//
//  BluetoothConnectionManagerView.swift
//  BluetoothDemo
//
//  Created by Jeshurun Roach on 11/13/20.
//

import BluetoothSupport
import Combine
import SwiftUI

struct BluetoothConnectionManagerView: View {
    @EnvironmentObject var connectionManager: BluetoothConnectionManager

    var body: some View {
        List {
            Toggle(isOn: $connectionManager.isEnabled) { Text(connectionManager.isEnabled ? "connected" : "disconnected") }
            ForEach(connectionManager.availableDevices) { device in
                NavigationLink(destination: page(device: device)) {
                    HStack {
                        Text(device.name ?? "unknown device")
                        Spacer()
                        connectionStatus(for: device.id)
                    }
                }
            }
        }
    }

    func page(device: BluetoothConnectionManager.DeviceInfo) -> some View {
        DeviceView(device: device)
            .navigationTitle(device.name ?? "unknown device")
    }

    @ViewBuilder
    func connectionStatus(for id: UUID) -> some View {
        switch connectionManager.connectionStatus(for: id) {
        case .connecting:
            Circle().foregroundColor(.blue)
        case .connected:
            Circle().foregroundColor(.green)
        case let .disconnecting(error):
            HStack {
                if let e = error {
                    Text(e.localizedDescription)
                }
                Circle().foregroundColor(.orange)
            }
        case let .disconnected(error):
            HStack {
                if let e = error {
                    Text(e.localizedDescription)
                }
                Circle().foregroundColor(.gray)
            }
        }
    }
}

struct DeviceView: View {
    @EnvironmentObject var manager: BluetoothConnectionManager
    var device: BluetoothConnectionManager.DeviceInfo

    var body: some View {
        if let connection = manager.connection(for: device.id) {
            DeviceConnectionView(connection: connection)
        } else {
            Text("Device not available")
        }
    }
}

struct DeviceConnectionView: View {
    @ObservedObject var connection: BluetoothConnection

    var body: some View {
        switch connection.state {
        case .connecting:
            Text("Connecting...")
        case .connected:
            DeviceConnectedView(vm: .init(connection: connection))
        case let .disconnecting(e):
            VStack {
                Text("Disconnecting...")
                if let error = e {
                    Text(error.localizedDescription)
                        .foregroundColor(.red)
                }
            }
        case .disconnected:
            disconnectedView
        }
    }

    var disconnectedView: some View {
        VStack {
            Text("Disconnected")
            if let e = connection.state.connectionError {
                Text(e.localizedDescription)
                    .foregroundColor(.red)
            }
            Button("Connect", action: connection.connect)
        }
    }
}

struct DeviceConnectedView: View {
    @StateObject var vm: VM

    @State var command: String = ""
    @State var message: String = ""
    @State var errorMessage: String?

    var body: some View {
        ScrollView {
            TextField("command", text: $command, onCommit: send)
                .disabled(!vm.connection.state.isConnected)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            Text(vm.connection.value ?? "")
            Text(vm.message)
            Text(errorMessage ?? "")
                .foregroundColor(.red)
        }.padding()
    }

    func send() {
        errorMessage = nil
        do {
            let cmd = command.uppercased().hasPrefix("AT+") ? command.uppercased() : command
            try vm.connection.send(message: cmd + "\r\n")
            command = ""
        } catch let e {
            errorMessage = e.localizedDescription
        }
    }

    class VM: ObservableObject {
        var connection: BluetoothConnection

        @Published var message: String = ""

        private var cancellables = Set<AnyCancellable>()

        init(connection: BluetoothConnection) {
            self.connection = connection
            connection.objectWillChange.sink {
                self.objectWillChange.send()
            }.store(in: &cancellables)
            connection.$value.scan(message) {
                if let x = $1 {
                    return $0 + x
                } else {
                    return ""
                }
            }.sink {
                self.message = $0
            }
            .store(in: &cancellables)
        }
    }
}

struct BluetoothConnectionManagerView_Previews: PreviewProvider {
    static var previews: some View {
        BluetoothConnectionManagerView()
    }
}
