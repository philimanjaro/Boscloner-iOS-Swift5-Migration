//
//  ContentView.swift
//  BluetoothDemo
//
//  Created by Jeshurun Roach on 11/10/20.
//

import BluetoothSupport
import Combine
import SwiftUI

struct ContentView: View {
    @StateObject var vm = VM()

    @State var command: String = ""
    @State var message: String = ""
    @State var errorMessage: String?

    var body: some View {
        ScrollView {
            HStack {
                Toggle(isOn: $vm.client.isEnabled) {
                    Text(vm.client.state.debugDescription)
                }
            }
            TextField("command", text: $command, onCommit: send)
                .disabled(!isConnected)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            Text(vm.client.value ?? "")
            Text(vm.message)
            Text(errorMessage ?? "")
                .foregroundColor(.red)
        }.padding()
    }

    func send() {
        errorMessage = nil
        do {
            let cmd = command.uppercased().hasPrefix("AT+") ? command.uppercased() : command
            try vm.client.send(command: cmd + "\r\n")
            command = ""
        } catch let e {
            errorMessage = e.localizedDescription
        }
    }

    var isConnected: Bool {
        guard case .connected = vm.client.state else { return false }
        return true
    }

    class VM: ObservableObject {
        var client = BluetoothClient(configuration: .hm19)

        @Published var message: String = ""

        private var cancellables = Set<AnyCancellable>()

        init() {
            client.objectWillChange.sink {
                self.objectWillChange.send()
            }.store(in: &cancellables)
            client.$value.scan(message) {
                if let x = $1 {
                    return $0 + x
                } else {
                    return ""
                }
            }.sink {
                self.message = $0
            }
            .store(in: &cancellables)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
