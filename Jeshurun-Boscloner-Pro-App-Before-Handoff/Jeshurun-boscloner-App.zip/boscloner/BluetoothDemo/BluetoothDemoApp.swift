//
//  BluetoothDemoApp.swift
//  BluetoothDemo
//
//  Created by Jeshurun Roach on 11/10/20.
//

import BluetoothSupport
import SwiftUI

@main
struct BluetoothDemoApp: App {
    @StateObject var manager = BluetoothConnectionManager(configuration: .hm19)

    var body: some Scene {
        WindowGroup {
            NavigationView {
                BluetoothConnectionManagerView()
            }.environmentObject(manager)
        }
    }
}
