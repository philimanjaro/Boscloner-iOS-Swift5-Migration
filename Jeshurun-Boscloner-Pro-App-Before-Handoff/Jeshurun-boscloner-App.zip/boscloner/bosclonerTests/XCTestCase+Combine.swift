//
//  XCTestCase+Combine.swift
//  bosclonerTests
//
//  Created by Jeshurun Roach on 4/29/21.
//

import Foundation
import XCTest
import Combine


extension Publisher {
    func await(_ testCase: XCTestCase) throws -> Output {
        try testCase.await(self)
    }
}

extension XCTestCase {
    enum AwaitError: Error {
        case noValue
    }
    
    @discardableResult
    func await<P: Publisher>(_ publisher: P) throws -> P.Output {
        let exp = XCTestExpectation()
        var value: P.Output?
        var error: P.Failure?
        
        var cancellables = Set<AnyCancellable>()
        
        publisher.sink(
            receiveCompletion: {
                defer { exp.fulfill() }
                guard case .failure(let e) = $0 else { return }
                error = e
            }, receiveValue: {
                value = $0
            }).store(in: &cancellables)
        
        wait(for: [exp], timeout: 60)
        
        guard error == nil else {
            throw error!
        }
        guard let v = value else {
            throw AwaitError.noValue
        }
        
        return v
    }
    
    func await<P: Publisher>(_ publisher: P) throws where P.Output == Never {
        let exp = XCTestExpectation()
        var error: P.Failure?
        
        var cancellables = Set<AnyCancellable>()
        publisher.sink(
            receiveCompletion: {
                defer { exp.fulfill() }
                guard case .failure(let e) = $0 else { return }
                error = e
            }, receiveValue: { _ in
                
            }).store(in: &cancellables)
        
        wait(for: [exp], timeout: 60)
        
        guard error == nil else {
            throw error!
        }
    }
}

