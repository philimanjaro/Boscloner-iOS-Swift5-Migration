//
//  bosclonerTests.swift
//  bosclonerTests
//
//  Created by Ryan McHugh on 12/29/20.
//

@testable import boscloner
import Combine
import Database
import BluetoothSupport
import DeviceSupport
import XCTest

class bosclonerTests: XCTestCase {
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testMockup() throws {
        var cancellables = Set<AnyCancellable>()
        DependencyInjector.default.database.facility()
            .sink {
                print($0)
                $0.forEach { DependencyInjector.default.database.delete(with: $0.id) }
            }
            .store(in: &cancellables)
    }
    
    func testDevice() throws {
        let btManager = BluetoothConnectionManager(configuration: .hm19)
        btManager.isEnabled = true
        
        let connectionManager = DeviceConnectionManager(
            btManager: btManager,
            deviceStore: TransientDeviceStore()
        )
        
        let device = try connectionManager.$availableDevices
            .print()
            .compactMap(\.first)
            .first().await(self)
        
        
        print(device.$status)
        
        let deviceManager = device.getManager()
        deviceManager.channel.connect()
        let validStatus = try deviceManager.channel.statePublisher.print().filter(\.isConnected).first().await(self)
        print(validStatus)
        try deviceManager.fetch(property: .battery)
        let battery = try deviceManager.$battery.first().await(self)
        
        print(battery)
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        measure {
            // Put the code you want to measure the time of here.
        }
    }
}

