// swift-tools-version:5.3
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "boscloner",
    platforms: [
        .iOS(.v14),
//        .macOS(.v10_15),
    ],
    products: [
        // Products define the executables and libraries a package produces, and make them visible to other packages.
        .library(
            name: "BosclonerCore",
//            type: .dynamic,
            targets: ["Database", "BluetoothSupport", "DeviceServices"]
        ),
    ],
    dependencies: [
        // Dependencies declare other packages that this package depends on.
        // .package(url: /* package url */, from: "1.0.0"),

    ],
    targets: [
        .target(name: "Database", resources: [.copy("CoreData/Model.xcdatamodeld")]),
        .testTarget(name: "DatabaseTests", dependencies: ["Database"]),

        .target(name: "BluetoothSupport"),
        .target(name: "DeviceSupport", dependencies: ["BluetoothSupport", "Database"]),
        .target(name: "DeviceServices", dependencies: ["DeviceSupport"]),
    ]
)
