import Combine
import Database
import XCTest

final class BosclonerTests: XCTestCase {
    var subscriptions = Set<AnyCancellable>()

    func initializeDatabase(test: @escaping (DatabaseService) -> Void) {
        let databaseService = DatabaseService()
        databaseService.initialize { error in
            if let error = error {
                XCTFail(error.localizedDescription)
                return
            }

            databaseService.badges().first().sink { badges in
                badges.forEach {
                    databaseService.delete(with: $0.id)
                }
                self.subscriptions.removeAll()

                test(databaseService)
            }.store(in: &self.subscriptions)
        }
    }

    func testDatabase() {
        let expectation = XCTestExpectation(description: "testDatabase")

        initializeDatabase { databaseService in
            let badge = Badge(
                data: "",
                type: .proxcard,
                location: nil,
                name: "TestBadge",
                userNotes: nil,
                clientId: nil,
                projectId: nil,
                sessionId: nil
            )
            var created = false
            databaseService.badges().sink { badges in
                print(badges.count)
                if created {
                    if let dbBadge = databaseService.badge(with: badge.id) {
                        if badge == dbBadge {
                            self.subscriptions.removeAll()
                        } else {
                            XCTFail("data not equal!\n\(json(badge))\n\(json(dbBadge))")
                        }
                    } else {
                        XCTFail("badge not found!")
                    }
                    expectation.fulfill()
                }
            }.store(in: &self.subscriptions)
            created = true
            databaseService.create(badge: badge)
        }

        wait(for: [expectation], timeout: 30.0)
    }

    static var allTests = [
        ("testDatabase", testDatabase),
    ]
}

func json<T: Encodable>(_ object: T) -> String {
    String(data: try? JSONEncoder().encode(object), encoding: .utf8) ?? ""
}
