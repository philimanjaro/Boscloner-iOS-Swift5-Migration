import XCTest

#if !canImport(ObjectiveC)
    public func allTests() -> [XCTestCaseEntry] {
        return [
            testCase(bosclonerTests.allTests),
        ]
    }
#endif
