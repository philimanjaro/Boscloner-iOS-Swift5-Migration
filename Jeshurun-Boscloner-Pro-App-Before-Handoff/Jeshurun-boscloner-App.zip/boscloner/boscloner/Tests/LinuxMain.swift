import XCTest

import bosclonerTests

var tests = [XCTestCaseEntry]()
tests += bosclonerTests.allTests()
XCTMain(tests)
