//
//  SwiftUIView.swift
//
//
//  Created by Jeshurun Roach on 11/8/20.
//

import CoreBluetooth
import Foundation

public enum BluetoothError: Error {
    case offline
    case connection(CBError)
    case encoding
    case decoding(String)
    case command(String)
}
