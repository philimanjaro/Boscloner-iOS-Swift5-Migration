//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/15/20.
//

import CoreBluetooth
import Foundation

extension CBPeripheralState: CustomDebugStringConvertible {
    public var debugDescription: String {
        switch self {
        case .connected: return "connected"
        case .connecting: return "connecting"
        case .disconnected: return "disconnected"
        case .disconnecting: return "disconnecting"
        @unknown default:
            return "unknown: \(rawValue)"
        }
    }
}

extension CBManagerState: CustomDebugStringConvertible {
    public var debugDescription: String {
        switch self {
        case .poweredOff: return "poweredOff"
        case .poweredOn: return "poweredOn"
        case .resetting: return "resetting"
        case .unauthorized: return "unauthorized"
        case .unknown: return "unknown"
        case .unsupported: return "unsupported"
        @unknown default: return "@unknown: \(rawValue)"
        }
    }
}
