//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/13/20.
//

import Combine
import CoreBluetooth
import Foundation

public class BluetoothConnection: NSObject, ObservableObject {
    public var id: UUID { peripheral.identifier }

    internal let peripheral: CBPeripheral
    private var characteristic: CBCharacteristic?

    private let outputSubject = PassthroughSubject<Data, Never>()

    public var receive: AnyPublisher<Data, Never> { outputSubject.eraseToAnyPublisher() }

    @Published public private(set) var state: State = .disconnected(nil)

    weak var manager: BluetoothConnectionManager?

    init(manager: BluetoothConnectionManager, peripheral: CBPeripheral) {
        self.manager = manager
        self.peripheral = peripheral

        super.init()

        peripheral.delegate = self
    }
}

public extension BluetoothConnection {
    func send(message: String) throws {
        guard case .connected = state, let char = characteristic else {
            throw Error.disconnected(state.connectionError)
        }

        let data = message.data(using: .utf8)!

        peripheral.writeValue(data, for: char, type: .withResponse)
    }

    func send(data _: Data) throws {
        guard case .connected = state else {
            throw Error.disconnected(state.connectionError)
        }
    }
}

// MARK: - State

public extension BluetoothConnection {
    enum State {
        case connecting
        case connected
        case disconnecting(ConnectionError?)
        case disconnected(ConnectionError?)

        public var isConnecting: Bool {
            guard case .connecting = self else { return false }
            return true
        }

        public var isConnected: Bool {
            guard case .connected = self else { return false }
            return true
        }

        public var isDisconnecting: Bool {
            guard case .disconnecting = self else { return false }
            return true
        }

        public var isDisconnected: Bool {
            guard case .disconnected = self else { return false }
            return true
        }

        public var connectionError: ConnectionError? {
            switch self {
            case let .disconnecting(error):
                return error
            case let .disconnected(error):
                return error
            default:
                return nil
            }
        }
    }
}

// MARK: - Error

public extension BluetoothConnection {
    enum Error: Swift.Error {
        case disconnected(ConnectionError?)
    }

    enum ConnectionError: Swift.Error {
        case outOfRange
        case tooManyConnections
        case discoveringServices(Swift.Error)
        case discoveringCharacteristic(Swift.Error)
        case updateFailed(Swift.Error)
        case disabled
        case unknown
    }
}

// MARK: - Setting up the connection

extension BluetoothConnection {
    public func connect() {
        if peripheral.state == .disconnected {
            manager?.centralManager.connect(peripheral, options: nil)
        } else if peripheral.state == .connected {
            setupService()
        }
    }

    private func setupService() {
        guard let manager = manager else {
            assertionFailure("Cannot setup services without a manager!")
            return
        }

        if let service = peripheral.services?.first(where: { $0.uuid == manager.serviceCBUUID }) {
            setupCharacteristic(with: service)
        } else {
            peripheral.discoverServices([manager.serviceCBUUID])
        }
    }

    private func setupCharacteristic(with service: CBService) {
        guard let manager = manager else {
            assertionFailure("Cannot setup services without a manager!")
            return
        }

        if let characteristic = service.characteristics?.first(where: { $0.uuid == manager.characteristicCBUUID }) {
            connect(with: characteristic)
        } else {
            peripheral.discoverCharacteristics([manager.characteristicCBUUID], for: service)
        }
    }

    private func connect(with characteristic: CBCharacteristic) {
        self.characteristic = characteristic
        state = .connected
    }

    public func disconnect() {
        guard state.isConnected || state.isConnecting,
              peripheral.state == .connected || peripheral.state == .connected
        else {
            return
        }
        state = .disconnecting(nil)
        manager?.centralManager.cancelPeripheralConnection(peripheral)
    }

    private func disconnect(with connectionError: ConnectionError) {
        state = .disconnecting(connectionError)

        switch peripheral.state {
        case .connecting, .connected:
            manager?.centralManager.cancelPeripheralConnection(peripheral)
        case .disconnected:
            state = .disconnected(connectionError)
            characteristic = nil
        default:
            break
        }
    }
}

// MARK: - Controls for manager

extension BluetoothConnection {
    func managerConnectedToPeripheral() {
        guard peripheral.state == .connected else {
            assertionFailure("peripheral is not connected")
            state = .disconnected(.unknown)
            return
        }

        setupService()
    }

    func managerDisconnectedFromPeripheral(error: ConnectionError?) {
        state = .disconnected(error ?? state.connectionError)
        characteristic = nil
    }

    func managerFailedToConnectToPeripheral(error: ConnectionError?) {
        state = .disconnected(error ?? state.connectionError)
        characteristic = nil
    }
}

// MARK: - CBPeripheralDelegate

extension BluetoothConnection: CBPeripheralDelegate {
    public func peripheral(_: CBPeripheral, didDiscoverServices error: Swift.Error?) {
        if let error = error {
            disconnect(with: .discoveringServices(error))
        } else {
            setupService()
        }
    }

    public func peripheral(_: CBPeripheral,
                           didDiscoverCharacteristicsFor service: CBService,
                           error: Swift.Error?)
    {
        if let error = error {
            disconnect(with: .discoveringCharacteristic(error))
        } else {
            setupCharacteristic(with: service)
        }
    }

    public func peripheral(_: CBPeripheral,
                           didUpdateValueFor characteristic: CBCharacteristic,
                           error: Swift.Error?)
    {
        if let error = error {
            disconnect(with: .updateFailed(error))
        } else if let data = characteristic.value {
            outputSubject.send(data)
        }
    }
}
