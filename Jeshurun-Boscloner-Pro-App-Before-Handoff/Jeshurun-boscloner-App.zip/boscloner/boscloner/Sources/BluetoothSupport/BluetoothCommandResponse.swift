//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/8/20.
//

import Foundation

public protocol BluetoothResponse {
    init(string: String) throws
}

public enum BluetoothResponses {
    public struct OK: BluetoothResponse {
        public init(string: String) throws {
            guard string == "OK" else {
                let errorComps = string.components(separatedBy: ",")
                if errorComps.count == 2, errorComps[0] == "ERR" {
                    throw BluetoothError.command(errorComps[1])
                } else {
                    throw BluetoothError.decoding(string)
                }
            }
        }
    }
}
