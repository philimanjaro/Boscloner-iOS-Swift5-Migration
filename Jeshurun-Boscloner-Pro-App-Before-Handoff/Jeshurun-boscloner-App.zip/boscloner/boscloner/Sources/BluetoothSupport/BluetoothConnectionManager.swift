//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/13/20.
//

import CoreBluetooth
import Foundation

public class BluetoothConnectionManager: NSObject, ObservableObject {
    private static var centralManagerOptions: [String: Any] {
        [CBCentralManagerOptionShowPowerAlertKey: true]
    }

    internal private(set) var centralManager: CBCentralManager!

    public let configuration: Configuration

    private var connections: [UUID: BluetoothConnection] = [:]

    @Published public var discoveredPeripheralIDs: Set<UUID> = []

    public init(configuration: Configuration) {
        self.configuration = configuration
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil, options: Self.centralManagerOptions)
    }

    @Published public var isEnabled: Bool = false {
        didSet { if oldValue != isEnabled { stateUpdated() } }
    }
}

// MARK: Bluetooth Connection

extension BluetoothConnectionManager {
    public func connectionStatus(for id: UUID) -> BluetoothConnection.State {
        connections[id]?.state ?? .disconnected(nil)
    }

    public func connection(for id: UUID) -> BluetoothConnection? {
        guard let peripheral = peripheral(id: id) else { return nil }
        return connection(for: peripheral)
    }

    internal func connection(for peripheral: CBPeripheral) -> BluetoothConnection {
        if let connection = connections[peripheral.identifier] {
            return connection
        } else {
            let connection = BluetoothConnection(manager: self, peripheral: peripheral)
            connections[peripheral.identifier] = connection
            return connection
        }
    }

    internal func peripheral(id: UUID) -> CBPeripheral? {
        centralManager.retrievePeripherals(withIdentifiers: [id])
            .first(where: { $0.identifier == id })
    }
}

// MARK: - State Management

extension BluetoothConnectionManager {
    private func stateUpdated() {
        if isEnabled, centralManager.state == .poweredOn, !centralManager.isScanning {
            start()
        } else if !isEnabled, centralManager.isScanning {
            stop()
        } else {
            print("State updated, doing nothing. enabled: \(isEnabled), state: \(centralManager.state)")
        }
    }

    private func start() {
        centralManager.scanForPeripherals(withServices: [serviceCBUUID], options: nil)
    }

    private func stop() {
        discoveredPeripheralIDs = []
        centralManager.stopScan()
        for peripheral in centralManager.retrieveConnectedPeripherals(withServices: [serviceCBUUID]) {
            centralManager.cancelPeripheralConnection(peripheral)
        }
    }
}

// MARK: - Configuration

extension BluetoothConnectionManager {
    public struct Configuration {
        public var serviceUUID: String
        public var characteristicUUID: String

        public init(service: String, characteristic: String) {
            serviceUUID = service
            characteristicUUID = characteristic
        }
    }

    internal var serviceCBUUID: CBUUID {
        CBUUID(string: configuration.serviceUUID)
    }

    internal var characteristicCBUUID: CBUUID {
        CBUUID(string: configuration.characteristicUUID)
    }
}

public extension BluetoothConnectionManager.Configuration {
    static let hm19: Self = .init(service: "FFE0", characteristic: "FFE1")
}

// MARK: - Device Info

public extension BluetoothConnectionManager {
    var availableDevices: [DeviceInfo] {
        centralManager.retrievePeripherals(withIdentifiers: Array(discoveredPeripheralIDs))
            .map { DeviceInfo(peripheral: $0) }
    }

    func deviceInfo(id: UUID) -> DeviceInfo? {
        guard let peripheral = peripheral(id: id) else { return nil }
        return DeviceInfo(peripheral: peripheral)
    }

    struct DeviceInfo: Equatable, Hashable, Identifiable {
        public var id: UUID
        public var name: String?
        
        public init(id: UUID, name: String?) {
            self.id = id
            self.name = name
        }

        public init(peripheral: CBPeripheral) {
            id = peripheral.identifier
            name = peripheral.name
        }
        
        public static func mock(name: String? = nil) -> DeviceInfo {
            DeviceInfo(id: .init(), name: name)
        }
    }
}

// MARK: - CBCentralManagerDelegate

extension BluetoothConnectionManager: CBCentralManagerDelegate {
    public func centralManagerDidUpdateState(_: CBCentralManager) {
        stateUpdated()
    }

    public func centralManager(_: CBCentralManager,
                               didDiscover peripheral: CBPeripheral,
                               advertisementData _: [String: Any],
                               rssi _: NSNumber)
    {
        discoveredPeripheralIDs.insert(peripheral.identifier)
    }

    public func centralManager(_: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        var connectionError: BluetoothConnection.ConnectionError?

        if let btError = error as? CBError {
            switch btError.code {
            case .connectionFailed, .unknown:
                connectionError = .unknown
            case .connectionTimeout:
                connectionError = .outOfRange
            case .connectionLimitReached:
                connectionError = .tooManyConnections
            default:
                break
            }
        }

        guard let connection = connections[peripheral.identifier] else { return }
        connection.managerFailedToConnectToPeripheral(error: connectionError)

        if !discoveredPeripheralIDs.contains(peripheral.identifier) {
            connections.removeValue(forKey: peripheral.identifier)
        }
    }

    public func centralManager(_: CBCentralManager, didConnect peripheral: CBPeripheral) {
        connections[peripheral.identifier]?.managerConnectedToPeripheral()
    }

    public func centralManager(_: CBCentralManager,
                               didDisconnectPeripheral peripheral: CBPeripheral,
                               error: Error?)
    {
        var connectionError: BluetoothConnection.ConnectionError?

        if let btError = error as? CBError {
            switch btError.code {
            case .connectionFailed, .unknown:
                connectionError = .unknown
            case .connectionTimeout:
                connectionError = .outOfRange
            case .connectionLimitReached:
                connectionError = .tooManyConnections
            default:
                break
            }
        }

        guard let connection = connections[peripheral.identifier] else { return }
        connection.managerDisconnectedFromPeripheral(error: connectionError)
        if !discoveredPeripheralIDs.contains(peripheral.identifier) {
            connections.removeValue(forKey: peripheral.identifier)
        }
    }
}
