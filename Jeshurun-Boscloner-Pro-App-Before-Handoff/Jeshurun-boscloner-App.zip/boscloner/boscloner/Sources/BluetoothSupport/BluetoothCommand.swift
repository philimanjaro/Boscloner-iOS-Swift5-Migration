//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/8/20.
//

import Combine
import Foundation

public protocol BluetoothCommand {
    var command: String { get }

    func toData() throws -> Data
}

public protocol BluetoothRequest: BluetoothCommand {
    associatedtype Response: BluetoothResponse
}

public extension BluetoothCommand {
    func toData() throws -> Data {
        guard let data = "?!\(command)?$\r\n".data(using: .utf8) else {
            throw BluetoothError.encoding
        }
        return data
    }
}

public extension BluetoothCommand {
    typealias OK = BluetoothResponses.OK
}

public extension BluetoothRequest {
    typealias Publisher = AnyPublisher<Response, Error>
}
