//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/11/21.
//

import BluetoothSupport
import Database
import Foundation

public class DeviceConnectionManager: ObservableObject {
    public let btManager: BluetoothConnectionManager
    let deviceStore: DeviceStore

    @Published public var thor: DeviceManager?
    @Published public var passport: DeviceManager?

    @Published public var availableDevices: [DeviceConnection]

    public init(btManager: BluetoothConnectionManager, deviceStore: DeviceStore) {
        self.btManager = btManager
        self.deviceStore = deviceStore
        availableDevices = []

        assignAvailableDevices()
    }

    private func assignAvailableDevices() {
        btManager.$discoveredPeripheralIDs
            .combineLatest($availableDevices)
            .compactMap { [unowned self] ids, devices -> [DeviceConnection]? in
                let newIds = ids.filter { id in !devices.contains(where: { $0.id == id }) }
                let newDevices = newIds.compactMap(btManager.connection(for:)).map {
                    DeviceConnection(manager: self, connection: $0, store: deviceStore)
                }
                guard !newDevices.isEmpty else { return nil }
                return devices + newDevices
            }.assign(to: &$availableDevices)
    }
}

/*
 import SwiftUI

 struct ThisView: View {

     @StateObject var connections: DeviceConnectionManager

     var body: some View {
         List {
             ForEach(connections.availableDevices, id: \.id) {
                 RowView(connection: $0)
             }
         }
     }

     struct RowView: View {

         @StateObject var connection: DeviceConnection

         var body: some View {
             HStack {
                 Group {
                     if connection.connection.state.isConnected {
                         Circle().foregroundColor(.green)
                     } else if connection.connection.state.isConnecting {
                         Circle().foregroundColor(.blue)
                     } else {
                         Circle().foregroundColor(.gray)
                     }
                 }.frame(width: 50, height: 50)
                 VStack {
                     Text(connection.id.uuidString)
                 }
                 Spacer()

             }.onTapGesture(perform: connection.connect)
         }
     }
 }
 */
