//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/15/20.
//

import Combine
import Foundation

public enum DeviceCommands {}

public protocol AnyDeviceCommand: BluetoothEncodable {
    var name: String { get }
}

public protocol DeviceCommand: AnyDeviceCommand {
    associatedtype Response: BluetoothDecodable
    associatedtype Error: BluetoothDecodable & Swift.Error
}

public enum DeviceCommandError<Command: DeviceCommand>: Error {
    public static func convert(_ error: Error) -> Self {
        if let error = error as? Command.Error {
            return .command(error)
        } else {
            return .bluetooth(error)
        }
    }

    case command(Command.Error)
    case bluetooth(Error)
}

public extension DeviceCommand {
    typealias Result = Swift.Result<Response, DeviceCommandError<Self>>
    typealias Publisher = AnyPublisher<Response, DeviceCommandError<Self>>
}

public extension BluetoothEncoder {
    func encode<Command: DeviceCommand>(command: Command) throws -> String {
        [
            delimiters.start,
            delimiters.command,
            ([command.name] + (try command.params()))
                .joined(separator: delimiters.parameter),
            delimiters.end,
        ].joined()
    }
}
