//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/22/20.
//

import BluetoothSupport
import Combine
import Database
import Foundation

public class DeviceManager: ObservableObject {
    @DeviceProperty(Property.battery) public var battery: Float?
    @DeviceProperty(Property.version) public var version: String?
    @DeviceProperty(Property.device) public var device: String?
    @DeviceProperty(Property.services) public var services: DeviceServices?

    @DeviceProperty(Property.state) public var state: State?

    @WritableDeviceProperty(Property.name) public var name: String?
    @WritableDeviceProperty(Property.badgeType) public var badgeType: BadgeType?
    @WritableDeviceProperty(Property.badgeId) public var badgeId: Badge.ID?
    @WritableDeviceProperty(Property.badgeData) public var badgeData: Data?

    public let channel: DeviceChannel
    let store: DeviceStore
    private var cancellables = Set<AnyCancellable>()
    
    var encoder: BluetoothEncoder { Self.encoder }
    var decoder: BluetoothDecoder { Self.decoder }

    private var activeCommands: [String: [PassthroughSubject<BluetoothDecoder.Result, Never>]] = [:]

    public init(channel: DeviceChannel, store: DeviceStore) {
        self.channel = channel
        self.store = store
        
        Mirror(reflecting: self).children.forEach {
            guard let property = $0.value as? AnyDeviceProperty else { return }
            property.manager = self
        }

        channel.receiveString.print(">> ").compactMap { try? Self.decoder.decode(message: $0) }
            .sink { [unowned self] result in receive(result: result) }
            .store(in: &cancellables)
    }
}

extension DeviceManager {
    private func sink(for property: Property) -> PassthroughSubject<Result<[String], Error>, Never> {
        self[keyPath: property.kp].sink
    }

    public func send<Command: DeviceCommand>(command: Command) -> Command.Publisher {
        let subject = PassthroughSubject<BluetoothDecoder.Result, Never>()
        activeCommands[command.name] = [subject] + (activeCommands[command.name] ?? [])

        return subject.tryMap { result -> Command.Response in
            if result.success {
                return try Command.Response(params: result.params)
            } else {
                let error = try Command.Error(params: result.params)
                throw DeviceCommandError<Command>.command(error)
            }
        }.mapError(DeviceCommandError<Command>.convert)
            .eraseToAnyPublisher()
    }

    func receive(result: BluetoothDecoder.Result) {
        switch result.kind {
        case .command:
            guard let subject = activeCommands[result.name]?.popLast() else { return }
            subject.send(result)
            subject.send(completion: .finished)

        case .property:
            guard let property = Property(rawValue: result.name) else { return }
            sink(for: property).send(.success(result.params))

        case .notification:
            break
        }
    }
}

extension DeviceManager {
    static let encoder = BluetoothEncoder(delimiters: .default)
    static let decoder = BluetoothDecoder(delimiters: .default)

    public enum Property: String {
        case battery
        case device
        case version
        case name
        case state
        case services
        case badgeType = "badge_type"
        case badgeId = "badge_id"
        case badgeData = "badge_data"
        
        var kp: KeyPath<DeviceManager, AnyDeviceProperty> {
            switch self {
            case .battery: return \._battery.asAnyProperty
            case .version: return \._version.asAnyProperty
            case .device: return \._device.asAnyProperty
            case .name: return \._name.asAnyProperty
            case .badgeId: return \._badgeId.asAnyProperty
            case .badgeType: return \._badgeType.asAnyProperty
            case .badgeData: return \._badgeData.asAnyProperty
            case .state: return \._state.asAnyProperty
            case .services: return \._services.asAnyProperty
            }
        }
    }

    func fetch(properties: [Property]) throws {
        for prop in properties {
            try fetch(property: prop)
        }
    }

    public func fetch(property: Property) throws {
        try self[keyPath: property.kp].fetch()
    }

    func getDeviceInfo() -> AnyPublisher<Device, Error> {
        do {
            try _name.fetchIfNeeded()
            try _device.fetchIfNeeded()
            try _version.fetchIfNeeded()
            try _services.fetchIfNeeded()
        } catch {
            return Fail(error: error).eraseToAnyPublisher()
        }

        let currentDevice = store.device(id: channel.id)

        return $name.combineLatest($device, $version, $services)
            .tryMap { [id = channel.id] name, device, version, services in
                Device(id: UID(id),
                       name: try name.get(),
                       favorite: currentDevice?.favorite ?? false,
                       autoconnect: currentDevice?.autoconnect ?? false,
                       firmwareVersion: try version.get(),
                       hardwareIdentifier: try device.get(),
                       services: try services.get(),
                       scanEvents: [])
            }.eraseToAnyPublisher()
    }

    func fetchEmptyProperties() throws {
        try fetch(properties: emptyProperties)
    }

    var emptyProperties: [Property] {
        let prop: [Property?] = [
            battery == nil ? .battery : nil,
            version == nil ? .version : nil,
            device == nil ? .device : nil,
            name == nil ? .name : nil,
//            badgeId == nil ? .badgeId : nil,
//            badgeType == nil ? .badgeType : nil,
//            badgeData == nil ? .badgeData : nil,
            state == nil ? .state : nil,
        ]

        return prop.compactMap { $0 }
    }

    public enum State: BluetoothCodable {
        case standby
        case discovery(SearchMode)
        case scan(BadgeType)
        case simulate
        case bruteForce

        public init(params: [String]) throws {
            guard let raw = params.first,
                  params.count == 1
            else { throw BluetoothDecoder.Error.invalid }

            let splits = raw.split(separator: "_", maxSplits: 1, omittingEmptySubsequences: false)

            guard let key = CodingKeys(rawValue: String(splits[0])) else {
                throw BluetoothDecoder.Error.invalid
            }

            let param = splits.count > 1 ? String(splits[1]) : nil

            switch key {
            case .standby:
                self = .standby
            case .discovery:
                guard let param = param, let mode = SearchMode(rawValue: param) else {
                    throw BluetoothDecoder.Error.invalid
                }
                self = .discovery(mode)
            case .scan:
                guard let param = param, let type = BadgeType.from(id: param) else {
                    throw BluetoothDecoder.Error.invalid
                }
                self = .scan(type)
            case .simulate:
                self = .simulate
            case .bruteForce:
                self = .bruteForce
            }
        }

        public func params() throws -> [String] {
            switch self {
            case .standby:
                return [CodingKeys.standby.rawValue]
            case let .discovery(mode):
                return ["\(CodingKeys.discovery.rawValue)_\(mode.rawValue)"]
            case let .scan(badge):
                return ["\(CodingKeys.scan.rawValue)_\(badge.id)"]
            case .simulate:
                return [CodingKeys.simulate.rawValue]
            case .bruteForce:
                return [CodingKeys.bruteForce.rawValue]
            }
        }

        private enum CodingKeys: String {
            case standby = "standby"
            case discovery = "search"
            case scan
            case simulate = "sim"
            case bruteForce = "brute"
        }

        public enum SearchMode: String {
            case low = "lf"
            case high = "hf"
            case auto
        }
    }
}

extension BadgeType: BluetoothCodable {
    public func params() throws -> [String] {
        [id]
    }

    public init(params: [String]) throws {
        guard let id = params.first,
              params.count == 1,
              let type = BadgeType.from(id: id)
        else { throw BluetoothDecoder.Error.invalid }
        self = type
    }
}

extension UID: BluetoothCodable {
    public func params() throws -> [String] {
        [rawValue.uuidString]
    }

    public init(params: [String]) throws {
        guard let value = params.first,
              params.count == 1,
              let uuid = UUID(uuidString: value)
        else { throw BluetoothDecoder.Error.invalid }
        self.init(uuid)
    }
}

extension DeviceServices: BluetoothCodable {
    public func params() throws -> [String] {
        [String(rawValue, radix: 0b10, uppercase: false)]
    }

    public init(params: [String]) throws {
        guard let str = params.first,
              params.count == 1,
              let val = UInt64(str, radix: 0b10)
        else { throw BluetoothDecoder.Error.invalid }
        self.init(rawValue: val)
    }
}
