//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/19/20.
//

import Foundation

protocol AnyDeviceNotification: BluetoothDecodable {
    static var name: String { get }
}

protocol DeviceNotification: AnyDeviceNotification {}
