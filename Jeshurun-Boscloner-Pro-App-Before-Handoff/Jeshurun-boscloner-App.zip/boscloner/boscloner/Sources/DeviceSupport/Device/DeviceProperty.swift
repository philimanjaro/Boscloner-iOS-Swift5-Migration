//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/19/20.
//

import BluetoothSupport
import Combine
import Foundation

protocol AnyDeviceProperty: AnyObject {
    var name: String { get }
    var error: Error? { get }
    var manager: DeviceManager? { get set }
    var sink: PassthroughSubject<Result<[String], Error>, Never> { get }
    func fetch() throws
    func fetchIfNeeded() throws
}

extension AnyDeviceProperty {
    var asAnyProperty: AnyDeviceProperty { self }
}

@propertyWrapper
public class DeviceProperty<Value: BluetoothDecodable>: ObservableObject, AnyDeviceProperty {
    struct ManagerMissing: Error { }
    
    fileprivate var queue: DispatchQueue
    let name: String
    weak var manager: DeviceManager?

    func getManager() throws -> DeviceManager {
        guard let manager = manager else {
            throw ManagerMissing()
        }
        return manager
    }

    public let sink: PassthroughSubject<Result<[String], Error>, Never>
    fileprivate var cancellables = Set<AnyCancellable>()

    fileprivate var value: Result<Value, Error>?
    fileprivate var restoreValue: Result<Value, Error>?

    public var wrappedValue: Value? {
        queue.sync {
            guard case let .success(value) = value else { return nil }
            return value
        }
    }

    public var error: Error? {
        queue.sync {
            guard case let .failure(error) = value else { return nil }
            return error
        }
    }

    private let valuePublisher: AnyPublisher<Result<Value, Error>, Never>

    public var projectedValue: AnyPublisher<Result<Value, Error>, Never> {
        queue.sync {
            if let value = value {
                return valuePublisher.prepend(value).eraseToAnyPublisher()
            } else {
                return valuePublisher
            }
        }
    }

    public func fetch() throws {
        let message = try getManager().encoder.encodeGetProperty(name: name)
        try getManager().channel.send(message: message)
    }

    public func fetchIfNeeded() throws {
        guard value == nil else { return }
        try fetch()
    }

    public convenience init<Name: RawRepresentable>(_ name: Name) where Name.RawValue == String {
        self.init(name: name.rawValue)
    }

    public init(name: String) {
        self.name = name
        let queue = DispatchQueue(label: "bluetooth.device.property.\(name)", attributes: .concurrent)
        let sink = PassthroughSubject<Result<[String], Error>, Never>()

        let publisher = sink.map { publisher -> Result<Value, Error> in
            do {
                return .success(try Value(params: try publisher.get()))
            } catch {
                return .failure(error)
            }
        }.share().makeConnectable().autoconnect()

        valuePublisher = publisher.eraseToAnyPublisher()
        self.queue = queue
        self.sink = sink

        publisher.receive(on: queue, options: DispatchQueue.SchedulerOptions(flags: .barrier))
            .sink { [unowned self] newValue in
                value = newValue
            }.store(in: &cancellables)
    }
}

@propertyWrapper
public class WritableDeviceProperty<Value: BluetoothCodable>: DeviceProperty<Value> {
    override public var wrappedValue: Value? {
        get {
            guard case let .success(value) = value else { return nil }
            return value
        }
        set {
            guard let value = newValue else { return }
            try? set(value: value)
        }
    }

    override public var projectedValue: AnyPublisher<Result<Value, Error>, Never> {
        super.projectedValue
    }

    public func set(value: Value) throws {
        if restoreValue == nil {
            restoreValue = self.value
        }
        let message = try getManager().encoder.encodeSetProperty(name: name, value: value)
        try getManager().channel.send(message: message)
        self.value = .success(value)
    }
}

extension BluetoothEncoder {
    func encodeGetProperty(name: String) throws -> String {
        [
            delimiters.start,
            delimiters.property,
            name,
            delimiters.end,
        ].joined()
    }

    func encodeSetProperty(name: String, value: BluetoothEncodable) throws -> String {
        [
            delimiters.start,
            delimiters.property,
            name,
            delimiters.parameter,
            try value.params().joined(separator: delimiters.parameter),
            delimiters.end,
        ].joined()
    }
}
