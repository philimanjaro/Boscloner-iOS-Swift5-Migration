//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/11/21.
//

import Database
import Foundation

public protocol DeviceStore {
    func device(id: UUID) -> Database.Device?
    func save(device: Database.Device)
}

public class DatabaseDeviceStore: DeviceStore {
    let database: DatabaseService
    public init(database: DatabaseService) {
        self.database = database
    }

    public func device(id: UUID) -> Database.Device? {
        database.device(with: UID(id))
    }

    public func save(device: Database.Device) {
        database.save(device: device)
    }
}

public class TransientDeviceStore: DeviceStore {
    var devices: [UUID: Database.Device]
    
    public init(devices: [UUID: Database.Device] = [:]) {
        self.devices = devices
    }
    
    public func device(id: UUID) -> Database.Device? {
        devices[id]
    }

    public func save(device: Database.Device) {
        devices[device.id.rawValue] = device
    }
}
