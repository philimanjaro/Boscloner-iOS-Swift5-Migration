//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/8/21.
//

import BluetoothSupport
import Combine
import Foundation

public protocol DeviceChannel {
    var id: UUID { get }
    var state: BluetoothConnection.State { get }
    var statePublisher: AnyPublisher<BluetoothConnection.State, Never> { get }

    var receive: AnyPublisher<Data, Never> { get }
    var receiveString: AnyPublisher<String, Never> { get }

    func send(message: String) throws
    func send(data: Data) throws

    func connect()
    func disconnect()
}

public extension DeviceChannel {
    var receiveString: AnyPublisher<String, Never> {
        receive.compactMap { String(data: $0, encoding: .ascii) }
            .eraseToAnyPublisher()
    }

    func send(message: String) throws {
        guard let data = message.data(using: .ascii) else {
            throw BluetoothDecoder.Error.invalid
        }
        try send(data: data)
    }
}

extension BluetoothConnection: DeviceChannel {
    public var statePublisher: AnyPublisher<BluetoothConnection.State, Never> {
        $state.eraseToAnyPublisher()
    }
}
