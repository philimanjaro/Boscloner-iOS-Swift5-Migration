//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/11/21.
//

import BluetoothSupport
import Combine
import Database

import Foundation

public class DeviceConnection: ObservableObject {
    @Published public var status: Status

    public enum Status {
        case disconnected
        case connecting
        case setup(DeviceSetupManager)
        case connected(DeviceManager)
        case disconnecting
    }

    unowned let connectionManager: DeviceConnectionManager
    let store: DeviceStore
    let connection: BluetoothConnection
    var device: Device?
    var deviceManager: DeviceManager?
    var id: UUID { connection.id }

    init(manager: DeviceConnectionManager, connection: BluetoothConnection, store: DeviceStore) {
        connectionManager = manager
        self.connection = connection
        self.store = store
        device = store.device(id: connection.id)
        status = .disconnected
    }

    public func getManager() -> DeviceManager {
        guard let manager = deviceManager else {
            let manager = DeviceManager(channel: connection, store: store)
            deviceManager = manager
            return manager
        }
        return manager
    }

    func connect() {}

    func connectChannel() -> AnyPublisher<Void, Error> {
        connection.statePublisher.tryFilter {
            if let error = $0.connectionError {
                throw error
            } else {
                return $0.isConnected
            }
        }.first().map { _ in () }.eraseToAnyPublisher()
    }

    func fetchDeviceProperties() {}
}

public class DeviceSetupManager {
    init(connection _: BluetoothConnection) {}
}
