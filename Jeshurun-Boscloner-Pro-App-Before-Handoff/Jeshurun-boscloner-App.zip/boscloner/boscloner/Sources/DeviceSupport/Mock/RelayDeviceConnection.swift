//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/8/21.
//

import BluetoothSupport
import Combine
import Foundation

public class RelayDeviceConnection: DeviceChannel {
    public var statePublisher: AnyPublisher<BluetoothConnection.State, Never> {
        $state.eraseToAnyPublisher()
    }

    public let id = UUID()

    @Published public var state: BluetoothConnection.State = .disconnected(nil)

    private let deviceOutput: AnyPublisher<String, Never>
    private let deviceInput: (String) -> Void

    public var receiveString: AnyPublisher<String, Never> { deviceOutput }
    public var receive: AnyPublisher<Data, Never> {
        receiveString.compactMap { $0.data(using: .ascii) }.eraseToAnyPublisher()
    }

    public init<P: Publisher>(send: P,
                              receive: @escaping (String) -> Void) where P.Output == String, P.Failure == Never
    {
        deviceOutput = send.eraseToAnyPublisher()
        deviceInput = receive
    }

    public func send(data: Data) throws {
        guard let message = String(data: data, encoding: .ascii) else { return }
        try send(message: message)
    }

    public func send(message: String) throws {
        deviceInput(message)
    }

    public func connect() {
        state = .connected
    }

    public func disconnect() {
        state = .disconnected(nil)
    }
}
