//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/22/20.
//

import Foundation

extension Int: BluetoothCodable {
    public func params() throws -> [String] {
        ["\(self)"]
    }

    public init(params: [String]) throws {
        guard params.count == 1, let value = Int(params[0]) else { throw BluetoothDecoder.Error.invalid }
        self = value
    }
}

extension Float: BluetoothCodable {
    public func params() throws -> [String] {
        ["\(self)"]
    }

    public init(params: [String]) throws {
        guard params.count == 1, let value = Float(params[0]) else { throw BluetoothDecoder.Error.invalid }
        self = value
    }
}

public extension RawRepresentable where RawValue: BluetoothEncodable, Self: BluetoothEncodable {
    func params() throws -> [String] {
        try rawValue.params()
    }
}

public extension RawRepresentable where RawValue: BluetoothDecodable, Self: BluetoothDecodable {
    init(params: [String]) throws {
        let rawValue = try RawValue(params: params)
        guard let value = Self(rawValue: rawValue) else {
            throw BluetoothDecoder.Error.invalid
        }
        self = value
    }
}

extension String: BluetoothCodable {
    public func params() throws -> [String] {
        [self]
    }

    public init(params: [String]) throws {
        guard params.count == 1 else { throw BluetoothDecoder.Error.invalid }
        self = params[0]
    }
}

extension Data: BluetoothCodable {
    public init(params: [String]) throws {
        guard params.count == 1,
              let base64string = params.first,
              let data = Data(base64Encoded: base64string)
        else { throw BluetoothDecoder.Error.invalid }

        self = data
    }

    public func params() throws -> [String] {
        [base64EncodedString()]
    }
}
