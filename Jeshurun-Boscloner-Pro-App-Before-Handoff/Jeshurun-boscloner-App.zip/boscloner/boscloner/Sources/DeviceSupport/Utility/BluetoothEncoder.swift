//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/19/20.
//

import Foundation

public protocol BluetoothEncodable {
    func params() throws -> [String]
}

// MARK: - Common

public struct BluetoothEncoder {
    let delimiters: Delimiters

    public init(delimiters: Delimiters) {
        self.delimiters = delimiters
    }

    public struct Delimiters {
        public var start: String
        public var end: String
        public var success: String
        public var failure: String
        public var parameter: String
        public var property: String
        public var command: String
        public var notification: String
    }
}

// MARK: - Default Delimiters

public extension BluetoothEncoder.Delimiters {
    static let `default` = debug
        
    static let encoded = Self(
        start: String(bytes: [0x2], encoding: .ascii)!,
        end: String(bytes: [0x3], encoding: .ascii)!,
        success: String(bytes: [0x33], encoding: .ascii)!,
        failure: String(bytes: [0x34], encoding: .ascii)!,
        parameter: String(bytes: [0x31], encoding: .ascii)!,
        property: "$",
        command: "!",
        notification: "^"
    )
    
    static let debug = Self(
        start: "{",
        end: "}",
        success: ":",
        failure: "!",
        parameter: ",",
        property: "$",
        command: "!",
        notification: "^"
    )
}
