//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/19/20.
//

import Foundation

public typealias BluetoothCodable = BluetoothEncodable & BluetoothDecodable

public protocol BluetoothDecodable {
    init(params: [String]) throws
}

extension RawRepresentable where RawValue == String, Self: BluetoothDecodable {
    init(params: [String]) throws {
        guard params.count == 1,
              let string = params.first,
              let value = Self(rawValue: string)
        else { throw BluetoothDecoder.Error.invalid }
        self = value
    }
}

public struct BluetoothDecoder {
    public enum Error: Swift.Error {
        case invalid
    }

    public let delimiters: Delimiters

    public init(delimiters: Delimiters) {
        self.delimiters = delimiters
    }

    public struct Result {
        public enum Kind {
            case property
            case command
            case notification
        }

        public var name: String
        public var kind: Kind
        public var success: Bool
        public var params: [String]
    }

    public func decode(data: Data) throws -> Result {
        guard let string = String(data: data, encoding: .ascii) else {
            throw Error.invalid
        }
        return try decode(message: string)
    }

    public func decode(message: String) throws -> Result {
        guard message.hasPrefix(delimiters.start), message.hasSuffix(delimiters.end) else {
            print("response does not have proper start and end")
            throw Error.invalid
        }

        let trimmed = message.dropFirst(delimiters.start.count).dropLast(delimiters.end.count)

        let range: Range<String.Index>
        let success: Bool
        if let successRange = trimmed.range(of: delimiters.success) {
            success = true
            range = successRange
        } else if let failureRange = trimmed.range(of: delimiters.failure) {
            success = false
            range = failureRange
        } else {
            print("No success or failure delim")
            throw Error.invalid
        }

        let kind: Result.Kind
        let name: String
        switch trimmed[trimmed.startIndex ..< range.lowerBound] {
        case let cmd where cmd.hasPrefix(delimiters.command):
            kind = .command
            name = String(cmd.dropFirst(delimiters.command.count))
        case let notif where notif.hasPrefix(delimiters.notification):
            kind = .notification
            name = String(notif.dropFirst(delimiters.notification.count))
        case let prop where prop.hasPrefix(delimiters.property):
            kind = .property
            name = String(prop.dropFirst(delimiters.property.count))
        default:
            throw Error.invalid
        }

        let params: [String]
        if range.upperBound < trimmed.endIndex {
            params = trimmed[range.upperBound ..< trimmed.endIndex]
                .split(separator: delimiters.parameter)
                .map(String.init)
        } else {
            params = []
        }

        return Result(name: name, kind: kind, success: success, params: params)
    }

    public struct Delimiters {
        public var start: String
        public var end: String
        public var success: String
        public var failure: String
        public var parameter: String
        public var property: String
        public var command: String
        public var notification: String
    }
}

public extension BluetoothDecoder.Delimiters {
    static let `default` = Self(
        start: String(bytes: [0x2], encoding: .ascii)!,
        end: String(bytes: [0x3], encoding: .ascii)!,
        success: String(bytes: [0x33], encoding: .ascii)!,
        failure: String(bytes: [0x34], encoding: .ascii)!,
        parameter: String(bytes: [0x31], encoding: .ascii)!,
        property: "$",
        command: "!",
        notification: "^"
    )
}

// MARK: - Decoding Support

extension StringProtocol {
    func split(separator: String) -> [SubSequence] {
        var index: String.Index = startIndex
        var splits: [SubSequence] = []
        while index < endIndex {
            guard let range = self[index ..< endIndex].range(of: separator) else { break }
            splits.append(self[index ..< range.lowerBound])
            index = range.upperBound
        }
        if index < endIndex {
            splits.append(self[index ..< endIndex])
        }
        return splits
    }
}
