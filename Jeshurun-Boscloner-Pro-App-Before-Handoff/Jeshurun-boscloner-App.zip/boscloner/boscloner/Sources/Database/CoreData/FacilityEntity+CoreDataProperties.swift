//
//  FacilityEntity+CoreDataProperties.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

public extension FacilityEntity {
    @nonobjc class func fetchRequest() -> NSFetchRequest<FacilityEntity> {
        return NSFetchRequest<FacilityEntity>(entityName: "FacilityEntity")
    }

    @NSManaged var createdAt: Date?
    @NSManaged var id: UUID?
    @NSManaged var name: String?
    @NSManaged var notes: String?
    @NSManaged var address: Data?
    @NSManaged var lat: NSDecimalNumber?
    @NSManaged var lng: NSDecimalNumber?
    @NSManaged var defaultBadgeType: String?
    @NSManaged var facilityBadgeId: String?
    @NSManaged var radius: NSDecimalNumber?
    @NSManaged var badges: NSSet?
    @NSManaged var client: ClientEntity?
    @NSManaged var accessPoints: NSOrderedSet?
    @NSManaged var contacts: NSSet?
}

// MARK: Generated accessors for badges

public extension FacilityEntity {
    @objc(addBadgesObject:)
    @NSManaged func addToBadges(_ value: BadgeEntity)

    @objc(removeBadgesObject:)
    @NSManaged func removeFromBadges(_ value: BadgeEntity)

    @objc(addBadges:)
    @NSManaged func addToBadges(_ values: NSSet)

    @objc(removeBadges:)
    @NSManaged func removeFromBadges(_ values: NSSet)
}

// MARK: Generated accessors for accessPoints

public extension FacilityEntity {
    @objc(insertObject:inAccessPointsAtIndex:)
    @NSManaged func insertIntoAccessPoints(_ value: AccessPointEntity, at idx: Int)

    @objc(removeObjectFromAccessPointsAtIndex:)
    @NSManaged func removeFromAccessPoints(at idx: Int)

    @objc(insertAccessPoints:atIndexes:)
    @NSManaged func insertIntoAccessPoints(_ values: [AccessPointEntity], at indexes: NSIndexSet)

    @objc(removeAccessPointsAtIndexes:)
    @NSManaged func removeFromAccessPoints(at indexes: NSIndexSet)

    @objc(replaceObjectInAccessPointsAtIndex:withObject:)
    @NSManaged func replaceAccessPoints(at idx: Int, with value: AccessPointEntity)

    @objc(replaceAccessPointsAtIndexes:withAccessPoints:)
    @NSManaged func replaceAccessPoints(at indexes: NSIndexSet, with values: [AccessPointEntity])

    @objc(addAccessPointsObject:)
    @NSManaged func addToAccessPoints(_ value: AccessPointEntity)

    @objc(removeAccessPointsObject:)
    @NSManaged func removeFromAccessPoints(_ value: AccessPointEntity)

    @objc(addAccessPoints:)
    @NSManaged func addToAccessPoints(_ values: NSOrderedSet)

    @objc(removeAccessPoints:)
    @NSManaged func removeFromAccessPoints(_ values: NSOrderedSet)
}

// MARK: Generated accessors for contacts

public extension FacilityEntity {
    @objc(addContactsObject:)
    @NSManaged func addToContacts(_ value: ContactEntity)

    @objc(removeContactsObject:)
    @NSManaged func removeFromContacts(_ value: ContactEntity)

    @objc(addContacts:)
    @NSManaged func addToContacts(_ values: NSSet)

    @objc(removeContacts:)
    @NSManaged func removeFromContacts(_ values: NSSet)
}
