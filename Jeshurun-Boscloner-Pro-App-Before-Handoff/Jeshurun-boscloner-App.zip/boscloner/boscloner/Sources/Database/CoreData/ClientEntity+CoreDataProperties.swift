//
//  ClientEntity+CoreDataProperties.swift
//
//
//  Created by Shahla Almasri Hafez on 1/13/21.
//
//

import CoreData
import Foundation

public extension ClientEntity {
    @nonobjc class func fetchRequest() -> NSFetchRequest<ClientEntity> {
        return NSFetchRequest<ClientEntity>(entityName: "ClientEntity")
    }

    @NSManaged var createdAt: Date?
    @NSManaged var id: UUID?
    @NSManaged var name: String?
    @NSManaged var notes: String?
    @NSManaged var facilities: NSSet?
    @NSManaged var primaryContact: ContactEntity?
}

// MARK: Generated accessors for facilities

public extension ClientEntity {
    @objc(addFacilitiesObject:)
    @NSManaged func addToFacilities(_ value: FacilityEntity)

    @objc(removeFacilitiesObject:)
    @NSManaged func removeFromFacilities(_ value: FacilityEntity)

    @objc(addFacilities:)
    @NSManaged func addToFacilities(_ values: NSSet)

    @objc(removeFacilities:)
    @NSManaged func removeFromFacilities(_ values: NSSet)
}
