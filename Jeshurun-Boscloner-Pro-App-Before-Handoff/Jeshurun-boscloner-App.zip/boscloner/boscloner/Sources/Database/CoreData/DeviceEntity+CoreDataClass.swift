//
//  DeviceEntity+CoreDataClass.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

@objc(DeviceEntity)
public class DeviceEntity: NSManagedObject {}
