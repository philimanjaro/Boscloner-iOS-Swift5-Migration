//
//  ProjectEntity+CoreDataProperties.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

public extension ProjectEntity {
    @nonobjc class func fetchRequest() -> NSFetchRequest<ProjectEntity> {
        return NSFetchRequest<ProjectEntity>(entityName: "ProjectEntity")
    }

    @NSManaged var createdAt: Date?
    @NSManaged var id: UUID?
    @NSManaged var name: String?
    @NSManaged var lastActive: Date?
    @NSManaged var badges: NSSet?
    @NSManaged var client: ClientEntity?
}

// MARK: Generated accessors for badges

public extension ProjectEntity {
    @objc(addBadgesObject:)
    @NSManaged func addToBadges(_ value: BadgeEntity)

    @objc(removeBadgesObject:)
    @NSManaged func removeFromBadges(_ value: BadgeEntity)

    @objc(addBadges:)
    @NSManaged func addToBadges(_ values: NSSet)

    @objc(removeBadges:)
    @NSManaged func removeFromBadges(_ values: NSSet)
}
