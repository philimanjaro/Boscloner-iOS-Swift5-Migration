//
//  ContactEntity+CoreDataProperties.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

public extension ContactEntity {
    @nonobjc class func fetchRequest() -> NSFetchRequest<ContactEntity> {
        return NSFetchRequest<ContactEntity>(entityName: "ContactEntity")
    }

    @NSManaged var createdAt: Date?
    @NSManaged var firstName: String?
    @NSManaged var lastName: String?
    @NSManaged var id: UUID?
    @NSManaged var title: String?
    @NSManaged var phone: String?
    @NSManaged var email: String?
    @NSManaged var photo: Data?
    @NSManaged var contactsId: String?
    @NSManaged var notes: String?
    @NSManaged var client: ClientEntity?
    @NSManaged var facility: FacilityEntity?
}
