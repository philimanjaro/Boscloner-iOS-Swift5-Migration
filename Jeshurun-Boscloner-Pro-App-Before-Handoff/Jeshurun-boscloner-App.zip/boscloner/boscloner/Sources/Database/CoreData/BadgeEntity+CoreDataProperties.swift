//
//  BadgeEntity+CoreDataProperties.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

public extension BadgeEntity {
    @nonobjc class func fetchRequest() -> NSFetchRequest<BadgeEntity> {
        return NSFetchRequest<BadgeEntity>(entityName: "BadgeEntity")
    }

    @NSManaged var createdAt: Date?
    @NSManaged var payload: Data?
    @NSManaged var id: UUID?
    @NSManaged var name: String?
    @NSManaged var type: String?
    @NSManaged var notes: String?
    @NSManaged var hidden: Bool
    @NSManaged var projects: NSSet?
    @NSManaged var facility: FacilityEntity?
    @NSManaged var scans: NSSet?
    @NSManaged var enabledAccessPoints: NSSet?
    @NSManaged var disabledAccessPoints: NSSet?
}

// MARK: Generated accessors for projects

public extension BadgeEntity {
    @objc(addProjectsObject:)
    @NSManaged func addToProjects(_ value: ProjectEntity)

    @objc(removeProjectsObject:)
    @NSManaged func removeFromProjects(_ value: ProjectEntity)

    @objc(addProjects:)
    @NSManaged func addToProjects(_ values: NSSet)

    @objc(removeProjects:)
    @NSManaged func removeFromProjects(_ values: NSSet)
}

// MARK: Generated accessors for scans

public extension BadgeEntity {
    @objc(addScansObject:)
    @NSManaged func addToScans(_ value: ScanEventEntity)

    @objc(removeScansObject:)
    @NSManaged func removeFromScans(_ value: ScanEventEntity)

    @objc(addScans:)
    @NSManaged func addToScans(_ values: NSSet)

    @objc(removeScans:)
    @NSManaged func removeFromScans(_ values: NSSet)
}
