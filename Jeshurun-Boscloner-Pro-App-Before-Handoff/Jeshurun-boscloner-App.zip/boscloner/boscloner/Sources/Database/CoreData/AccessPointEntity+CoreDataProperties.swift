//
//  AccessPointEntity+CoreDataProperties.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

public extension AccessPointEntity {
    @nonobjc class func fetchRequest() -> NSFetchRequest<AccessPointEntity> {
        return NSFetchRequest<AccessPointEntity>(entityName: "AccessPointEntity")
    }

    @NSManaged var id: UUID?
    @NSManaged var name: String?
    @NSManaged var notes: String?
    @NSManaged var lat: NSDecimalNumber?
    @NSManaged var lng: NSDecimalNumber?
    @NSManaged var facility: FacilityEntity?
    @NSManaged var enabledBadges: NSSet?
    @NSManaged var disabledBadges: NSSet?
}

// MARK: Generated accessors for enabledBadges

public extension AccessPointEntity {
    @objc(addEnabledBadgesObject:)
    @NSManaged func addToEnabledBadges(_ value: BadgeEntity)

    @objc(removeEnabledBadgesObject:)
    @NSManaged func removeFromEnabledBadges(_ value: BadgeEntity)

    @objc(addEnabledBadges:)
    @NSManaged func addToEnabledBadges(_ values: NSSet)

    @objc(removeEnabledBadges:)
    @NSManaged func removeFromEnabledBadges(_ values: NSSet)
}
