//
//  ScanEventEntity+CoreDataProperties.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

public extension ScanEventEntity {
    @nonobjc class func fetchRequest() -> NSFetchRequest<ScanEventEntity> {
        return NSFetchRequest<ScanEventEntity>(entityName: "ScanEventEntity")
    }

    @NSManaged var id: UUID?
    @NSManaged var timestamp: Date?
    @NSManaged var lat: NSDecimalNumber?
    @NSManaged var lng: NSDecimalNumber?
    @NSManaged var device: DeviceEntity?
    @NSManaged var project: ProjectEntity?
    @NSManaged var badge: BadgeEntity?
}
