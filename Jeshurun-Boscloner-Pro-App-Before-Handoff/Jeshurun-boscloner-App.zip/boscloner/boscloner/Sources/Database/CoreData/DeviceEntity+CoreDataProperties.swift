//
//  DeviceEntity+CoreDataProperties.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

public extension DeviceEntity {
    @nonobjc class func fetchRequest() -> NSFetchRequest<DeviceEntity> {
        return NSFetchRequest<DeviceEntity>(entityName: "DeviceEntity")
    }

    @NSManaged var id: UUID?
    @NSManaged var name: String?
    @NSManaged var favorite: Bool
    @NSManaged var autoconnect: Bool
    @NSManaged var firmwareVersion: String?
    @NSManaged var hardwareVersion: String?
    @NSManaged var services: Int64
    @NSManaged var scanEvents: NSSet?
}

// MARK: Generated accessors for scanEvents

public extension DeviceEntity {
    @objc(addScanEventsObject:)
    @NSManaged func addToScanEvents(_ value: ScanEventEntity)

    @objc(removeScanEventsObject:)
    @NSManaged func removeFromScanEvents(_ value: ScanEventEntity)

    @objc(addScanEvents:)
    @NSManaged func addToScanEvents(_ values: NSSet)

    @objc(removeScanEvents:)
    @NSManaged func removeFromScanEvents(_ values: NSSet)
}
