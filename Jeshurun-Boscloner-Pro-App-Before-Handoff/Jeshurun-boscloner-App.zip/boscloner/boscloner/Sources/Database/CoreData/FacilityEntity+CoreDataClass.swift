//
//  FacilityEntity+CoreDataClass.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

@objc(FacilityEntity)
public class FacilityEntity: NSManagedObject {}
