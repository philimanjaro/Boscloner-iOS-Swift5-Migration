//
//  ProjectEntity+CoreDataClass.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//
//

import CoreData
import Foundation

@objc(ProjectEntity)
public class ProjectEntity: NSManagedObject {}
