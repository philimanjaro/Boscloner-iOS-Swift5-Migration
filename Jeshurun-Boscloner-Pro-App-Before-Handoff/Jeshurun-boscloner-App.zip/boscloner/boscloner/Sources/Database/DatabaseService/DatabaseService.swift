//
//  File.swift
//
//
//  Created by rickb on 10/9/20.
//

import Combine
import CoreData
import Foundation

public class DatabaseService: ObservableObject {
    var persistentContainer: NSPersistentContainer!

    var changeSubject = PassthroughSubject<AnyChange, Never>()

    var bundle: Bundle {
        let bundle = Bundle(for: Self.self)
        let url = bundle.url(forResource: "boscloner_Database", withExtension: "bundle")!
        return Bundle(url: url)!
    }

    var modelURL: URL {
        bundle.url(forResource: "Model", withExtension: "momd")!
    }

    public init() {}

    public func initialize(completion: ((Error?) -> Void)? = nil) {
        let mom = NSManagedObjectModel(contentsOf: modelURL)!
        persistentContainer = NSPersistentContainer(name: "Model", managedObjectModel: mom)
        persistentContainer.loadPersistentStores { [weak self] _, error in
            if let url = self?.persistentContainer.persistentStoreDescriptions.first?.url {
                print(url)
            }
            self?.objectWillChange.send()
            completion?(error)
        }
    }
}

extension DatabaseService {
    enum Change<Model: Identifiable> {
        case create(Model)
        case update(Model)
        case delete(Model.ID)

        var id: Model.ID {
            switch self {
            case let .create(model): return model.id
            case let .update(model): return model.id
            case let .delete(id): return id
            }
        }

        var model: Model? {
            switch self {
            case let .create(model): return model
            case let .update(model): return model
            case .delete: return nil
            }
        }

        var createdModel: Model? {
            guard case let .create(model) = self else { return nil }
            return model
        }

        var updatedModel: Model? {
            guard case let .update(model) = self else { return nil }
            return model
        }

        var deletedModelId: Model.ID? {
            guard case let .delete(id) = self else { return nil }
            return id
        }
    }

    enum AnyChange {
        case client(Change<Client>)
        case facility(Change<Facility>)

        var client: Change<Client>? {
            guard case let .client(client) = self else { return nil }
            return client
        }

        var facility: Change<Facility>? {
            guard case let .facility(facility) = self else { return nil }
            return facility
        }
    }
}

protocol PredicateQuery {
    var predicate: NSPredicate? { get }
}

extension NSSet {
    func mapIds<Model: ManagedValue>(model _: Model.Type = Model.self) -> [UID<Model>] {
        map { .init(($0 as? Model.AssociatedManagedObject)?.id ?? UUID()) }
    }
}

extension NSOrderedSet {
    func mapIds<Model: ManagedValue>(model _: Model.Type = Model.self) -> [UID<Model>] {
        map { .init(($0 as? Model.AssociatedManagedObject)?.id ?? UUID()) }
    }
}
