//
//  File.swift
//
//
//  Created by rickb on 10/9/20.
//

import Combine
import CoreData
import Foundation

extension Project: ManagedValue {
    typealias AssociatedManagedObject = ProjectEntity

    init(with project: ProjectEntity) {
        id = .init(project.id!)
        name = project.name!
        createdAt = project.createdAt!
        lastActive = project.lastActive
        createdAt = project.createdAt!
//        client = project.client.map { Client.ID($0.id!) }
        savedBadges = project.badges?.mapIds() ?? []
    }
}

extension ProjectEntity: ManagedObject {
    typealias AssociatedManagedValue = Project

    func configure(with project: Project, in context: NSManagedObjectContext) {
        id = project.id.rawValue
        name = project.name
        createdAt = project.createdAt
        lastActive = project.lastActive
        createdAt = project.createdAt
        client = context.fetch(with: project.client).first
    }
}

// MARK: - Query

public extension DatabaseService {
    indirect enum ProjectQuery: PredicateQuery {
        case client(Client.ID)
        case project(Project.ID)
    }

    func projects(for client: Client) -> AnyPublisher<[Project], Never> {
        persistentContainer.viewContext.query(with: ProjectQuery.client(client.id), for: Project.self)
    }

    func project(with id: Project.ID?) -> Project? {
        persistentContainer.viewContext.fetch(with: id).first
    }

    func delete(with id: Project.ID?) {
        persistentContainer.viewContext.delete(with: id, for: Project.self)
    }
}

extension DatabaseService.ProjectQuery {
    var predicate: NSPredicate? {
        switch self {
        case let .client(clientID):
            return NSPredicate(format: "client.id == %@", argumentArray: [clientID.rawValue])
        case let .project(projectID):
            return NSPredicate(format: "id == %@", argumentArray: [projectID])
        }
    }
}
