//
//  File.swift
//
//
//  Created by rickb on 10/9/20.
//

import Combine
import CoreData
import Foundation

extension Client: ManagedValue {
    typealias AssociatedManagedObject = ClientEntity

    init(with client: ClientEntity) {
        id = .init(client.id!)
        createdAt = client.createdAt!
        name = client.name!
        notes = client.notes
        facilities = client.facilities?.mapIds() ?? []
        primaryContact = .init(with: client.primaryContact!)
    }
}

extension ClientEntity: ManagedObject {
    typealias AssociatedManagedValue = Client

    func configure(with client: Client, in context: NSManagedObjectContext) {
        id = client.id.rawValue
        createdAt = client.createdAt
        notes = client.notes
        name = client.name
        primaryContact?.configure(with: client.primaryContact, in: context)
    }
}

// MARK: - Query

public extension DatabaseService {
    func save(client: Client) {
        let entity = persistentContainer.viewContext.fetch(with: client.id, for: ClientEntity.self).first

        entity?.configure(with: client, in: persistentContainer.viewContext)

        persistentContainer.viewContext.saveContext()
        changeSubject.send(.client(.update(client)))
    }

    func create(client: Client) {
        let clientEntity = ClientEntity(context: persistentContainer.viewContext)
        let contactEntity = ContactEntity(context: persistentContainer.viewContext)

        clientEntity.primaryContact = contactEntity

        clientEntity.configure(with: client, in: persistentContainer.viewContext)
        contactEntity.configure(with: client.primaryContact, in: persistentContainer.viewContext)

        persistentContainer.viewContext.saveContext()

        changeSubject.send(.client(.create(client)))
    }

    func clients() -> [Client] {
        persistentContainer.viewContext.fetchAll()
    }

    func client(with id: Client.ID?) -> Client? {
        persistentContainer.viewContext.fetch(with: id).first
    }

    func clientPublisher(with id: Client.ID?) -> AnyPublisher<Client?, Never> {
        guard let id = id else {
            return Empty(completeImmediately: false)
                .eraseToAnyPublisher()
        }

        return changeSubject.compactMap(\.client)
            .filter { $0.id == id }
            .map(\.model)
            .prepend(client(with: id))
            .eraseToAnyPublisher()
    }

    func clientsPublisher() -> AnyPublisher<[Client], Never> {
        let currentClients = clients()

        return changeSubject.compactMap(\.client)
            .scan(currentClients) { clients, change in
                var clients = clients
                switch change {
                case let .create(client):
                    clients.append(client)
                case let .update(client):
                    if let index = clients.firstIndex(where: { $0.id == client.id }) {
                        clients[index] = client
                    } else {
                        clients.append(client)
                    }
                case let .delete(id):
                    clients.removeAll(where: { $0.id == id })
                }

                return clients
            }.prepend(currentClients)
            .eraseToAnyPublisher()
    }

    func delete(with id: Client.ID?) {
        persistentContainer.viewContext.delete(with: id, for: Client.self)
    }
}
