//
//  File.swift
//
//
//  Created by rickb on 10/12/20.
//

import Combine
import CoreData
import Foundation

extension Facility: ManagedValue {
    private static let jsonDecoder = JSONDecoder()
    typealias AssociatedManagedObject = FacilityEntity

    init(with facility: FacilityEntity) {
        id = .init(facility.id!)
        name = facility.name!
        address = facility.address.flatMap {
            try? Self.jsonDecoder.decode(Address.self, from: $0)
        }
        lat = facility.lat?.doubleValue
        lng = facility.lng?.doubleValue
        radius = facility.radius?.doubleValue

        defaultBadgeType = facility.defaultBadgeType.flatMap(BadgeType.from(id:))
        facilityBadgeId = facility.facilityBadgeId
        notes = facility.notes
        client = facility.client != nil ? .init(facility.client!.id!) : .new
        contacts = facility.contacts?.mapIds() ?? []
        badges = facility.badges?.mapIds() ?? []
        accessPoints = facility.accessPoints?.mapIds() ?? []
    }
}

extension FacilityEntity: ManagedObject {
    private static let jsonEncoder = JSONEncoder()
    typealias AssociatedManagedValue = Facility

    func configure(with facility: Facility, in context: NSManagedObjectContext) {
        id = facility.id.rawValue
        name = facility.name
        address = facility.address.flatMap {
            try? Self.jsonEncoder.encode($0)
        }
        lat = facility.lat.map(NSDecimalNumber.init(value:))
        lng = facility.lng.map(NSDecimalNumber.init(value:))
        radius = facility.radius.map(NSDecimalNumber.init(value:))

        defaultBadgeType = facility.defaultBadgeType?.id
        facilityBadgeId = facility.facilityBadgeId
        notes = facility.notes

        client = context.fetch(with: facility.client).first
    }
}

// MARK: - Query

public extension DatabaseService {
    indirect enum FacilityQuery: PredicateQuery {
        case all
        case client(Client.ID)
        case project(Project.ID)
        case and(FacilityQuery, FacilityQuery)
        case or(FacilityQuery, FacilityQuery)
        case not(FacilityQuery)
    }

    func save(facility: Facility) {
        guard let entity = persistentContainer.viewContext.fetch(
            with: facility.id, for: FacilityEntity.self
        ).first else {
            create(facility: facility)
            return
        }

        entity.name = facility.name
        entity.notes = facility.notes

        changeSubject.send(.facility(.update(facility)))
    }

    // TODO: - add client property to entity
//    func sites(for client: Client) -> AnyPublisher<[Site], Never> {
//        persistentContainer.viewContext.query(with: SiteQuery.)
//    }

    func facility(with id: Facility.ID?) -> Facility? {
        persistentContainer.viewContext.fetch(with: id).first
    }

    func create(facility: Facility) {
        persistentContainer.viewContext.create(with: facility)
        changeSubject.send(.facility(.create(facility)))
    }

    func delete(with id: Facility.ID) {
        persistentContainer.viewContext.delete(with: id, for: Facility.self)
        changeSubject.send(.facility(.delete(id)))
    }

    // MARK: - queries

    func facility(for client: Client.ID) -> AnyPublisher<[Facility], Never> {
        persistentContainer.viewContext.query(with: FacilityQuery.client(client), for: Facility.self)
    }

    func facility(query: FacilityQuery = .all) -> AnyPublisher<[Facility], Never> {
        persistentContainer.viewContext.query(with: query)
    }
}

extension DatabaseService.FacilityQuery {
    var predicate: NSPredicate? {
        switch self {
        case .all:
            return nil
        case let .client(clientID):
            return NSPredicate(format: "client.id == %@", argumentArray: [clientID.rawValue])
        case let .project(projectID):
            return NSPredicate(format: "project.id == %@", argumentArray: [projectID.rawValue])
        case let .and(query1, query2):
            return NSCompoundPredicate(andPredicateWithSubpredicates: [query1.predicate, query2.predicate]
                .compactMap { $0 })
        case let .or(query1, query2):
            return NSCompoundPredicate(orPredicateWithSubpredicates: [query1.predicate, query2.predicate]
                .compactMap { $0 })
        case let .not(query):
            return query.predicate.flatMap { NSCompoundPredicate(notPredicateWithSubpredicate: $0) }
        }
    }
}
