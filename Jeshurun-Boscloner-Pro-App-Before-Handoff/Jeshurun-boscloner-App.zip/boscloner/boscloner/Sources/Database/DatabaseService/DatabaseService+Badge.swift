//
//  File.swift
//
//
//  Created by rickb on 10/9/20.
//

import Combine
import CoreData
import Foundation

extension Badge: ManagedValue {
    typealias AssociatedManagedObject = BadgeEntity

    init(with badge: BadgeEntity) {
        id = .init(badge.id!)
        type = .from(id: badge.type!)!
        createdAt = badge.createdAt!
        payload = badge.payload!
        name = badge.name
        notes = badge.notes
        hidden = badge.hidden
        savedInProjects = badge.projects!.mapIds()
        facility = .init(badge.facility!.id!)
        scans = badge.scans!.mapIds()
        unlockedAccessPoints = badge.enabledAccessPoints!.mapIds()
        restrictedAccessPoints = badge.disabledAccessPoints!.mapIds()
    }
}

extension BadgeEntity: ManagedObject {
    typealias AssociatedManagedValue = Badge

    func configure(with badge: Badge, in context: NSManagedObjectContext) {
        id = badge.id.rawValue
        createdAt = badge.createdAt
        payload = badge.payload
        name = badge.name
        type = badge.type.id
        notes = badge.notes
        hidden = badge.hidden
        facility = context.fetch(with: badge.facility).first
    }
}

// MARK: - Query

public extension DatabaseService {
    indirect enum BadgeQuery {
        case all
        case project(Project.ID)
        case facility(Facility.ID)
        case and(BadgeQuery, BadgeQuery)
        case or(BadgeQuery, BadgeQuery)
        case not(BadgeQuery)
    }

    func save(badge: Badge) {
        guard let entity = persistentContainer.viewContext.fetch(with: badge.id).first as BadgeEntity? else {
            create(badge: badge)
            return
        }
        entity.configure(with: badge, in: persistentContainer.viewContext)
        persistentContainer.viewContext.saveContext()
    }

    func create(badge: Badge) {
        persistentContainer.viewContext.create(with: badge)
    }

    func badges(query: BadgeQuery = .all) -> AnyPublisher<[Badge], Never> {
        persistentContainer.viewContext.query(with: query)
    }

    func badge(with id: Badge.ID?) -> Badge? {
        persistentContainer.viewContext.fetch(with: id).first
    }

    func delete(with id: Badge.ID?) {
        persistentContainer.viewContext.delete(with: id, for: Badge.self)
    }
}

extension DatabaseService.BadgeQuery: PredicateQuery {
    var predicate: NSPredicate? {
        switch self {
        case .all:
            return nil
        case let .project(projectId):
            return NSPredicate(format: "project.id == %@", argumentArray: [projectId.rawValue])
        case let .facility(facilityId):
            return NSPredicate(format: "facility.id == %@", argumentArray: [facilityId.rawValue])
        case let .and(query1, query2):
            return NSCompoundPredicate(andPredicateWithSubpredicates: [query1.predicate, query2.predicate]
                .compactMap { $0 })
        case let .or(query1, query2):
            return NSCompoundPredicate(orPredicateWithSubpredicates: [query1.predicate, query2.predicate]
                .compactMap { $0 })
        case let .not(query):
            return query.predicate.flatMap { NSCompoundPredicate(notPredicateWithSubpredicate: $0) }
        }
    }
}
