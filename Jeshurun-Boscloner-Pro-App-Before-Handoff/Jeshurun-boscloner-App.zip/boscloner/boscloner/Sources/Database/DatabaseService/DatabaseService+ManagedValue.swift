//
//  File.swift
//
//
//  Created by rickb on 10/9/20.
//

import Combine
import CoreData
import Foundation

protocol ManagedValue: Identifiable where ID == UID<Self>, AssociatedManagedObject.AssociatedManagedValue == Self {
    associatedtype AssociatedManagedObject: ManagedObject

    init(with: AssociatedManagedObject)
}

protocol ManagedObject: NSManagedObject where AssociatedManagedValue.AssociatedManagedObject == Self {
    associatedtype AssociatedManagedValue: ManagedValue
    var id: UUID? { get }
    func configure(with: AssociatedManagedValue, in context: NSManagedObjectContext)
    static var sortDescriptors: [NSSortDescriptor] { get }
}

extension ManagedObject {
    static var sortDescriptors: [NSSortDescriptor] { [.init(key: "createdAt", ascending: true)] }

    static func request() -> NSFetchRequest<Self> {
        let request = NSFetchRequest<Self>(entityName: entity().name!)
        request.sortDescriptors = sortDescriptors
        return request
    }
}

extension NSManagedObjectContext {
    func fetchAll<T: ManagedObject>(for _: T.Type = T.self) -> [T] {
        let request = T.request()
        do {
            return try fetch(request)
        } catch {
            print(error)
            return []
        }
    }

    func fetchAll<T: ManagedValue>(for _: T.Type = T.self) -> [T] {
        fetchAll(for: T.AssociatedManagedObject.self).map { T(with: $0) }
    }

    func fetch<T: ManagedObject>(with id: T.AssociatedManagedValue.ID?, for _: T.Type = T.self) -> [T] {
        guard let id = id else { return [] }
        let request = T.request()
        request.predicate = NSPredicate(format: "id == %@", argumentArray: [id.rawValue])
        do {
            return try fetch(request)
        } catch {
            print(error)
            return []
        }
    }

    func fetch<T: ManagedValue>(with id: T.ID?, for _: T.Type = T.self) -> [T] {
        fetch(with: id, for: T.AssociatedManagedObject.self).map { T(with: $0) }
    }

    func query<T: ManagedValue, Q: PredicateQuery>(with query: Q,
                                                   for _: T.Type = T.self) -> AnyPublisher<[T], Never>
    {
        NSFetchedResultsControllerPublisher(for: T.AssociatedManagedObject.self, context: self) {
            $0.fetchRequest.predicate = query.predicate
        }.mapManagedEntities()
    }

    func delete<T: ManagedValue>(with id: T.ID?, for _: T.Type) {
        fetch(with: id, for: T.AssociatedManagedObject.self).forEach { object in
            delete(object)
        }
        saveContext()
    }

    func create<T: ManagedValue>(with value: T, saveContext: Bool = true) {
        let object = T.AssociatedManagedObject(context: self)
        object.configure(with: value, in: self)
        if saveContext {
            self.saveContext()
        }
    }

    func saveContext() {
        if hasChanges {
            do {
                try save()
            } catch {
                fatalError(error.localizedDescription)
            }
        }
    }
}

extension Publisher where Output: Sequence {
    func mapManagedEntities<T: ManagedValue>() -> AnyPublisher<[T], Failure>
        where Output.Element == FetchedResultsSectionInfo<T.AssociatedManagedObject>
    {
        map { sections in
            sections.flatMap { $0.objects }.map { T(with: $0) }
        }.eraseToAnyPublisher()
    }
}

extension NSFetchedResultsControllerPublisher {
    init(for _: T.Type = T.self,
         context: NSManagedObjectContext,
         configure: ((NSFetchedResultsController<T>) -> Void)? = nil) where T: ManagedObject
    {
        let controller = NSFetchedResultsController(fetchRequest: T.request(),
                                                    managedObjectContext: context,
                                                    sectionNameKeyPath: nil,
                                                    cacheName: nil)
        configure?(controller)
        self.init(controller: controller)
    }
}
