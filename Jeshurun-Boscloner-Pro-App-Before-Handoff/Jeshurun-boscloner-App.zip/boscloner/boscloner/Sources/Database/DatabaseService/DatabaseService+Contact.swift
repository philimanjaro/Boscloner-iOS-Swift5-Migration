//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Combine
import CoreData
import Foundation

extension Contact: ManagedValue {
    typealias AssociatedManagedObject = ContactEntity

    init(with contact: ContactEntity) {
        id = .init(contact.id!)
        firstName = contact.firstName!
        lastName = contact.lastName!
        title = contact.title
        phone = contact.phone
        email = contact.email
        photo = contact.photo
        contactsId = contact.contactsId
        notes = contact.notes

        client = .init(contact.client!.id!)
        facility = contact.facility.map { UID<Facility>($0.id!) }
    }

    public var name: String {
        return "\(firstName) \(lastName)"
    }
}

extension ContactEntity: ManagedObject {
    typealias AssociatedManagedValue = Contact

    func configure(with contact: Contact, in context: NSManagedObjectContext) {
        id = contact.id.rawValue
        firstName = contact.firstName
        lastName = contact.lastName
        title = contact.title
        phone = contact.phone
        email = contact.email
        photo = contact.photo
        contactsId = contact.contactsId
        notes = contact.notes

        client = context.fetch(with: contact.client).first
        facility = context.fetch(with: contact.facility).first
    }
}

// MARK: - Query

public extension DatabaseService {
    indirect enum ContactQuery: PredicateQuery {
        case all
        case client(Client.ID)
        case facility(Facility.ID)
        case and(ContactQuery, ContactQuery)
        case or(ContactQuery, ContactQuery)
        case not(ContactQuery)
    }

    func save(contact: Contact) {
        guard let entity = persistentContainer.viewContext.fetch(with: contact.id).first as ContactEntity? else {
            persistentContainer.viewContext.create(with: contact)
            return
        }
        entity.configure(with: contact, in: persistentContainer.viewContext)
        persistentContainer.viewContext.saveContext()
    }

    func contact(with id: Contact.ID?) -> Contact? {
        persistentContainer.viewContext.fetch(with: id).first
    }

    func contacts(for client: Client) -> AnyPublisher<[Contact], Never> {
        persistentContainer.viewContext.query(with: ContactQuery.client(client.id), for: Contact.self)
    }

    func delete(with id: Contact.ID?) {
        persistentContainer.viewContext.delete(with: id, for: Contact.self)
    }
}

extension DatabaseService.ContactQuery {
    var predicate: NSPredicate? {
        switch self {
        case .all:
            return nil
        case let .client(clientID):
            return NSPredicate(format: "id == %@", argumentArray: [clientID.rawValue])
        case let .facility(facilityID):
            return NSPredicate(format: "facility.id == %@", argumentArray: [facilityID.rawValue])
        case let .and(query1, query2):
            return NSCompoundPredicate(andPredicateWithSubpredicates: [query1.predicate, query2.predicate]
                .compactMap { $0 })
        case let .or(query1, query2):
            return NSCompoundPredicate(orPredicateWithSubpredicates: [query1.predicate, query2.predicate]
                .compactMap { $0 })
        case let .not(query):
            return query.predicate.flatMap { NSCompoundPredicate(notPredicateWithSubpredicate: $0) }
        }
    }
}
