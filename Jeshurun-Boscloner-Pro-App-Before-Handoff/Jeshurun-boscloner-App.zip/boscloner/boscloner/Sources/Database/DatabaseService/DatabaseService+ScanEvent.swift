//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Combine
import CoreData
import Foundation

extension ScanEvent: ManagedValue {
    typealias AssociatedManagedObject = ScanEventEntity

    init(with scanEvent: ScanEventEntity) {
        id = .init(scanEvent.id!)
        timestamp = scanEvent.timestamp!
        lat = scanEvent.lat?.doubleValue
        lng = scanEvent.lng?.doubleValue

        project = scanEvent.project.map { Project.ID($0.id!) }
        device = Device.ID(scanEvent.device!.id!)
        badge = Badge.ID(scanEvent.badge!.id!)
    }
}

extension ScanEventEntity: ManagedObject {
    typealias AssociatedManagedValue = ScanEvent

    func configure(with scanEvent: ScanEvent, in context: NSManagedObjectContext) {
        id = scanEvent.id.rawValue
        timestamp = scanEvent.timestamp
        lat = scanEvent.lat.map(NSDecimalNumber.init(value:))
        lng = scanEvent.lng.map(NSDecimalNumber.init(value:))

        project = context.fetch(with: scanEvent.project).first
        device = context.fetch(with: scanEvent.device).first
        badge = context.fetch(with: scanEvent.badge).first
    }
}

// MARK: - Query
