//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Combine
import CoreData
import Foundation

extension Device: ManagedValue {
    typealias AssociatedManagedObject = DeviceEntity

    init(with device: DeviceEntity) {
        id = .init(device.id!)
        name = device.name
        favorite = device.favorite
        autoconnect = device.autoconnect
        firmwareVersion = device.firmwareVersion!
        hardwareIdentifier = device.hardwareVersion!
        services = DeviceServices(rawValue: UInt64(device.services))
        scanEvents = device.scanEvents!.mapIds()
    }
}

extension DeviceEntity: ManagedObject {
    typealias AssociatedManagedValue = Device

    static var sortDescriptors: [NSSortDescriptor] { [] }

    func configure(with device: Device, in _: NSManagedObjectContext) {
        id = device.id.rawValue
        name = device.name
        favorite = device.favorite
        autoconnect = device.autoconnect
        firmwareVersion = device.firmwareVersion
        hardwareVersion = device.hardwareIdentifier
        services = Int64(device.services.rawValue)
    }
}

// MARK: - Query

public extension DatabaseService {
    indirect enum DeviceQuery {
        case all
        case favorite
        case autoconnect
    }

    func save(device: Device) {
        let entity = persistentContainer.viewContext
            .fetch(with: device.id, for: DeviceEntity.self).first
            ?? DeviceEntity(context: persistentContainer.viewContext)

        entity.configure(with: device, in: persistentContainer.viewContext)

        persistentContainer.viewContext.saveContext()
    }

    func delete(device id: Device.ID?) {
        persistentContainer.viewContext
            .delete(with: id, for: Device.self)
    }

    func devices(query: DeviceQuery) -> AnyPublisher<[Device], Never> {
        persistentContainer.viewContext.query(with: query)
    }

    func devices() -> [Device] {
        persistentContainer.viewContext.fetchAll()
    }

    func device(with id: Device.ID?) -> Device? {
        persistentContainer.viewContext.fetch(with: id).first
    }
}

extension DatabaseService.DeviceQuery: PredicateQuery {
    var predicate: NSPredicate? {
        switch self {
        case .all:
            return nil
        case .autoconnect:
            return NSPredicate(format: "autoconnect == TRUE")
        case .favorite:
            return NSPredicate(format: "favorite == TRUE")
        }
    }
}
