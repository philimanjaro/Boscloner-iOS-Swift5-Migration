//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Combine
import CoreData
import Foundation

extension AccessPoint: ManagedValue {
    typealias AssociatedManagedObject = AccessPointEntity

    init(with accessPoint: AccessPointEntity) {
        id = .init(accessPoint.id!)
        name = accessPoint.name ?? ""
        notes = accessPoint.notes
        lat = accessPoint.lat?.doubleValue
        lng = accessPoint.lng?.doubleValue
        facility = .init(accessPoint.facility!.id!)
        enabledBadges = accessPoint.enabledBadges?
            .map { UID<Badge>(($0 as? BadgeEntity)?.id! ?? UUID()) } ?? []
        disabledBadges = accessPoint.disabledBadges?
            .map { UID<Badge>(($0 as? BadgeEntity)?.id! ?? UUID()) } ?? []
    }
}

extension AccessPointEntity: ManagedObject {
    typealias AssociatedManagedValue = AccessPoint

    func configure(with accessPoint: AccessPoint, in context: NSManagedObjectContext) {
        id = accessPoint.id.rawValue
        name = accessPoint.name
        lat = accessPoint.lat.map(NSDecimalNumber.init(floatLiteral:))
        lng = accessPoint.lng.map(NSDecimalNumber.init(floatLiteral:))

        facility = context.fetch(with: accessPoint.facility).first
    }
}

// MARK: - Query

public extension DatabaseService {
    indirect enum AccessPointQuery {
        case all
        case facility(Facility.ID)
        case enabled(for: Badge.ID)
        case disabled(for: Badge.ID)

        case and(AccessPointQuery, AccessPointQuery)
        case or(AccessPointQuery, AccessPointQuery)
        case not(AccessPointQuery)
    }

    func create(accessPoint: AccessPoint) {
        persistentContainer.viewContext.create(with: accessPoint)
    }

    func accessPoints(query: AccessPointQuery = .all) -> AnyPublisher<[AccessPoint], Never> {
        persistentContainer.viewContext.query(with: query)
    }

    func accessPoint(with id: AccessPoint.ID) -> AccessPoint? {
        persistentContainer.viewContext.fetch(with: id).first
    }

    func delete(with id: AccessPoint.ID?) {
        persistentContainer.viewContext.delete(with: id, for: AccessPoint.self)
    }
}

extension DatabaseService.AccessPointQuery: PredicateQuery {
    var predicate: NSPredicate? {
        switch self {
        case .all:
            return nil
        case let .facility(facilityId):
            return NSPredicate(format: "facility.id == %@", argumentArray: [facilityId.rawValue])

        case let .enabled(badgeId):
            return NSPredicate(format: "ANY enabledBadges.id == %@", argumentArray: [badgeId.rawValue])

        case let .disabled(badgeId):
            return NSPredicate(format: "ANY disabledBadges.id == %@", argumentArray: [badgeId.rawValue])

        case let .and(query1, query2):
            return NSCompoundPredicate(andPredicateWithSubpredicates: [query1.predicate, query2.predicate]
                .compactMap { $0 })
        case let .or(query1, query2):
            return NSCompoundPredicate(orPredicateWithSubpredicates: [query1.predicate, query2.predicate]
                .compactMap { $0 })
        case let .not(query):
            return query.predicate.flatMap { NSCompoundPredicate(notPredicateWithSubpredicate: $0) }
        }
    }
}
