//
//  Client.swift
//
//
//  Created by Jeshurun Roach on 9/8/20.
//

import Foundation

public struct Client: Model {
    public let id: UID<Client>
    public let createdAt: Date
    public var name: String
    public var notes: String?

    public var facilities: [UID<Facility>]
    public var primaryContact: Contact

    // MARK: Initializer

    public init(id: UID<Client> = .new,
                createdAt: Date = Date(),
                name: String,
                notes: String? = nil,
                facilities: [UID<Facility>] = .new(2),
                primaryContact: Contact)
    {
        self.id = id
        self.createdAt = createdAt
        self.name = name
        self.notes = notes
        self.facilities = facilities
        self.primaryContact = primaryContact
    }

    public static func mock(id: UID<Client> = .new) -> Client {
        Client(id: id, name: "My Client", primaryContact: .mock(id: .new))
    }
}
