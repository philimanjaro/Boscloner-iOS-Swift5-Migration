//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Foundation

public struct Address: Codable {
    public var street: String
    public var street2: String?
    public var city: String
    public var state: String
    public var country: String
    public var zip: String

    public init(street: String, street2: String? = nil, city: String, state: String, country: String, zip: String) {
        self.street = street
        self.street2 = street2
        self.city = city
        self.state = state
        self.country = country
        self.zip = zip
    }

    public var combined: String {
        "\(street + (street2 != nil ? street2! : "")) \(city), \(state) \(zip), \(country)"
    }
}

public extension Address {
    static let mock = Address(street: "123 Easy Street",
                              street2: nil,
                              city: "Seattle",
                              state: "WA",
                              country: "USA",
                              zip: "98105")
}
