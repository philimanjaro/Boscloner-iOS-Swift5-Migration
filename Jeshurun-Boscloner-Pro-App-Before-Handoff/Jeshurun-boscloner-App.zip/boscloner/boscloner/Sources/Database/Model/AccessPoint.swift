//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Foundation

public struct AccessPoint: Model {
    public let id: UID<AccessPoint>

    /// user defined name for the access point
    public var name: String

    /// Detailed information on the access point
    public var notes: String?

    public var lat: Double?
    public var lng: Double?

//    @ManyToOne(\Facility.accessPoints)
    public var facility: UID<Facility>

//    @ManyToMany(\.unlockedAccessPoints)
    public var enabledBadges: [UID<Badge>]

//    @ManyToMany(\.restrictedAccessPoints)
    public var disabledBadges: [UID<Badge>]

    public init(id: UID<AccessPoint> = .new,
                name: String = "My Access Point",
                notes: String? = "Some Notes",
                lat: Double? = nil,
                lng: Double? = nil,
                facility: UID<Facility> = .new,
                enabledBadges: [UID<Badge>] = .new(3),
                disabledBadges: [UID<Badge>] = .new(2))
    {
        self.id = id
        self.name = name
        self.notes = notes
        self.lat = lat
        self.lng = lng

        self.facility = facility
        self.enabledBadges = enabledBadges
        self.disabledBadges = disabledBadges
    }

    public static func mock(id: UID<AccessPoint> = .new) -> AccessPoint {
        AccessPoint(id: id)
    }
}
