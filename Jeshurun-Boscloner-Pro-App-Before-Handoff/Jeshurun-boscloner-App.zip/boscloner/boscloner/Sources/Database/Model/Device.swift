//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Foundation

public struct Device: Model {
    public let id: UID<Device>

    /// User defined name for the device
    public var name: String?

    /// whether the device is favorited
    public var favorite: Bool

    /// whether the device should be automatically connected
    public var autoconnect: Bool

    public var firmwareVersion: String
    public var hardwareIdentifier: String

    /// bitmask of services available on the device
    public var services: DeviceServices

    public var scanEvents: [UID<ScanEvent>]

    // MARK: Initializer

    public init(id: UID<Device> = .new,
                name: String? = nil,
                favorite: Bool = false,
                autoconnect: Bool = false,
                firmwareVersion: String = "MOCK_FIRMWARE",
                hardwareIdentifier: String = "MOCK_HARDWARE",
                services: DeviceServices = .none,
                scanEvents: [UID<ScanEvent>] = .new(3))
    {
        self.id = id
        self.name = name
        self.favorite = favorite
        self.autoconnect = autoconnect
        self.firmwareVersion = firmwareVersion
        self.hardwareIdentifier = hardwareIdentifier
        self.services = services
        self.scanEvents = scanEvents
    }

    public static func mock(id: UID<Device>) -> Device {
        Device(id: id)
    }
}

public struct DeviceService: RawRepresentable, OptionSet {
    public var rawValue: UInt64

    public init(rawValue: UInt64) { self.rawValue = rawValue }

    public static var none: DeviceService { DeviceService(rawValue: 0) }
}

public struct DeviceServices: RawRepresentable, OptionSet, Hashable {
    public var rawValue: UInt64

    public init(rawValue value: UInt64) {
        rawValue = value
    }
}

public extension DeviceServices {
    static let none: DeviceServices = []

    static let thor: DeviceServices = [
        .discover, .scan,
    ]

    static let passport: DeviceServices = [
        .read, .write, .emulate, .bruteForce,
    ]
}

extension DeviceServices: CaseIterable {
    public static let read = DeviceServices(shift: 0)
    public static let write = DeviceServices(shift: 1)
    public static let discover = DeviceServices(shift: 2)
    public static let scan = DeviceServices(shift: 3)
    public static let bruteForce = DeviceServices(shift: 4)
    public static let emulate = DeviceServices(shift: 5)

    private init(shift: UInt64) {
        rawValue = 1 << shift
    }

    public static var allCases: [DeviceServices] = [
        read, write, discover, scan, bruteForce, emulate,
    ]
}
