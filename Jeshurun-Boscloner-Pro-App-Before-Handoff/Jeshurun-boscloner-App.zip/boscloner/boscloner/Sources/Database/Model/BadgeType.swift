//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Foundation

public struct BadgeType: Identifiable, Codable, Equatable, Hashable {
    public let id: String
    public let name: String

    public let frequency: Frequency

    public let emulatable: Bool
    public let crackable: Bool

    public var encrytped: Bool {
        switch frequency {
        case .high: return true
        case .low: return false
        }
    }

    public init(id: String, name: String, frequency: BadgeType.Frequency, emulatable: Bool, crackable: Bool) {
        self.id = id
        self.name = name
        self.frequency = frequency
        self.emulatable = emulatable
        self.crackable = crackable
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let id = try container.decode(BadgeType.ID.self)
        guard let badgeType = BadgeType.from(id: id) else {
            throw DecodingError.dataCorrupted(.init(codingPath: container.codingPath,
                                                    debugDescription: "Unknown badge type '\(id)'"))
        }
        self = badgeType
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(id)
    }

    public enum Frequency: String, Codable, Equatable {
        case low, high
    }
}

extension BadgeType: CaseIterable {
    public static func from(id: ID) -> BadgeType? {
        index[id]
    }

    public static let allCases: [BadgeType] = [
        proxcard,
        indala,
        em4100,
        iclass,
        mifare,
    ]

    public static let index: [ID: BadgeType] = .init(uniqueKeysWithValues: allCases.map { ($0.id, $0) })

    public static let proxcard = BadgeType(
        id: "proxcard",
        name: "HID ProxCard II",
        frequency: .low,
        emulatable: true,
        crackable: true
    )

    public static let indala = BadgeType(
        id: "indala",
        name: "HID Indala",
        frequency: .low,
        emulatable: false,
        crackable: false
    )

    public static let em4100 = BadgeType(
        id: "em4100",
        name: "EM4100",
        frequency: .low,
        emulatable: true,
        crackable: false
    )

    public static let iclass = BadgeType(
        id: "iclass",
        name: "HID iClass SS",
        frequency: .high,
        emulatable: true,
        crackable: false
    )

    public static let mifare = BadgeType(
        id: "mifare",
        name: "MICARRE Classic",
        frequency: .high,
        emulatable: false,
        crackable: true
    )
}
