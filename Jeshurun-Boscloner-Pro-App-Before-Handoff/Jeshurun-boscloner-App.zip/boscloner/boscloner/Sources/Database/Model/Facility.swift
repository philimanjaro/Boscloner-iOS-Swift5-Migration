//
//  File.swift
//
//
//  Created by rickb on 10/12/20.
//

import CoreLocation
import Foundation

public struct Facility: Model {
    public let id: UID<Facility>

    public var name: String
    public var address: Address?
    public var lat: Double?
    public var lng: Double?
    public var radius: Double?

    public var defaultBadgeType: BadgeType?
    public var facilityBadgeId: String?

    public var notes: String?

//        @ManyToOne(\Client.facilities)
    public var client: UID<Client>

//    @MaybeToMany(\Contact.facility)
    public var contacts: [UID<Contact>]

//    @OneToMany(\Badge.facility)
    public var badges: [UID<Badge>]

//    @OneToMany(\AccessPoint.facility)
    public var accessPoints: [UID<AccessPoint>]

    // MARK: Initializer

    public init(id: UID<Facility> = .new,
                name: String,
                address: Address? = nil,
                lat: Double? = nil,
                lng: Double? = nil,
                radius: Double? = nil,
                defaultBadgeType: BadgeType? = nil,
                facilityBadgeId: String? = nil,
                notes: String? = nil,
                client: UID<Client> = .new,
                contacts: [UID<Contact>] = [],
                badges: [UID<Badge>] = [],
                accessPoints: [UID<AccessPoint>] = [])
    {
        self.id = id
        self.name = name
        self.address = address
        self.lat = lat
        self.lng = lng
        self.radius = radius
        self.defaultBadgeType = defaultBadgeType
        self.facilityBadgeId = facilityBadgeId
        self.notes = notes

        self.client = client
        self.contacts = contacts
        self.badges = badges
        self.accessPoints = accessPoints
    }

    public static func mock(id: UID<Facility>) -> Facility {
        Facility(id: id, name: "My Facility")
    }

    public var coordinate: CLLocationCoordinate2D? {
        guard let lat = lat, let lng = lng else { return nil }
        return CLLocationCoordinate2D(latitude: lat, longitude: lng)
    }
}

/*
 public struct Facility: Identifiable {
 	public let id: UID<Facility>
     public let createdAt: Date
 	public let name: String
     public let notes: String?

     public init(id: ID = ID(), createdAt: Date = Date(), name: String, notes: String? = nil) {
 		self.id = id
         self.createdAt = createdAt
 		self.name = name
         self.notes = notes
 	}
 }
 */
