//
//  File.swift
//
//
//  Created by Jeshurun Roach on 9/8/20.
//

import Foundation

public struct Badge: Model {
    public let id: UID<Badge>
    public var createdAt: Date

    /// The type of the badge
    public var type: BadgeType

    /// the data which the card transmits to readers
    public var payload: Data

    /// A user created name for the badge
    public var name: String?

    /// User's notes on the badge
    public var notes: String?

    /// If set to true, this badge will be hidden from the user.
    public var hidden: Bool = false

    /// The facility that the badge belongs to.
//        @ManyToOne(\Facility.badges)
    public var facility: UID<Facility>

    /// All scan events associated with the badge
//        @OneToMany(\ScanEvent.badge)
    public var scans: [UID<ScanEvent>]

    /// all access points that this badge has been tested to work for
//        @ManyToMany(\AccessPoint.enabledBadges)
    public var unlockedAccessPoints: [UID<AccessPoint>]

    /// all access points that this badge has been tested not to work for
//        @ManyToMany(\AccessPoint.disabledBadges)
    public var restrictedAccessPoints: [UID<AccessPoint>]

    /// All the projects that this badge is saved in
//        @ManyToMany(\Project.savedBadges)
    public var savedInProjects: [UID<Project>]

    // MARK: Initializer

    public init(id: UID<Badge> = .new,
                createdAt: Date = Date(),
                type: BadgeType,
                payload: Data = Data(),
                name: String? = nil,
                notes: String? = nil,
                hidden: Bool = false,
                facility: UID<Facility> = .new,
                scans: [UID<ScanEvent>] = .new(5),
                unlockedAccessPoints: [UID<AccessPoint>] = .new(2),
                restrictedAccessPoints: [UID<AccessPoint>] = .new(5),
                savedInProjects: [UID<Project>] = .new(1))
    {
        self.id = id
        self.createdAt = createdAt
        self.type = type
        self.payload = payload
        self.name = name
        self.notes = notes
        self.hidden = hidden
        self.facility = facility
        self.scans = scans
        self.unlockedAccessPoints = unlockedAccessPoints
        self.restrictedAccessPoints = restrictedAccessPoints
        self.savedInProjects = savedInProjects
    }

    public static func mock(id: UID<Badge> = .new) -> Badge {
        Badge(id: id, type: .proxcard)
    }
}

public extension Badge {
    var defaultName: String {
        "A Badge"
    }
    
    var payloadString: String {
        payload.map {
            String($0, radix: 0xF, uppercase: true)
        }.joined(separator: ":")
    }
    
    func trimmedPayloadString(limit: Int) -> String {
        payload.prefix(limit).map {
            String($0, radix: 0xF, uppercase: true)
        }.joined(separator: ":")
    }
}

/*
 public struct Badge: Identifiable, Codable, Equatable {

 	public let id: UID<Badge>
 	public let data: String
 	public let type: BadgeType
 	public let location: Location?
 	public let name: String
 	public let createdAt: Date
 	public let userNotes: String?
 	public let clientId: UID<Client>?
 	public let projectId: UID<Project>?
 	public let sessionIds: [UID<Session>]

 	public struct Location: Codable, Equatable {
 		public let latitude: Double
 		public let longitude: Double
 	}

 	public init(
 		id: ID = ID(),
 		data: String,
 		type: BadgeType,
 		location: Location?,
 		name: String,
 		createdAt: Date = Date(),
 		userNotes: String?,
 		clientId: UID<Client>?,
 		projectId: UID<Project>?,
 		sessionIds: [UID<Session>]
 	) {
 		self.id = id
 		self.data = data
 		self.type = type
 		self.location = location
 		self.name = name
 		self.createdAt = createdAt
 		self.userNotes = userNotes
 		self.clientId = clientId
 		self.projectId = projectId
 		self.sessionIds = sessionIds
 	}
 }
 */
