//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Foundation

public struct ScanEvent: Model {
    public let id: UID<ScanEvent>
    public var timestamp: Date

    public var lat: Double?
    public var lng: Double?

//    @ManyToMaybe(\Project.scans)
    public var project: UID<Project>?

//    @ManyToOne(\Device.scanEvents)
    public var device: UID<Device>

//    @ManyToOne(\Badge.scans)
    public var badge: UID<Badge>

    // MARK: Initializer

    public init(id: UID<ScanEvent> = .new,
                timestamp: Date = Date(),
                lat: Double? = nil,
                lng: Double? = nil,
                project: UID<Project>? = nil,
                device: UID<Device> = .new,
                badge: UID<Badge> = .new)
    {
        self.id = id
        self.timestamp = timestamp
        self.lat = lat
        self.lng = lng

        self.project = project
        self.device = device
        self.badge = badge
    }

    public static func mock(id: UID<ScanEvent>) -> ScanEvent {
        ScanEvent(id: id)
    }
}
