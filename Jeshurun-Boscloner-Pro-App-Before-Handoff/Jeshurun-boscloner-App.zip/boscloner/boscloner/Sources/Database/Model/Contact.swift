//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Foundation

public struct Contact: Model {
    public let id: UID<Contact>

    public var firstName: String
    public var lastName: String
    public var title: String?
    public var phone: String?
    public var email: String?
    public var photo: Data?
    public var contactsId: String?
    public var notes: String?

    //    @ManyToOne(\Client.contacts)
    public var client: UID<Client>

    //    @ManyToMaybe(\Facility.contacts)
    public var facility: UID<Facility>?

    public init(id: UID<Contact> = .new,
                firstName: String,
                lastName: String,
                title: String?,
                phone: String? = nil,
                email: String? = nil,
                photo: Data? = nil,
                contactsId: String? = nil,
                notes: String? = nil,
                client: UID<Client>,
                facility: UID<Facility>? = nil)
    {
        self.id = id
        self.firstName = firstName
        self.lastName = lastName
        self.title = title
        self.phone = phone
        self.email = email
        self.photo = photo
        self.contactsId = contactsId
        self.notes = notes

        self.client = client
        self.facility = facility
    }

    public static func mock(id: UID<Contact>) -> Contact {
        Contact(id: id, firstName: "Steve", lastName: "Jobs", title: "CEO", client: .new)
    }
}
