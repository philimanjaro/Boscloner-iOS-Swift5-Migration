//
//  File.swift
//
//
//  Created by Jeshurun Roach on 9/8/20.
//

import Foundation

public struct Project: Model {
    public let id: UID<Project>
    public var name: String

    public var lastActive: Date?
    public var createdAt: Date

//    @ManyToMany(\Badge.savedInProjects)
    public var savedBadges: [Badge.ID]

//    @ManyToMaybe(\Client.projects)
    public var client: Client.ID?

    // MARK: - Initializer

    public init(id: Project.ID = .new,
                name: String,
                lastActive: Date? = nil,
                createdAt: Date = Date(),
                savedBadges: [Badge.ID] = [],
                client: Client.ID? = nil)
    {
        self.id = id
        self.name = name
        self.lastActive = lastActive
        self.createdAt = createdAt

        self.savedBadges = savedBadges
        self.client = client
    }

    public static func mock(id: UID<Project>) -> Project {
        return Project(id: id, name: "My Project")
    }
}

/*
 public struct Project: Identifiable {
 	public let id: UID<Project>
 	public let name: String
     public let createdAt: Date

 	public init(id: ID = ID(), name: String, createdAt: Date = Date()) {
 		self.id = id
 		self.name = name
         self.createdAt = createdAt
 	}
 }
 */
