//
//  File.swift
//
//
//  Created by rickb on 10/9/20.
//

import Foundation

public struct UID<Value>: Codable, Hashable {
    public let rawValue: UUID

    public init() {
        rawValue = UUID()
    }

    public init(_ value: UUID) {
        rawValue = value
    }

    public init?(_ value: UUID?) {
        guard let value = value else { return nil }
        rawValue = value
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        rawValue = try container.decode(UUID.self)
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(rawValue)
    }

    public static var new: Self { .init() }
}

public extension Array {
    static func new<T>(_ count: Int, type _: T.Type = T.self) -> [UID<T>] where Element == UID<T> {
        guard count > 0 else { return [] }
        return (0 ..< count).map { _ in UID<T>.new }
    }
}
