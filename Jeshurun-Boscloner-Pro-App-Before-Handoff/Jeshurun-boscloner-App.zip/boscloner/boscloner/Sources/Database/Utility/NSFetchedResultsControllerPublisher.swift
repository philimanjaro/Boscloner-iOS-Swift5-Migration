//
//  File.swift
//
//
//  Created by rickb on 10/10/20.
//

import Combine
import CoreData
import Foundation

struct FetchedResultsSectionInfo<T> {
    let name: String
    let indexTitle: String?
    let objects: [T]
}

struct NSFetchedResultsControllerPublisher<T: NSManagedObject>: Publisher {
    typealias Output = [FetchedResultsSectionInfo<T>]
    typealias Failure = Never

    let controller: NSFetchedResultsController<T>

    func receive<S>(subscriber: S) where S: Subscriber, S.Failure == Failure, S.Input == Output {
        let subscription = NSFetchedResultsControllerSubscription(subscriber: subscriber, controller: controller)
        subscriber.receive(subscription: subscription)
    }
}

final class NSFetchedResultsControllerSubscription<SubscriberType: Subscriber, T: NSManagedObject>: NSObject,
    Subscription,
    NSFetchedResultsControllerDelegate
    where SubscriberType.Input == [FetchedResultsSectionInfo<T>], SubscriberType.Failure == Never
{
    private var subscriber: SubscriberType?
    private var observer: AnyObject?

    let controller: NSFetchedResultsController<T>

    init(subscriber: SubscriberType, controller: NSFetchedResultsController<T>) {
        self.subscriber = subscriber
        self.controller = controller
        super.init()
        controller.delegate = self
    }

    func request(_: Subscribers.Demand) {
        try? controller.performFetch()
        _ = subscriber?.receive(sections())
    }

    func cancel() {
        subscriber = nil
    }

    func controllerDidChangeContent(_: NSFetchedResultsController<NSFetchRequestResult>) {
        _ = subscriber?.receive(sections())
    }

    func sections() -> [FetchedResultsSectionInfo<T>] {
        controller.sections?.map {
            FetchedResultsSectionInfo(name: $0.name, indexTitle: $0.indexTitle, objects: $0.objects as? [T] ?? [])
        } ?? []
    }
}
