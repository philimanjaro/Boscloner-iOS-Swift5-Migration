//
//  File.swift
//
//
//  Created by Jeshurun Roach on 1/5/21.
//

import Foundation

public protocol Model: Identifiable where ID == UID<Self> {
    static func mock(id: UID<Self>) -> Self
}
