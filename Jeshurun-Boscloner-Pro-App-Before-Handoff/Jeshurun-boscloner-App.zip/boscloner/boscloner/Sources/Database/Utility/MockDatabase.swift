//
//  File.swift
//  
//
//  Created by Jeshurun Roach on 3/17/21.
//

import Foundation


public class MockDatabasePopulator {
    
    let database: DatabaseService
    
    public init(database: DatabaseService) {
        self.database = database
    }
    
    public func populate() {
        let contactId = UID<Contact>.new
        let clientId = UID<Client>.new
        let facilityId = UID<Facility>.new
        let badge1Id = UID<Badge>.new
        let scanEventId = UID<ScanEvent>.new
        let deviceId = UID<Device>.new
        
        let contact = Contact(id: contactId, firstName: "James", lastName: "Brown", title: "Manager", client: clientId)
        let client = Client(id: clientId, createdAt: Date(), name: "BestBuy", notes: nil, facilities: [], primaryContact: contact)
        database.create(client: client)
        
        let address = Address(street: "625 Black Lake Blvd SW", street2: "Unit200", city: "Olympia", state: "WA", country: "USA", zip: "98502")
        let facility = Facility(id: facilityId, name: "Capital Mall", address: address, lat: 47.042358, lng: -122.934017, defaultBadgeType: .iclass, client: clientId, contacts: [contactId], badges: [], accessPoints: [])
        database.create(facility: facility)
        
        let device = Device(id: deviceId, name: "My Thor", favorite: true, autoconnect: true, firmwareVersion: "123", hardwareIdentifier: "THOR", services: .thor, scanEvents: [])
        database.save(device: device)
        
        let badge1 = Badge(id: .new, createdAt: Date(), type: .iclass, payload: "123456".data(using: .utf8)!, name: "Security Guard", hidden: false, facility: facilityId, scans: [scanEventId], unlockedAccessPoints: [], restrictedAccessPoints: [], savedInProjects: [])
        database.create(badge: badge1)
        
        let scan = ScanEvent(id: scanEventId, timestamp: Date(), lat: 47.042358, lng: -122.934017, project: nil, device: deviceId, badge: badge1Id)
        
        database.persistentContainer.viewContext
            .create(with: scan)
    }
}
