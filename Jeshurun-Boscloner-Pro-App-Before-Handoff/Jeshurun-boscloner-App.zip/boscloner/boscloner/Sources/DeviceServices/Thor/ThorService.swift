//
//  File.swift
//
//
//  Created by Jeshurun Roach on 2/1/21.
//

import Combine
import Database
import DeviceSupport
import Foundation

public class ThorService {
    @Published public var status: Status = .disconnected
    @Published public var isBusy: Bool = false
    @Published public var scans: [Scan] = []
    @Published public var discoveredBadgeTypes: [BadgeType] = []

    private(set) var device: DeviceManager?

    private var queue = DispatchQueue(label: "boscloner.thor.service")
    private var cancellables = Set<AnyCancellable>()
    private var deviceCancellable: AnyCancellable?
    private var simulatedServiceCancellable: AnyCancellable?

    public init() {
        status = .standby

        #if DEBUG
            cancellables.formUnion(bindDebug())
        #endif
    }

    private init(device: DeviceManager? = nil) {
        set(device: device)
    }

    private func bindDebug() -> Set<AnyCancellable> {
        var bag = Set<AnyCancellable>()

        $status.sink(receiveValue: { print($0.description) })
            .store(in: &bag)

        return bag
    }

    private func set(device: DeviceManager?) {
        guard self.device !== device else { return }
        deviceCancellable?.cancel()
        self.device = device
        guard let device = device else { return }
        deviceCancellable = device.channel.statePublisher
            .flatMap { state -> AnyPublisher<Status, Never> in
                switch state {
                case .connecting:
                    return Just(.connecting)
                        .eraseToAnyPublisher()
                case .connected:
                    return device.$state.map { result -> Status in
                        guard case let .success(state) = result else {
                            try? device.fetch(property: .state)
                            return .connecting
                        }
                        switch state {
                        case .standby:
                            return .standby
                        case .discovery:
                            return .discovery
                        case let .scan(badge):
                            return .scan(badge)
                        default:
                            assertionFailure("invalid status for Thor")
                            return .standby
                        }
                    }.eraseToAnyPublisher()
                case .disconnecting:
                    return Just(.disconnected)
                        .eraseToAnyPublisher()
                case .disconnected:
                    return Just(.disconnected)
                        .eraseToAnyPublisher()
                }
            }.sink { [unowned self] newStatus in
                status = newStatus
            }
    }

    public func cancelSession() -> AnyPublisher<Never, SessionError> {
        if let error = changeSessionError {
            return Fail(error: error)
                .eraseToAnyPublisher()
        }

        guard status.isSession else {
            return Empty(completeImmediately: true).eraseToAnyPublisher()
        }
        isBusy = true

        let handler = Empty<Never, SessionError>(completeImmediately: true)
            .delay(for: 3, scheduler: queue)
            .share()

        handler.sink { [unowned self] _ in
            status = .standby
            isBusy = false
        } receiveValue: { _ in
            // never
        }.store(in: &cancellables)

        return handler
            .eraseToAnyPublisher()
    }

    public func startDiscovery() -> AnyPublisher<Never, SessionError> {
        if let error = changeSessionError {
            return Fail(error: error)
                .eraseToAnyPublisher()
        }

        guard status.isStandby else {
            let message = "cannot start discovery while status is \(status.description)"
            return Fail(error: .busy(message: message))
                .eraseToAnyPublisher()
        }

        simulatedServiceCancellable?.cancel()
        isBusy = true

        let handler = Empty<Never, SessionError>(completeImmediately: true)
            .delay(for: 3, scheduler: queue)
            .share()

        handler.sink { [unowned self] _ in
            status = .discovery
            isBusy = false
            simulateDiscovery()
        } receiveValue: { _ in
            // never
        }.store(in: &cancellables)

        return handler
            .eraseToAnyPublisher()
    }

    public func startScanning(for badgeType: BadgeType, facility: Facility.ID) -> AnyPublisher<Never, SessionError> {
        if let error = changeSessionError {
            return Fail(error: error)
                .eraseToAnyPublisher()
        }

        guard status.isStandby else {
            let message = "cannot start scanning while status is \(status.description)"
            return Fail(error: .busy(message: message))
                .eraseToAnyPublisher()
        }

        simulatedServiceCancellable?.cancel()
        isBusy = true

        let handler = Empty<Never, SessionError>(completeImmediately: true)
            .delay(for: 3, scheduler: queue)
            .share()

        handler.sink { [unowned self] _ in
            status = .scan(badgeType)
            isBusy = false
            simulateScan(for: badgeType, facility: facility)
        } receiveValue: { _ in
            // never
        }.store(in: &cancellables)

        return handler
            .eraseToAnyPublisher()
    }
}

extension ThorService {
    private var changeSessionError: SessionError? {
        if isBusy {
            return .busy(message: nil)
        }

        switch status {
        case .disconnected:
            return .disconnected
        case .connecting:
            return .busy(message: "connecting to device")
        default:
            return nil
        }
    }
}

extension ThorService {
    static var simulatedDiscoveryTypes: [BadgeType] {
        [.em4100, .indala]
    }

    private func simulateDiscovery() {
        simulatedServiceCancellable = Timer
            .publish(every: 4, on: .main, in: .common)
            .autoconnect()
            .scan(-1) { last, _ in last + 1 }
            .scan([BadgeType]()) { list, index in
                guard Self.simulatedDiscoveryTypes.indices.contains(index) else {
                    return list
                }
                return list + [Self.simulatedDiscoveryTypes[index]]
            }
            .removeDuplicates()
            .sink { [unowned self] badgeTypes in
                discoveredBadgeTypes = badgeTypes
            }
    }

    private func simulateScan(for badgeType: BadgeType, facility: Facility.ID?) {
        simulatedServiceCancellable = Timer
            .publish(every: 4, on: .main, in: .common)
            .autoconnect()
            .scan([Scan]()) { list, time in
                if list.count > 5 {
                    self.simulatedServiceCancellable?.cancel()
                }
                let rand = Int.random(in: 0 ..< 12)
                let newTime = time.addingTimeInterval(.init(-60 * rand))
                return list + [Self.mockScanEvent(for: badgeType, facility: facility, time: newTime)]
            }
            .sink { [unowned self] events in
                self.scans = events
            }
    }

    private static func mockScanEvent(for badgeType: BadgeType, facility: Facility.ID?, time: Date) -> Scan {
        let scanId = UID<ScanEvent>.new
        let badge = Badge(
            id: .new,
            createdAt: time,
            type: badgeType,
            payload: Data(),
            name: nil,
            notes: nil,
            hidden: false,
            facility: facility ?? .new,
            scans: [scanId],
            unlockedAccessPoints: [],
            restrictedAccessPoints: [],
            savedInProjects: []
        )
        let event = ScanEvent(id: scanId, timestamp: time, lat: nil, lng: nil, project: nil, device: .new, badge: badge.id)
        return Scan(event: event, badge: badge)
    }
}

public extension ThorService {
    struct Scan {
        public var event: ScanEvent
        public var badge: Badge
    }

    enum Status: CustomStringConvertible, Equatable {
        case disconnected
        case connecting
        case standby
        case discovery
        case scan(BadgeType)

        var isSession: Bool {
            switch self {
            case .discovery, .scan:
                return true
            default:
                return false
            }
        }

        var isStandby: Bool {
            guard case .standby = self else { return false }
            return true
        }

        public var description: String {
            switch self {
            case .disconnected: return "disconnected"
            case .connecting: return "connecting"
            case .standby: return "standby"
            case .discovery: return "discovery"
            case let .scan(badge): return "scan \(badge.name)"
            }
        }
    }

    enum SessionError: Error {
        case disconnected
        case busy(message: String?)
    }
}

public class MockThorService: ThorService {}
