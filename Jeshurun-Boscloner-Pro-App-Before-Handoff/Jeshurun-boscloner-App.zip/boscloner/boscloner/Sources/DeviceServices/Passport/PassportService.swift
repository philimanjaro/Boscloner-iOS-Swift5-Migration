//
//  File.swift
//
//
//  Created by Jeshurun Roach on 2/1/21.
//

import Foundation
import Combine
import Database
import DeviceSupport
import BluetoothSupport


public class PassportService {
    @Published public var status: Status = .disconnected
    @Published public var isBusy: Bool = false
    
    @Published private(set) var device: DeviceManager?
    private var cancellables = Set<AnyCancellable>()
    private var deviceCancellable: AnyCancellable?
    
    public init() {
    }
    
    private init(device: DeviceManager? = nil) {
        
        set(device: device)
    }
    
    private func set(device: DeviceManager?) {
        guard self.device !== device else { return }
        deviceCancellable?.cancel()
        self.device = device
        guard let device = device else { return }
        deviceCancellable = device.channel.statePublisher
            .flatMap { state -> AnyPublisher<Status, Never> in
                switch state {
                case .connecting:
                    return Just(.connecting)
                        .eraseToAnyPublisher()
                case .disconnecting, .disconnected:
                    return Just(.disconnected)
                        .eraseToAnyPublisher()
                case .connected:
                    return device.$badgeId
                        .combineLatest(device.$state) { _id, _state -> Status in
                            switch (_id, _state) {
                            case let (.success(id), .success(state)):
                                switch state {
                                case .bruteForce:
                                    return .bruteForce(id)
                                case .simulate:
                                    return .simulating(id)
                                default:
                                    return .standby
                                }
                            default:
                                try? device.fetch(property: .badgeId)
                                try? device.fetch(property: .state)
                                return .connecting
                            }
                        }.eraseToAnyPublisher()
                }
            }.receive(on: DispatchQueue.main)
            .removeDuplicates()
            .sink { [unowned self] newStatus in
                status = newStatus
            }
    }
    
    public func write(badge: Badge) {
        
    }
    
    public func bruteForce(badge: Badge) {
        
    }
    
    public func simulate(badge: Badge) {
        
    }
    
}


extension PassportService {
    public enum Status: Equatable {
        case disconnected
        case connecting
        case standby
        case write(Badge.ID)
        case simulating(Badge.ID)
        case bruteForce(Badge.ID)
        
        public var isDisconnected: Bool {
            guard case .disconnected = self else { return false }
            return true
        }
        
        public var isConnecting: Bool {
            guard case .connecting = self else { return false }
            return true
        }
        
        public var isStandby: Bool {
            guard case .standby = self else { return false }
            return true
        }
        
        public var isWriting: Bool {
            guard case .write = self else { return false }
            return true
        }
        
        public var isSimulating: Bool {
            guard case .simulating = self else { return false }
            return true
        }
        
        public var isBruteForcing: Bool {
            guard case .bruteForce = self else { return false }
            return true
        }
        
        public var writingBadge: Badge.ID? {
            guard case .write(let badge) = self else { return nil }
            return badge
        }
        
        public var simulatingBadge: Badge.ID? {
            guard case .simulating(let badge) = self else { return nil }
            return badge
        }
        
        public var bruteForcingBadge: Badge.ID? {
            guard case .bruteForce(let badge) = self else { return nil }
            return badge
        }
        
        public var badge: Badge.ID? {
            switch self {
            case .write(let badge): return badge
            case .simulating(let badge): return badge
            case .bruteForce(let badge): return badge
            default: return nil
            }
        }
    }
}
