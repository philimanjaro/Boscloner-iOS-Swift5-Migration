//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/3/20.
//

import BluetoothSupport
import Combine
import DeviceSupport
import Foundation

public extension PassportService {
    static func device(connection: DeviceConnection) -> PassportService {
        BluetoothPassportService(connection: connection,
                                 encoder: .init(delimiters: .default),
                                 decoder: .init(delimiters: .default))
    }
}

private class BluetoothPassportService: PassportService {
    public enum Property: String {
        case battery = "1"
        case name
    }

    let connection: DeviceConnection
    let encoder: BluetoothEncoder
    let decoder: BluetoothDecoder

    private var cancellables = Set<AnyCancellable>()

    private var activeCommands: [String: [PassthroughSubject<BluetoothDecoder.Result, Never>]] = [:]

    @DeviceProperty public var battery: Int?
    @WritableDeviceProperty public var name: String?

    init(connection: DeviceConnection, encoder: BluetoothEncoder, decoder: BluetoothDecoder) {
        self.connection = connection
        self.encoder = encoder
        self.decoder = decoder
        // setup properties
        _battery = DeviceProperty(name: Property.battery,
                                  connection: connection,
                                  encoder: encoder,
                                  decoder: decoder)
        _name = WritableDeviceProperty(name: Property.name,
                                       connection: connection,
                                       encoder: encoder,
                                       decoder: decoder)

        super.init()

        connection.receiveString.compactMap { try? decoder.decode(message: $0) }
            .sink { [unowned self] result in receive(result: result) }
            .store(in: &cancellables)
    }

    private func sink(for property: Property) -> PassthroughSubject<Result<[String], Error>, Never> {
        switch property {
        case .battery:
            return _battery.sink
        case .name:
            return _name.sink
        }
    }

    public func send<Command: DeviceCommand>(command: Command) -> Command.Publisher {
        let subject = PassthroughSubject<BluetoothDecoder.Result, Never>()
        activeCommands[command.name] = [subject] + (activeCommands[command.name] ?? [])

        return subject.tryMap { result -> Command.Response in
            if result.success {
                return try Command.Response(params: result.params)
            } else {
                let error = try Command.Error(params: result.params)
                throw DeviceCommandError<Command>.command(error)
            }
        }.mapError(DeviceCommandError<Command>.convert)
            .eraseToAnyPublisher()
    }

    func send(message: String) throws {
        try connection.send(message: message)
    }

    func receive(result: BluetoothDecoder.Result) {
        switch result.kind {
        case .command:
            guard let subject = activeCommands[result.name]?.popLast() else { return }
            subject.send(result)
            subject.send(completion: .finished)
        case .property:
            guard let property = Property(rawValue: result.name) else { return }
            sink(for: property).send(.success(result.params))
        case .notification:
            break
        }
    }
}
