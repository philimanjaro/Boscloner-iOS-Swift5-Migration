//
//  File.swift
//
//
//  Created by rickb on 11/4/20.
//

import BluetoothSupport
import Foundation

public extension PassportService {
    enum CommandDeviceID: String {
        case hid = "HIDPROX"
        case em4100 = "EM4100"
        case indala = "INDALA"
    }

    struct Wake: BluetoothRequest {
        public var command: String { "PASSPORT,WAKE" }

        public typealias Response = OK
    }

    struct Clone: BluetoothRequest {
        public var command: String { "PASSPORT,\(device.rawValue)_CLONE,\(id)" }

        public let device: CommandDeviceID
        public let id: String

        public typealias Response = OK
    }

    struct Bruteforce: BluetoothRequest {
        public var command: String { "PASSPORT,\(device.rawValue)_BRUTE,\(id),\(iterations)" }

        public let device: CommandDeviceID
        public let id: String
        public let iterations: Int

        public typealias Response = OK
    }

    struct Simulate: BluetoothRequest {
        public var command: String { "PASSPORT,\(device.rawValue)_SIM,\(duration),\(duration)" }

        public let device: CommandDeviceID
        public let id: String
        public let duration: Int

        public typealias Response = OK
    }

    struct Stop: BluetoothRequest {
        public var command: String { "PASSPORT,STP" }

        public typealias Response = OK
    }
}
