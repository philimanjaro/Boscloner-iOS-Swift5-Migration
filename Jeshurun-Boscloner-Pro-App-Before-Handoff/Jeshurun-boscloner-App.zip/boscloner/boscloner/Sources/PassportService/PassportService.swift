//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/3/20.
//

import BluetoothSupport
import Combine
import Foundation

public class PassportService: ObservableObject {
    @Published private(set) var passport: Passport?

    public func connect() -> AnyPublisher<Void, Error> {
        fatalError("PassportService \(#function) must be overridden")
    }

    public func disconnect() -> AnyPublisher<Void, Error> {
        fatalError("PassportService \(#function) must be overridden")
    }

    public func request<Request: BluetoothRequest>(_: Request) -> Request.Publisher {
        fatalError("PassportService \(#function) must be overridden")
    }
}

public extension PassportService {
    func wake() -> AnyPublisher<Void, Error> {
        request(PassportService.Wake()).mapCommand()
    }

    func stop() -> AnyPublisher<Void, Error> {
        request(PassportService.Stop()).mapCommand()
    }

    func clone(device: CommandDeviceID, id: String) -> AnyPublisher<Void, Error> {
        request(PassportService.Clone(device: device, id: id)).mapCommand()
    }

    func bruteforce(device: CommandDeviceID, id: String, iterations: Int) -> AnyPublisher<Void, Error> {
        request(PassportService.Bruteforce(device: device, id: id, iterations: iterations)).mapCommand()
    }

    func simulate(device: CommandDeviceID, id: String, duration: Int) -> AnyPublisher<Void, Error> {
        request(PassportService.Simulate(device: device, id: id, duration: duration)).mapCommand()
    }
}

extension Publisher {
    func mapCommand() -> AnyPublisher<Void, Error> {
        map { _ in }.mapError { $0 as Error }.eraseToAnyPublisher()
    }
}
