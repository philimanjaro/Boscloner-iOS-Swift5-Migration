//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/3/20.
//

import Foundation

public struct Passport {
    public var id: String
    public var state: State = .connecting

    public enum State {
        case connecting
        case disconnecting
        case ready
        case executingCommand
        case bruteForce
    }
}
