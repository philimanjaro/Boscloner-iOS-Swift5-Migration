//
//  File.swift
//
//
//  Created by Jeshurun Roach on 11/3/20.
//

import BluetoothSupport
import Combine
import Foundation

public extension PassportService {
    static func mock() -> PassportService {
        MockPassportService()
    }
}

private class MockPassportService: PassportService {
    override func connect() -> AnyPublisher<Void, Error> {
        fatalError("PassportService \(#function) must be overridden")
    }

    override func disconnect() -> AnyPublisher<Void, Error> {
        fatalError("PassportService \(#function) must be overridden")
    }

    override func request<Request: BluetoothRequest>(_: Request) -> Request.Publisher {
        do {
            return Publishers.just(try Request.Response(string: "OK")).randomDelay()
        } catch {
            return Fail(error: error).randomDelay()
        }
    }
}

extension Publishers {
    static func just<Output, Failure: Error>(_ output: Output) -> AnyPublisher<Output, Failure> {
        Just(output).setFailureType(to: Failure.self).eraseToAnyPublisher()
    }
}

extension Publisher {
    func randomDelay() -> AnyPublisher<Output, Failure> {
        delay(for: .milliseconds(.random(in: 100 ..< 1000)), scheduler: DispatchQueue.main).eraseToAnyPublisher()
    }
}
