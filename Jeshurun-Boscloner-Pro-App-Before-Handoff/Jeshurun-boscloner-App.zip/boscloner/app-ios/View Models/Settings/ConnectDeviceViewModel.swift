//
//  ConnectDeviceViewModel.swift
//  boscloner
//
//  Created by Jeshurun Roach on 3/18/21.
//

import Foundation
import Combine

class ConnectDeviceViewModel: ObservableObject {
    @Dependency(\.connectionManager) var connectionManager
    
    var cancellables = Set<AnyCancellable>()
    
    init() {
        connectionManager.objectWillChange
            .sink(receiveValue: self.objectWillChange.send)
            .store(in: &cancellables)
    }
    
}
