//
//  DevicesViewModel.swift
//  boscloner
//
//  Created by Jeshurun Roach on 2/23/21.
//

import Combine
import Database
import Foundation
import DeviceSupport
import BluetoothSupport

protocol DevicesViewModelInterface: ObservableObject {
    var savedDevices: [Device] { get }
    var nearbyDevices: [BluetoothConnectionManager.DeviceInfo] { get }
}

class DevicesViewModel: ObservableObject, DevicesViewModelInterface {
    @Published var savedDevices: [Device] = []
    @Published var nearbyDevices: [BluetoothConnectionManager.DeviceInfo] = []
    
    @Published var thor: DeviceManager?
    @Published var passport: DeviceManager?
    
    @Dependency(\.database) private var database
    

    private var cancellables = Set<AnyCancellable>()

    init() {
        fetchDevices()
    }

    private func fetchDevices() {
        savedDevices = database.devices()
//        database.devices(query: .favorite)
//            .sink { [unowned self] devices in
//                savedDevices = devices
//            }.store(in: &cancellables)
    }
}

class MockDevicesViewModel: ObservableObject, DevicesViewModelInterface {
    @Published var savedDevices: [Device] = []
    @Published var nearbyDevices: [BluetoothConnectionManager.DeviceInfo] = []
    
    @Published var thor: DeviceManager?
    @Published var passport: DeviceManager?
    
    init() {
        fetchDevices()
        fetchNearbyDevices()
    }

    func fetchDevices() {
        savedDevices = [
            Device(id: .new, name: "My Thor", favorite: true, autoconnect: true, firmwareVersion: "v1.24.21", hardwareIdentifier: "THOR", services: .thor, scanEvents: []),
            Device(id: .new, name: "My Passport", favorite: true, autoconnect: true, firmwareVersion: "v2.21.5", hardwareIdentifier: "PASSPORT", services: .passport, scanEvents: []),
        ]
    }
    
    func fetchNearbyDevices() {
        nearbyDevices = [
            .mock(name: "Nearby Thor Device"),
            .mock(name: "Nearby Passport Device"),
            .mock(name: "Another Nearby Device")
        ]
    }
}

