//
//  LibraryViewModel.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 12/10/20.
//

import Combine
import Database
import Foundation
import SwiftUI

public class LibraryViewModel: ObservableObject {
    // Typealias for New Models
    //  typealias Facility = Models.Facility

    private enum Constant {
        static let numberOfRecentProjects = 3
        static let recentProjectsKey = "RecentProjects"
    }

    @Published var clients = [Client]()
    @Published var projects = [Project]()
    @Published var recentProjects = [Project]()
    @Published var facilities = [Facility]()
    @Published var contacts = [Contact]()
    @Published var accessPoints = [AccessPoint]()
    @Published var badges = [Badge]()

    private var cancellables = Set<AnyCancellable>()

    let database: DatabaseService

    init(database: DatabaseService) {
        self.database = database
        fetchRecentProjects()
        fetchClients()
        fetchFacilities()
        fetchContacts()
        fetchBadges()
        fetchAccessPoints()
    }

    // MARK: - DATA

    func fetchRecentProjects() {
        guard let recentProjectIDs =
            UserDefaults.standard.stringArray(forKey: Constant.recentProjectsKey) else { return }
        for projectID in recentProjectIDs {
            if let project = database.project(with: Project.ID(UUID(uuidString: projectID))) {
                recentProjects.append(project)
            }
        }
    }

    func rememberRecentProject(_ project: Project) {
        var recentProjectIDs = [project.id.rawValue.uuidString]
        if let projectIDs = UserDefaults.standard.stringArray(forKey: Constant.recentProjectsKey) {
            for (index, projectID) in projectIDs.enumerated() where index < Constant.numberOfRecentProjects - 1 {
                recentProjectIDs.append(projectID)
            }
        }
        UserDefaults.standard.set(recentProjectIDs, forKey: Constant.recentProjectsKey)
    }

    func deleteClient(at offsets: IndexSet) {
        for offset in offsets {
            database.delete(with: clients[offset].id)
        }
        fetchClients()
    }

    func fetchClients() {
        clients = database.clients()
    }

    func fetchProjects(for client: Client) {
        database.projects(for: client)
            .map { $0 }
            .assign(to: \.projects, on: self)
            .store(in: &cancellables)
    }

    func createProject(name: String, for client: Client) {
        database.create(project: Project(name: name), for: client)
    }

    func deleteProject(for client: Client, at offsets: IndexSet) {
        for offset in offsets {
            database.delete(with: projects[offset].id)
        }
        fetchProjects(for: client)
    }

    func fetchFacilities() {
        facilities = mockedFacilities()
    }

    func fetchContacts() {
        contacts = mockedContacts()
    }

    func fetchBadges() {
        badges = mockedBadges()
    }

    func fetchAccessPoints() {
        accessPoints = mockedAccessPoints()
    }
}
