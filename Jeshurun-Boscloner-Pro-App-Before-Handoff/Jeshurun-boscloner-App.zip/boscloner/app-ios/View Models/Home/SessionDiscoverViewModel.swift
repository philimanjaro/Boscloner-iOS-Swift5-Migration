//
//  SessionDiscoverViewModel.swift
//  boscloner
//
//  Created by Ryan McHugh on 2/3/21.
//

import Combine
import Database
import DeviceServices
import Foundation

class SessionDiscoverViewModel: ObservableObject {
    @Published var nearbyBadgeTypeIndicies = Set<Int>()
    @Published var facilities = [Facility]()

    @Published var selectedFacility: Facility?
    @Published var isScanning: Bool = false
    @Published var errorMessage: String = ""

    @Published var recentFacilities = [Facility]()

    let badgeTypes: [BadgeType] = BadgeType.allCases

    var closestFacility: Facility? {
        facilities.sorted { first, second in
            guard let first = first.coordinate else { return false }
            guard let second = second.coordinate else { return true }
            guard let firstDist = locationService.distance(from: first) else { return false }
            guard let secondDist = locationService.distance(from: second) else { return true }
            return firstDist < secondDist
        }.first
    }
    
    var client: Client? {
        guard let facility = selectedFacility else { return nil }
        return database.client(with: facility.client)
    }

    var sortedBadgeTypes: [Int] {
        badgeTypes.enumerated().compactMap { $0.offset }.sorted { first, second in
            var isDefault = false
            if let defaultType = selectedFacility?.defaultBadgeType {
                isDefault = badgeTypes[second] == defaultType && badgeTypes[first] != defaultType
            }
            return nearbyBadgeTypeIndicies.contains(first) && !nearbyBadgeTypeIndicies.contains(second)
                && !isDefault
        }
    }

    // TODO: Add @Dependency Property Wrapper
    // Dependencies
    @Dependency(\.database) var database: DatabaseService
    @Dependency(\.thorService) var thorService: ThorService
    @Dependency(\.locationService) var locationService: LocationService

    private var cancellables = Set<AnyCancellable>()

    init() {
        fetchFacilities()

        watchThorService()

        $selectedFacility.sink { [unowned self] in
            guard let facility = $0 else { return }
            self.updateRecentFacilties(facility: facility)
        }.store(in: &cancellables)
    }

    func initialize() {}

    func destruct() {
        if isScanning {
            thorService.cancelSession()
                .sink {
                    Helpers.shared.onError($0)
                } receiveValue: { _ in }
                .store(in: &cancellables)
        }
    }

    // MARK: CRUD

    func fetchFacilities() {
        database.facility()
            .sink { [unowned self] f in
                facilities = f
            }.store(in: &cancellables)
    }

    func fetchNearbyBadgeTypes() {
        guard !isScanning else {
            // cannot instantiate Never
            // Can send Void
            thorService.cancelSession()
                .sink(receiveCompletion: Helpers.shared.onError) { _ in }
                .store(in: &cancellables)
            return
        }

        thorService.startDiscovery()
            .sink(receiveCompletion: Helpers.shared.onError) { _ in }
            .store(in: &cancellables)
    }

    func fetchRecentFaciltiies() {
        guard let recentFacilityIDs = UserDefaults.standard.stringArray(forKey: "RecentFacilities") else { return }
        recentFacilities = recentFacilityIDs.compactMap {
            database.facility(with: Facility.ID(UUID(uuidString: $0)))
        }
    }

    func updateRecentFacilties(facility: Facility) {
        recentFacilities = recentFacilities.filter { $0.id != facility.id }
        recentFacilities.insert(facility, at: 0)
        if recentFacilities.count > 2 {
            recentFacilities.removeLast()
        }
        let persistForm = recentFacilities.compactMap { $0.id.rawValue.uuidString }
        UserDefaults.standard.set(persistForm, forKey: "RecentFacilities")
    }

    func watchThorService() {
        thorService.$status
            .sink { [unowned self] status in
                DispatchQueue.main.async {
                    switch status {
                    case .discovery:
                        self.isScanning = true
                        self.errorMessage = ""
                    case .disconnected:
                        self.errorMessage = "Thor is not connected."
                        self.isScanning = false
                    case .connecting:
                        self.errorMessage = "Thor is connecting..."
                        self.isScanning = false
                    default:
                        self.errorMessage = ""
                        self.isScanning = false
                    }
                }
            }.store(in: &cancellables)

        thorService.$isBusy
            .sink { [unowned self] isBusy in
                if isBusy {
                    self.errorMessage = "Waiting for Thor to respond..."
                }
            }.store(in: &cancellables)

        thorService.$discoveredBadgeTypes
            .sink { [unowned self] nearbyBadges in
                nearbyBadges.forEach {
                    guard let index = self.badgeTypes.firstIndex(of: $0) else { return }
                    self.nearbyBadgeTypeIndicies.insert(index)
                }
            }.store(in: &cancellables)
    }

    // MARK: Convenience Functions

    func isDefaultBadgeType(_ index: Int) -> Bool {
        guard let defaultBadgeType = selectedFacility?.defaultBadgeType,
              index < badgeTypes.count else { return false }
        return badgeTypes[index] == defaultBadgeType
    }
}
