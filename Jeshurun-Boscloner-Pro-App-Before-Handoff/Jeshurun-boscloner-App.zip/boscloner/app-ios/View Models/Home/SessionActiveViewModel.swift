//
//  SessionActiveViewModel.swift
//  boscloner
//
//  Created by Ryan McHugh on 2/9/21.
//

import Combine
import Database
import DeviceServices
import Foundation
import SwiftUI

class SessionActiveViewModel: ObservableObject {
    @Published var stats = [Statistic]()
    @Published var nearbyBadges = [Badge]()
    @Published var isScanning = false

    @Dependency(\.thorService) var thorService

    private var sessionTimer = SessionTimer()

    private var cancellables = Set<AnyCancellable>()
    private var initCancellables = Set<AnyCancellable>()

    init() {
        fetchNearbyBadges()
    }

    func initialize(badgeType: BadgeType, facility: Facility.ID) {
        thorService.$status
            .sink { [unowned self] status in
                DispatchQueue.main.async {
                    self.isScanning = status == .scan(badgeType)
                    if !isScanning {
                        startScanning(badgeType: badgeType, facility: facility)
                    } else if sessionTimer.startDate == nil {
                        sessionTimer.start()
                    }
                }
            }
            .store(in: &initCancellables)

        sessionTimer.$interval
            .sink { [unowned self] interval in
                self.fetchStats(duration: interval, badgeType: badgeType)
            }
            .store(in: &initCancellables)
    }

    func destruct() {
        thorService.cancelSession()
            .sink(receiveCompletion: Helpers.shared.onError) { _ in }
            .store(in: &cancellables)

        initCancellables.forEach { $0.cancel() }

        nearbyBadges = [Badge]()
        stats = [Statistic]()
        sessionTimer.stop()
    }

    func startScanning(badgeType: BadgeType, facility: Facility.ID) {
        thorService.startScanning(for: badgeType, facility: facility)
            .sink(receiveCompletion: Helpers.shared.onError) { _ in }
            .store(in: &cancellables)
    }

    // MARK: CRUD

    func fetchStats(duration: TimeInterval, badgeType: BadgeType) {
        stats = [
            .init(.duration, val: Int(duration.rounded())),
            .init(.badgesDiscovered, val: nearbyBadges.count),
            .init(.newBadges, val: "1"),
            .init(.badgeType, val: badgeType.name),
        ]
    }

    func fetchNearbyBadges() {
        thorService.$scans
            .sink { [unowned self] in
                let ret = $0.compactMap { scan in
                    scan.badge
                }.sorted { first, second in
                    first.createdAt > second.createdAt
                }
                withAnimation { self.nearbyBadges = ret }
            }
            .store(in: &cancellables)
    }
}

extension SessionActiveViewModel {
    public struct Statistic {
        let id = UUID()
        let info: Info
        let name: String
        let value: Text
        let systemImage: String

        init(_ info: Info, val: String) {
            let stat = info.toStatistic(val)
            self.info = info
            name = stat.name
            value = stat.value
            systemImage = stat.systemImage
        }

        init(_ info: Info, val: Int) {
            self.init(info, val: String(val))
        }

        init(info: Info, name: String, value: Text, systemImage: String) {
            self.info = info
            self.name = name
            self.value = value
            self.systemImage = systemImage
        }

        public enum Info: String {
            case duration = "Duration"
            case badgesDiscovered = "Discovered"
            case newBadges = "New Badges"
            case badgeType = "Badge Type"

            func toStatistic(_ val: String) -> Statistic {
                var modifiedVal = Text(val)
                var image = ""

                switch self {
                case .duration:
                    image = "clock"
                    if let val = Int(val), val >= 60 {
                        modifiedVal = Text("\(val / 60) min ") + Text("\(val % 60) s")
                    } else {
                        modifiedVal = Text("\(val) s")
                    }
                case .badgesDiscovered:
                    image = "magnifyingglass"
                    if let val = Int(val), val <= 1 {
                        modifiedVal = Text("\(val) badge")
                    } else {
                        modifiedVal = Text("\(val) badges")
                    }
                case .newBadges:
                    image = "seal"
                    if let val = Int(val), val <= 1 {
                        modifiedVal = Text("\(val) badge")
                    } else {
                        modifiedVal = Text("\(val) badges")
                    }
                case .badgeType:
                    image = "dot.radiowaves.left.and.right"
                }
                return Statistic(info: self,
                                 name: rawValue,
                                 value: modifiedVal,
                                 systemImage: image)
            }
        }
    }
}

extension SessionActiveViewModel {
    class SessionTimer: ObservableObject {
        @Published var startDate: Date?
        @Published var interval: TimeInterval = 0
        @Published var text: String = "doing nothing"
        private let timer: Timer.TimerPublisher = Timer.publish(every: 1, on: .main, in: .default)
        private var timerCancellable: AnyCancellable?

        init() {
            bindTimer()
        }

        private func bindTimer() {
            timer.combineLatest($startDate)
                .handleEvents(receiveOutput: { self.text = "out: \($0)" }, receiveCancel: { self.text = "cancelled" })
                .map { time, start in
                    guard let start = start else { return 0 }
                    return time.timeIntervalSince(start)
                }.assign(to: &$interval)
        }

        func start() {
            text = "start"
            timerCancellable?.cancel()
            startDate = startDate ?? Date()

            timerCancellable = timer.connect() as? AnyCancellable
        }

        func stop() {
            text = "stop"
            startDate = nil
            timerCancellable?.cancel()
        }

        func reset() {
            text = "reset"
            stop()
            startDate = nil
        }
    }
}
