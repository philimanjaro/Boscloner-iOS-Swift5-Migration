//
//  FacilityDetailsView.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 1/13/21.
//

import Combine
import Foundation
import Database

class FacilityDetailsViewModel: ObservableObject {
    @Published var contacts = [Contact]()
    @Published var badges = [Badge]()
    @Published var accessPoints = [AccessPoint]()

    private var cancellables = Set<AnyCancellable>()

    @Dependency(\.database) var database: DatabaseService
    
    var facility: Facility? {
        didSet {
            if oldValue?.id != facility?.id {
                facilityUpdated()
            }
        }
    }
    var client: Client?
    
    init() {}
    
    private func facilityUpdated() {
        if facility != nil {
            fetchClient()
            fetchContacts()
            fetchBadges()
            fetchAccessPoints()
        } else {
            contacts = []
            badges = []
            accessPoints = []
            client = nil
        }
    }

    // MARK: - DATA
    
    func fetchClient() {
        guard let facility = facility else { return }
        client = database.client(with: facility.client)
    }

    func fetchContacts() {
        // 
    }

    func fetchBadges() {
        guard let facility = facility else { return }
        database
            .badges(query: .facility(facility.id))
            .receive(on: DispatchQueue.main)
            .sink { [unowned self] badges in
                self.badges = badges
            }.store(in: &cancellables)
    }

    func fetchAccessPoints() {
        // todo
    }
}
