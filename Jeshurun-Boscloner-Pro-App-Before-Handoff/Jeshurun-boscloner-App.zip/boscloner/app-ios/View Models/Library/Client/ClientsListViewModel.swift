//
//  LibraryViewModel.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 12/10/20.
//

import Combine
import Database
import Foundation

class ClientsListViewModel: ObservableObject {
    @Published var clients = [Client]()

    private var cancellables = Set<AnyCancellable>()

    let database: DatabaseService

    init(database: DatabaseService) {
        self.database = database

        database.clientsPublisher().assign(to: &$clients)
    }

    // MARK: - DATA

    func createClient(name: String,
                      notes: String?,
                      contactFirstName: String,
                      contactLastName: String,
                      contactTitle: String?,
                      contactPhone: String,
                      contactEmail: String)
    {
        let clientId = Client.ID.new
        let contact = Contact(firstName: contactFirstName,
                              lastName: contactLastName,
                              title: contactTitle,
                              phone: contactPhone,
                              email: contactEmail,
                              photo: nil,
                              contactsId: nil,
                              notes: nil,
                              client: clientId,
                              facility: nil)

        let client = Client(id: clientId,
                            name: name,
                            notes: notes,
                            primaryContact: contact)

        database.create(client: client)
    }

    func deleteClient(at offsets: IndexSet) {
        for offset in offsets {
            database.delete(with: clients[offset].id)
        }
    }
}
