//
//  ClientDetailsViewModel.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 1/13/21.
//

import Combine
import Database

class ClientDetailsViewModel: ObservableObject {
    @Published var facilities = [Facility]()
    @Published var contacts = [Contact]()

    private var cancellables = Set<AnyCancellable>()

    @Published var client: Client
    let database: DatabaseService

    init(client: Client, database: DatabaseService) {
        self.database = database
        self.client = client

        database.clientPublisher(with: client.id)
            .compactMap { $0 }
            .assign(to: &$client)
    }

    func update(client: Client) {
        let text = """
            Should not be updating view model with different client!
            Create a new view model.
        """
        assert(self.client.id == client.id, text)
        self.client = client
    }

    // MARK: - DATA

    func fetchFacilities() {
        database.facility(for: client.id)
            .compactMap { print($0); return $0 }
            .assign(to: &$facilities)
    }

    func fetchContacts() {
        contacts = mockedContacts()
    }
}
