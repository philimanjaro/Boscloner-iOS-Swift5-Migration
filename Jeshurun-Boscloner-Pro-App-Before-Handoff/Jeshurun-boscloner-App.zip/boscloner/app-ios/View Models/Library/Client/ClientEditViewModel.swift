//
//  ClientEditViewModel.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 1/14/21.
//

import Combine
import Database
import Foundation

class ClientEditViewModel: ObservableObject {
    let database: DatabaseService
    var client: Client?
    var contact: Contact? { client?.primaryContact }

    private var cancellables = Set<AnyCancellable>()

    init(client: Client?, database: DatabaseService) {
        self.client = client
        self.database = database
    }

    // MARK: - DATA

    private func createClient(name: String,
                              notes: String?,
                              contactFirstName: String,
                              contactLastName: String,
                              contactTitle: String?,
                              contactPhone: String,
                              contactEmail: String)
    {
        let clientId = Client.ID.new
        let contact = Contact(firstName: contactFirstName,
                              lastName: contactLastName,
                              title: contactTitle,
                              phone: contactPhone,
                              email: contactEmail,
                              photo: nil,
                              contactsId: nil,
                              notes: nil,
                              client: clientId,
                              facility: nil)

        let client = Client(id: clientId,
                            name: name,
                            notes: notes,
                            primaryContact: contact)

        database.create(client: client)

        self.client = client
    }

    func delete(_ client: Client) {
        database.delete(with: client.id)
    }

    func save(name: String,
              notes: String?,
              contactFirstName: String,
              contactLastName: String,
              contactTitle: String?,
              contactPhone: String,
              contactEmail: String)
    {
        guard var client = client else {
            createClient(name: name,
                         notes: notes,
                         contactFirstName: contactFirstName,
                         contactLastName: contactLastName,
                         contactTitle: contactTitle,
                         contactPhone: contactPhone,
                         contactEmail: contactEmail)
            return
        }

        client.primaryContact.firstName = contactFirstName
        client.primaryContact.lastName = contactLastName
        client.primaryContact.phone = contactPhone
        client.primaryContact.email = contactEmail

        client.name = name
        client.notes = notes
        database.save(client: client)
    }
}
