//
//  ThorController.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import Combine
import Database
import Foundation

enum ThorState {
    case offline, online, discovery, capture(BadgeType)
}

class ThorManager: ObservableObject {
    @Published var state: ThorState = .offline

    @Published var capturedCards: [Badge] = []

    private var cancellables: Set<AnyCancellable> = .init()

    init() {
        $state.map { state -> AnyPublisher<Badge, Never> in
            switch state {
            case .discovery:
                let card = Badge.mock()
                return Just(card)
                    .delay(for: .seconds(3), scheduler: DispatchQueue.main)
                    .eraseToAnyPublisher()
            case let .capture(badgeType):
                return Timer.publish(every: 5, on: .main, in: .common)
                    .autoconnect()
                    .map { _ in
                        var badge = Badge.mock()
                        badge.type = badgeType
                        return badge
                    }.eraseToAnyPublisher()
            default:
                return Empty().eraseToAnyPublisher()
            }
        }.switchToLatest().handleEvents(receiveOutput: { [unowned self] card in
            if case let .capture(cardType) = self.state, cardType.id == card.type.id { return }
            self.state = .capture(card.type)
        }).sink(receiveValue: { [unowned self] nextCard in
            self.capturedCards.append(nextCard)
        }).store(in: &cancellables)
    }
}
