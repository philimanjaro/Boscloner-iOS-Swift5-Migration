//
//  HomePage.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import SwiftUI

struct HomePage: View {
    @State var isCardLoaded: Bool = true

    var body: some View {
//        ScrollView {
//            VStack(alignment: .leading) {
        ////                PassportView()
        ////                Spacer()
        ////                ThorView()
//                Navigation
//            }.padding()
//        }
        NavigationView {
            SessionDiscoverView()
        }.navigationViewStyle(StackNavigationViewStyle())
    }
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}
