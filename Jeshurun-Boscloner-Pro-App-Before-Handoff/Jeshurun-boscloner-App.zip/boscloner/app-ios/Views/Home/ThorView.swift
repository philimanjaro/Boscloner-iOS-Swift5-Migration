//
//  ThorView.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import Database
import SwiftUI

extension ThorState {
    typealias BadgeType = Database.BadgeType
    var text: String {
        switch self {
        case .offline: return "Offline"
        case .online: return "Online"
        case .discovery: return "Discovery"
        case let .capture(type): return type.name
        }
    }

    var textColor: Color {
        switch self {
        case .offline: return .white
        case .online: return .white
        case .discovery: return .white
        case .capture: return .white
        }
    }

    var color: Color {
        switch self {
        case .offline: return .gray
        case .online: return .green
        case .discovery: return .purple
        case .capture: return .blue
        }
    }
}

struct CapturedCard {
    var id = UUID()

    var timestamp = Date()
    var encryped: Bool

    var progress: Float
    var finished: Bool { progress >= 1 }
}

struct ThorView: View {
    @EnvironmentObject var thorManager: ThorManager
    @EnvironmentObject var passportManager: PassportManager

    var state: ThorState {
        get { thorManager.state }
        nonmutating set { thorManager.state = newValue }
    }

    @State var showingCard: Badge?

    @ViewBuilder
    var body: some View {
        headerView

//        LazyVGrid(
//            columns: [
//                GridItem(.flexible(), spacing: 16),
//                GridItem(.flexible(), spacing: 16),
//            ],
//            spacing: 16,
//            content: {
//                ForEach(Array(thorManager.capturedCards.enumerated()), id: \.0.self) { _, card in
//                    CardClipView(card: card)
//                        .onTapGesture { showingCard = card }
//                }
//            }
//        ).sheet(item: $showingCard) { card in
//            NavigationView {
//                BadgeDetailsView(badge: card)
//            }.environmentObject(passportManager)
//        }
    }

    var headerView: some View {
        HStack {
            Text("Thor")
                .bold()
                .font(.largeTitle)
            Text(state.text)
                .bold()
                .animation(.easeIn)
                .foregroundColor(state.textColor)
                .padding(.vertical, 4).padding(.horizontal, 12)
                .background(
                    Capsule().foregroundColor(state.color)
                )
            Spacer()
            optionsPicker.buttonStyle(ButtonStyling())
        }
    }

    @State var isShowingMenu: Bool = false

    @ViewBuilder
    var optionsPicker: some View {
        switch state {
        case .offline:
            Button("Go Online") {
                withAnimation {
                    state = .online
                }
            }
        default:
            Button("Pick Mode") { isShowingMenu = true }
                .actionSheet(isPresented: $isShowingMenu, content: {
                    ActionSheet(
                        title: Text("Capture Mode"),
                        message: Text("Choose a mode to capture with"),
                        buttons: [
                            .default(Text("Discovery"), action: { withAnimation { state = .discovery } }),
                        ]
                            + BadgeType.allCases.map { card -> ActionSheet.Button in
                                .default(Text(card.name), action: { withAnimation { state = .capture(card) } })
                            }
                            + [
                                .cancel(Text("Cancel")),
                                .destructive(Text("None"), action: { withAnimation { state = .online } }),
                            ]
                    )
                })
        }
        Text("Placeholder")
    }

    struct ButtonStyling: ButtonStyle {
        func makeBody(configuration config: Configuration) -> some View {
            config.label
                .foregroundColor(.white)
                .padding(.vertical, 4).padding(.horizontal, 12)
                .background(
                    Capsule().foregroundColor(.gray)
                )
        }
    }
}

struct ThorView_Previews: PreviewProvider {
    static var previews: some View {
        ThorView()
    }
}
