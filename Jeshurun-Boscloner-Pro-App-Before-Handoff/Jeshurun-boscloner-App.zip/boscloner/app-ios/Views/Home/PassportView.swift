//
//  PassportView.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import Database
import SwiftUI

enum PassportState {
    case offline, online, loaded(Badge), emulating(Badge)

    var isOffline: Bool {
        guard case .offline = self else { return false }
        return true
    }

    var isEmulating: Bool {
        guard case .emulating = self else { return false }
        return true
    }
}

extension PassportState {
    var text: String {
        switch self {
        case .emulating: return "Emulating"
        case .online, .loaded: return "Online"
        case .offline: return "Offline"
        }
    }

    var color: Color {
        switch self {
        case .emulating: return .blue
        case .online, .loaded: return .green
        case .offline: return .gray
        }
    }

    var textColor: Color {
        switch self {
        case .emulating: return .white
        case .online, .loaded: return .white
        case .offline: return .white
        }
    }
}

struct PassportView: View {
    @EnvironmentObject var passportManager: PassportManager

    @State var writeCardPopupEnabled: Bool = false
    @State var bruteForcePopup: Bool = false

    var state: PassportState {
        get { passportManager.state }
        nonmutating set { passportManager.state = newValue }
    }

    var body: some View {
        VStack(alignment: .leading) {
            headerView
                .padding(.vertical, 16)
            card
                .padding(.vertical, 16)
            actionView.padding(.bottom, 18)
        }
    }

    var headerView: some View {
        HStack {
            Text("Passport")
                .bold()
                .font(.largeTitle)
            Text(state.text)
                .bold()
                .foregroundColor(state.textColor)
                .padding(.vertical, 4).padding(.horizontal, 12)
                .background(
                    Capsule().foregroundColor(state.color)
                )
        }
    }

    @ViewBuilder
    var actionView: some View {
        if let card = passportManager.activeCard {
            HStack {
                if card.type.emulatable {
                    if passportManager.state.isEmulating {
                        Button("Stop Emulating") { state = .loaded(card) }
                    } else {
                        Button("Emulate") { state = .emulating(card) }
                    }
                }
                Spacer()
                if card.type.crackable {
                    Button("Brute-Force") { bruteForcePopup = true }
                        .sheet(isPresented: $bruteForcePopup) {
                            Text("Staring brute force... Hold Passport next to reader!")
                        }
                }
                Spacer()
                Button("Write") { writeCardPopupEnabled = true }
                    .sheet(isPresented: $writeCardPopupEnabled) {
                        Text("Place your writable card over the passport to write!")
                    }
            }.buttonStyle(ActionButtonStyling())
        } else {
            EmptyView()
        }
    }

    @ViewBuilder
    var card: some View {
        if let card = passportManager.activeCard {
            CardView(card: card)
        } else {
            emptyCardView
        }
    }

    var emptyCardView: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16)
                .strokeBorder(Color.secondary,
                              style: StrokeStyle(lineWidth: 3, dash: [10]))
                .aspectRatio(1.7, contentMode: .fill)
                .opacity(0.4)
            Text(state.isOffline ? "Connect a passport!" : "Select a card")
                .bold()
                .font(.title3)
                .foregroundColor(.blue)
                .onTapGesture { state = .online }
        }
    }

    struct ActionButtonStyling: ButtonStyle {
        func makeBody(configuration: Configuration) -> some View {
            configuration.label
                .font(.headline)
                .foregroundColor(.blue)
                .padding(.vertical, 8).padding(.horizontal, 16)
                .background(Capsule().foregroundColor(.gray).opacity(0.4))
        }
    }
}

struct PassportView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            PassportView()
            PassportView()
            PassportView()
            PassportView()

        }.frame(width: 200)
            .previewLayout(.sizeThatFits)
    }
}
