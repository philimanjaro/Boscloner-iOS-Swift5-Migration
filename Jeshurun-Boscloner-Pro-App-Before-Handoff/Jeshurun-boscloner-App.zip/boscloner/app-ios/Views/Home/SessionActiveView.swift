//
//  SessionActiveView.swift
//  boscloner
//
//  Created by Ryan McHugh on 2/9/21.
//

import Database
import SwiftUI

struct SessionActiveView: View {
    @Environment(\.presentationMode) var presentationMode
    typealias ViewModel = SessionActiveViewModel
    @StateObject var viewModel = ViewModel()

    @State private var isAlertShown = false
    @State private var isSheetShown = false
    @State private var badgeTapped: Badge?

    // Animation
    @State private var isAppearing = true

    public var badgeType: BadgeType
    public var facility: Facility.ID
    
    var body: some View {
        List {
            statsSection
            thorSection
            nearbyBadgesSection
        }
        .listStyle(InsetGroupedListStyle())
        .navigationBarItems(leading: stopButton)
        .navigationBarBackButtonHidden(true)
        .navigationTitle("Active Session")
        .alert(isPresented: $isAlertShown) { stopAlert }
        .sheet(isPresented: $isSheetShown) { sheetContent }
        .onAppear {
            viewModel.initialize(badgeType: badgeType, facility: facility)
        }.preference(key: IsScanningPreference.self, value: true)
    }
}

// MARK: MISC

extension SessionActiveView {
    var stopButton: some View {
        Button(action: toggleAlert) {
            Text("Stop")
                .foregroundColor(.red)
        }
    }

    func toggleAlert() {
        isAlertShown.toggle()
    }

    func stopAction() {
        print("Stopping...")
        viewModel.destruct()
        presentationMode.wrappedValue.dismiss()
    }

    var stopAlert: Alert {
        Alert(title: Text("Stop Session"),
              message: Text("Are you sure you want to stop scanning for badges?"),
              primaryButton: .default(Text("Yes"), action: stopAction),
              secondaryButton: .cancel())
    }

    @ViewBuilder var sheetContent: some View {
        if let badge = badgeTapped {
            BadgeDetailsView(badge: badge)
        } else {
            EmptyView()
        }
    }
}

// MARK: Sections

extension SessionActiveView {
    var statsSection: some View {
        let header = HStack {
            Text("Stats")
            Spacer()
        }

        func statView(_ stat: ViewModel.Statistic) -> some View {
            VStack(alignment: .leading, spacing: 2.5) {
                HStack {
                    stat.value
                        .font(.headline)
                }
                HStack {
                    Image(systemName: stat.systemImage)
                    Text(stat.name)
                        .foregroundColor(.secondary)
                        .font(.subheadline)
                        .lineLimit(1)
                    Spacer()
                }
            }
        }

        let columns = [
            GridItem(.flexible()),
            GridItem(.flexible()),
        ]

        return Section(header: header) {
            if viewModel.stats.isEmpty {
                HStack {
                    Spacer()
                    Text("No Stats Available")
                    Spacer()
                }
            } else {
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(viewModel.stats, id: \.id, content: statView)
                }
                .animation(isAppearing ?
                    .easeInOut(duration: 0.15) : .none)
                .onAppear {
                    isAppearing = false
                }
            }
        }
        .animation(.easeInOut(duration: 0.15))
    }

    var thorSection: some View {
        let header = HStack {
            Text("Thor")
            Spacer()
        }
        return Section(header: header) {
            Text("Thor Data will go here.")
        }
    }

    var nearbyBadgesSection: some View {
        let header = HStack {
            Text("Nearby Badges")
            Spacer()
        }

        func badgeItem(_ badge: Badge) -> some View {
            let badgeTime = abs(badge.createdAt.timeIntervalSinceNow.minutes)
            let badgeAction: (Badge) -> (() -> Void) = { badge in {
                self.badgeTapped = badge
                self.isSheetShown.toggle()
            }
            }
            return Button(action: badgeAction(badge)) {
                HStack {
                    Image(systemName: "key")
                    Text(badge.name ?? "Unknown")
                    Spacer()
                    Text(String(badgeTime) + "m ago")
                        .foregroundColor(badgeTime <= 3 ? .green : .gray)
                    Image(systemName: "chevron.right")
                        .foregroundColor(.secondary)
                }
                .foregroundColor(.primary)
            }
        }

        return Section(header: header) {
            if viewModel.nearbyBadges.isEmpty {
                HStack {
                    Spacer()
                    Text(viewModel.isScanning ? "Searching Nearby" : "Starting Session")
                    ActivitySpinnerView(isLoading: .constant(true))
                    Spacer()
                }
            }
            ForEach(viewModel.nearbyBadges, id: \.id, content: badgeItem)
                .animation(.easeInOut(duration: 0.65))
        }
    }
}

struct SessionActiveView_Previews: PreviewProvider {
    static var previews: some View {
        SessionActiveView(badgeType: .indala, facility: .new)
    }
}
