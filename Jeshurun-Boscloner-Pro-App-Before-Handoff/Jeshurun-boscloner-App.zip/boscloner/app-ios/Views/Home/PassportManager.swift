//
//  PassportManager.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import Combine
import Database
import Foundation

class PassportManager: ObservableObject {
    @Published var state: PassportState = .offline

    var activeCard: Badge? {
        switch state {
        case let .loaded(card): return card
        case let .emulating(card): return card
        default: return nil
        }
    }

    func set(card: Badge) {
        switch state {
        case .offline:
            return
        case .emulating:
            state = .emulating(card)
        default:
            state = .loaded(card)
        }
    }
}
