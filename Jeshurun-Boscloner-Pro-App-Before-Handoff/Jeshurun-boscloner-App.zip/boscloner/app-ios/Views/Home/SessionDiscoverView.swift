//
//  SessionDiscoverView.swift
//  boscloner
//
//  Created by Ryan McHugh on 2/2/21.
//

import Database
import SwiftUI

struct SessionDiscoverView: View {
    typealias ViewModel = SessionDiscoverViewModel
    @StateObject var viewModel = ViewModel()

    @State var selectedBadge: Int?
    @State var isActiveSessionShown = false
    // Animation
    @State var buttonHighlight: CGFloat = 0.0

    var body: some View {
        ZStack {
            runBlock {
                viewModel.initialize()
            }
            navigationInjector
                .hidden()
            List {
                messageSection
                facilitySection
                badgesSection
                startButton
            }
            .listStyle(InsetGroupedListStyle())
        }
        .onDisappear {
            viewModel.destruct()
        }
        .navigationTitle("New Session")
    }
}

// MARK: Navigation Injector

private extension SessionDiscoverView {
    var navigationInjector: some View {
        Section {
            NavigationLink(destination: activeSessionViewBuilder(),
                           isActive: $isActiveSessionShown) {
                EmptyView()
            }
        }
    }
}

// MARK: Misc

extension SessionDiscoverView {
    var canStart: Bool {
        selectedBadge != nil
            && viewModel.selectedFacility != nil
            && viewModel.errorMessage.isEmpty
    }

    @ViewBuilder func activeSessionViewBuilder() -> some View {
        if let selectedBadge = selectedBadge, let facility = viewModel.selectedFacility {
            SessionActiveView(badgeType: viewModel.badgeTypes[selectedBadge], facility: facility.id)
        } else {
            EmptyView()
        }
    }

    var startButton: some View {
        let header = HStack(alignment: .center) {
            Spacer()
            Text(viewModel.errorMessage)
                .foregroundColor(.red)
                .font(.subheadline)
            Spacer()
        }

        func startAction() {
            self.isActiveSessionShown = true
        }

        return Section(header: header) {
            Button(action: startAction) {
                HStack {
                    Spacer()
                    Text("Start")
                        .font(.title)
                        .foregroundColor(.white)
                    Spacer()
                }
            }
        }
        .listRowBackground(canStart ? Color.blue : Color.gray)
        .listRowInsets(.none)
        .disabled(!canStart)
    }

    var searchNearbyButton: some View {
        HStack(alignment: .center) {
            Spacer()
            Group {
                if !viewModel.isScanning {
                    Image(systemName: "antenna.radiowaves.left.and.right")
                    Text("Search Nearby")
                } else {
                    Group {
                        Image(systemName: "xmark")
                        Text("Stop Scanning")
                    }
                    .foregroundColor(.red)
                }
            }
            .foregroundColor(.blue)
            if viewModel.isScanning {
                ActivitySpinnerView(isLoading: .constant(true))
            }
            Spacer()
        }
        .padding(.top, 2.5)
        .padding(.bottom, 9)
        .onTapGesture {
            startScanning()
        }
    }

    // Badge Views
    func badgeView(_ index: Int) -> some View {
        return VStack(spacing: 10) {
            HStack {
                Image(systemName: "checkmark")
                    .foregroundColor(selectedBadge == index ? .blue : .clear)
                Text(viewModel.badgeTypes[index].name)
                Spacer()
                if viewModel.isDefaultBadgeType(index) {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                }
                
                Image(systemName: "antenna.radiowaves.left.and.right")
                    .foregroundColor(.blue)
                    .opacity(viewModel.nearbyBadgeTypeIndicies.contains(index) ? 1 : 0)
            
            }
            Divider()
        }
        .contentShape(Rectangle())
        .transition(.slide)
        .onTapGesture {
            if selectedBadge == index {
                selectedBadge = nil
            } else {
                selectedBadge = index
            }
        }
    }
}

// MARK: Data

private extension SessionDiscoverView {
    var recentFacilities: [Facility] {
        viewModel.recentFacilities.filter {
            guard let closestFacility = viewModel.closestFacility else { return true }
            return $0.id != closestFacility.id
        }
    }
}

// MARK: Functions

private extension SessionDiscoverView {
    func startScanning() {
        // ViewModel func
        viewModel.fetchNearbyBadgeTypes()
    }
}

// MARK: Sections

extension SessionDiscoverView {
    var messageSection: some View {
        let message = "A message may go here to explain how to use this page"
        return Section {
            Text(message).bold().foregroundColor(.secondary)
        }
        .listRowBackground(Color(UIColor.systemGroupedBackground))
    }

    var facilitySection: some View {
        let header = HStack {
            Text("Facility")
            Spacer()
        }

        return Section(header: header) {
            if let nearbyFacility = viewModel.closestFacility {
                facilityRow(nearbyFacility, distance: nil, recent: false)
            }
            ForEach(viewModel.recentFacilities.filter { $0.id != viewModel.closestFacility?.id }) { facility in
                facilityRow(facility, distance: nil, recent: true)
            }
            NavigationLink(
                destination: FacilityPicker(selection: $viewModel.selectedFacility,
                                            list: recentFacilities,
                                            closestFacility: viewModel.closestFacility)) {
                if let f = viewModel.selectedFacility, !viewModel.recentFacilities.contains(where: { $0.id == f.id }), viewModel.closestFacility?.id != f.id {
                    facilityRow(f, distance: nil, recent: false)
                } else {
                    Text("Choose a facility")
                }
            }
        }
    }
    
    func facilityRow(_ facility: Facility, distance: Double?, recent: Bool) -> some View {
        HStack {
            Image(systemName: "checkmark")
                .foregroundColor(viewModel.selectedFacility?.id == facility.id ? .blue : .clear)
            VStack(alignment: .leading) {
                Text(facility.name)
                if let client = viewModel.database.client(with: facility.client) {
                    Text(client.name)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
            }
            Spacer()
            if let distance = distance {
                let km = distance / 1000
                let decimal = (distance / 100)
                Text("\(Int(km)).\(Int(decimal) % 10)) km")
            }
            if recent {
                Image(systemName: "clock")
                    .foregroundColor(.blue)
            }
        }.onTapGesture { viewModel.selectedFacility = facility }
    }

    var badgesSection: some View {
        let header = HStack {
            Text("Badges")
            Spacer()
        }

        return Section(header: header) {
            // Swapped to VStack to preserve animation
            VStack(spacing: 10) {
                ForEach(viewModel.sortedBadgeTypes, id: \.self, content: badgeView)
                    .transition(.move(edge: .trailing))
                    .animation(.easeOut(duration: 0.3))
                searchNearbyButton
            }
            .padding(.top, 10)
            .listRowInsets(.none)
        }
        .listRowInsets(.none)
        
    }
}

struct FacilityPicker: View {
    @Environment(\.presentationMode) var presentationMode

    @Binding var selection: Facility?
    public var list: [Facility]
    public var closestFacility: Facility?

    private enum HeaderType: String {
        case closest = "Closest"
        case recent = "Recent Facilities"
    }

    private func header(_ type: HeaderType) -> some View {
        return HStack(alignment: .center) {
            Spacer()
            Text(type.rawValue)
            Spacer()
        }
    }

    private func item(_ facility: Facility) -> some View {
        return Button(action: onClose(facility)) {
            HStack {
                Text(facility.name)
                    .foregroundColor(.primary)
                Spacer()
            }
        }
    }

    private func onClose(_ facility: Facility) -> () -> Void {
        return {
            selection = facility
            presentationMode.wrappedValue.dismiss()
        }
    }

    var allFacilitiesButton: some View {
        Section {
            ZStack {
                HStack {
                    Spacer()
                    Text("All Facilities")
                        .font(.title)
                    Spacer()
                }
                NavigationLink(destination: FacilitiesListView()) {
                    EmptyView()
                }.hidden()
            }
        }
    }

    var body: some View {
        List {
            if let closestFacility = closestFacility {
                Section(header: header(.closest)) {
                    Button(action: onClose(closestFacility)) {
                        HStack {
                            Image(systemName: "location")
                            Text(closestFacility.name)
                                .foregroundColor(.primary)
                            Spacer()
                        }
                    }
                }
            }
            if !list.isEmpty {
                Section(header: header(.recent)) {
                    ForEach(list, id: \.id, content: item)
                }
            }
            allFacilitiesButton
        }
        .listStyle(InsetGroupedListStyle())
    }
}

struct SessionDiscoverView_Previews: PreviewProvider, View {
    static var previews: some View {
        Group {
            Self()
            Self().colorScheme(.dark)
        }.previewDevice(.iPhone12Pro)
    }

    var body: some View {
        NavigationView {
            SessionDiscoverView()
        }
    }
}
