//
//  DevicesPage.swift
//  boscloner
//
//  Created by Jeshurun Roach on 2/23/21.
//

import Combine
import Database
import SwiftUI
import DeviceSupport

struct DevicesPage: View {
    #if targetEnvironment(simulator)
        typealias ViewModel = MockDevicesViewModel
    #else
        typealias ViewModel = DevicesViewModel
    #endif
    @StateObject var viewModel = ViewModel()
    
    #if DEBUG
    @State var testDevicesConnected: Bool = true
    #endif
    
    var body: some View {
        List {
            Section(header: thorHeader) {
                NavigationLink(destination: DeviceDetailScreen()) {
                    connectedThorView
                }
            }
            Section(header: passportHeader) {
                NavigationLink(destination: DeviceDetailScreen()) {
                    connectedPassportView
                }
            }
            
            #if DEBUG
            Toggle("Test Devices", isOn: $testDevicesConnected)
            #endif

        }.listStyle(InsetGroupedListStyle())
            .navigationBarTitle(Text("Devices"))
    }
}

extension DevicesPage {
    
    private var thorHeader: some View {
        Text("Thor")
            .bold()
            .font(.title)
            .foregroundColor(.primary)
            .textCase(.none)
    }
    
    private var passportHeader: some View {
        Text("Passport")
            .bold()
            .font(.title)
            .foregroundColor(.primary)
            .textCase(.none)
    }
    
    @ViewBuilder
    private var connectedThorView: some View {
        HStack {
            _placeholderIcon(title: Text("Thor Image"))

            #if DEBUG
            if testDevicesConnected {
                ConnectedDeviceView.Content(
                    name: "My Thor",
                    battery: 85.0,
                    status: "Connected",
                    statusColor: .blue
                )
            } else {
                notConnectedView
            }
            #else
            if let thor = viewModel.thor {
                ConnectedDeviceView(device: thor)
            } else {
                notConnectedView
            }
            #endif
        }
    }
    
    @ViewBuilder
    var connectedPassportView: some View {
        HStack {
            _placeholderIcon(title: Text("Passport Image"))

            #if DEBUG
            if testDevicesConnected {
                ConnectedDeviceView.Content(
                    name: "My Passport",
                    battery: 23.0,
                    status: "Connected",
                    statusColor: .blue
                )
            } else {
                notConnectedView
            }
            #else
            if let thor = viewModel.thor {
                ConnectedDeviceView(device: thor)
            } else {
                notConnectedView
            }
            #endif
        }
    }
    
    var thorImage: some View {
        RoundedRectangle(cornerRadius: 25.0)
            .foregroundColor(.blue)
            .overlay(Text("Thor"))
    }

    var passportImage: some View {
        RoundedRectangle(cornerRadius: 25.0)
            .foregroundColor(.blue)
            .overlay(Text("Passport"))
    }
    
    var notConnectedView: some View {
        HStack {
            Spacer()
            VStack(alignment: .trailing) {
                Text("No Device Connected").bold()
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                Spacer()
                Button(action: {}) {
                    Text("Connect").bold()
                        .padding(.horizontal)
                        .padding(.vertical, 6)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .foregroundColor(.blue)
                        )
                }.buttonStyle(PlainButtonStyle())
                .padding(.bottom, 8)
                
            }
        }
    }
    
    private func _placeholderIcon(title: Text) -> some View {
        RoundedRectangle(cornerRadius: 8)
            .frame(width: 100, height: 100, alignment: .center)
            .foregroundColor(.gray).opacity(0.2)
            .overlay(
                title.bold().foregroundColor(.secondary).multilineTextAlignment(.center))
    }
    
}



extension DevicesPage {
    struct ConnectedDeviceView: View {
        @ObservedObject var device: DeviceManager
        
        var body: some View {
            Content(
                name: device.name ?? "Device",
                battery: device.battery,
                status: "Connected",
                statusColor: .blue
            )
        }
        
        struct Content: View {
            let name: String
            let battery: Float?
            let status: String
            let statusColor: Color
            
            var body: some View {
                VStack(alignment: .leading) {
                    Text(name).bold().font(.title3)
                    HStack {
                        Text(battery.map { "\(Int($0))%" } ?? "--%")
                        Image(systemName: "battery.25")
                    }.foregroundColor(.secondary)
                    
                    Text(status).foregroundColor(statusColor)
                    
                    Spacer()
                }
            }
        }
    }
}


// MARK: - Preview

struct DevicesPage_Previews: PreviewProvider, View {
    static var previews: some View {
        Self()
    }
    
    var body: some View {
        NavigationView {
            DevicesPage()
        }.colorScheme(.dark)
    }
}
