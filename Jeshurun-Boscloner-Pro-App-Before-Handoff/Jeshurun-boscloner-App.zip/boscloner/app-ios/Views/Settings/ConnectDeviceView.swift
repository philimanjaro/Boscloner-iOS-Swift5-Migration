//
//  ConnectDeviceView.swift
//  boscloner
//
//  Created by Jeshurun Roach on 3/18/21.
//

import SwiftUI
import BluetoothSupport

struct ConnectDeviceView: View {
    typealias ViewModel = ConnectDeviceViewModel
    
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        List {
            
        }
    }
}

struct ConnectDeviceView_Previews: PreviewProvider {
    static var previews: some View {
        ConnectDeviceView()
    }
}
