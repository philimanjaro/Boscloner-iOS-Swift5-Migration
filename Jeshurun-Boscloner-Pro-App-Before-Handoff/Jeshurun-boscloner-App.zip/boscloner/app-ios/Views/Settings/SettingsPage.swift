//
//  SettingsPage.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import SwiftUI

struct SettingsPage: View {
    var body: some View {
        NavigationView {
            List {
                Section {
                    NavigationLink("Devices", destination: devicesView)
                }
                
                Section {
                    NavigationLink("Privacy", destination: privacyView)
                    NavigationLink("About Us", destination: aboutUsView)
                }
            }.navigationTitle("Settings")
            .listStyle(InsetGroupedListStyle())
        }
    }

    var devicesView: some View {
        DevicesPage()
    }

    var thorView: some View {
        Text("Thor Settings")
            .navigationTitle("Thor")
    }

    var passportView: some View {
        Text("passport Settings")
            .navigationTitle("Passport")
    }

    var privacyView: some View {
        Text("Privacy")
            .navigationTitle("Privacy")
    }

    var aboutUsView: some View {
        Text("About Us!")
            .navigationTitle("About Us")
    }
}

struct SettingsPage_Previews: PreviewProvider {
    static var previews: some View {
        SettingsPage()
    }
}
