//
//  SwiftUIView.swift
//
//
//  Created by Jeshurun Roach on 2/23/21.
//

import SwiftUI


struct DeviceDetailScreen: View {
    // modify these values to see the different states of the view
    @State var deviceName: String = "My Device"
    @State var connection: Connection = .disconnected
    @State var connectionError: String? // = "There was an error connecting to thor"
    @State var updateAvailable: Bool = true
    
    
    
    struct DeviceEditScreen: View {
        @Binding var deviceName: String
        @Binding var connection: Connection
        @Binding var connectionError: String? // = "There was an error connecting to thor"
        @Binding var updateAvailable: Bool
        
        var connectionErrorBinding: Binding<String> {
            Binding {
                connectionError ?? ""
            } set: { new in
                connectionError = new.isEmpty ? nil : new
            }
        }
        
        var body: some View {
            List {
                Section(header: Text("Device Name")) {
                TextField("Name", text: $deviceName)
                }
                
                Section(header: Text("Connection Status")) {
                    ForEach([Connection.connected, .connecting, .disconnected], id: \.rawValue) { c in
                        c.buttonText.foregroundColor(connection.rawValue == c.rawValue ? .blue : .primary)
                            .onTapGesture { connection = c }
                    }
                    TextField("No Error", text: connectionErrorBinding)
                }
                
                Section {
                    Toggle("Update Available", isOn: $updateAvailable)
                }
            }.listStyle(InsetGroupedListStyle())
        }
    }
    
    enum Connection: Int {
        case connected, disconnected, connecting
        
        var buttonColor: Color {
            switch self {
            case .connected:
                return .red
            case .disconnected:
                return .blue
            case .connecting:
                return .gray
            }
        }
        var buttonEnabled: Bool {
            guard case .connecting = self else { return true }
            return false
        }
        var buttonText: Text {
            switch self {
            case .connected:
                return Text("Disconnect")
            case .disconnected:
                return Text("Connect")
            case .connecting:
                return Text("Connecting...")
            }
        }
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                icon
                connectionContent.modifier(SectionViewModifier())
                    .padding(.horizontal)
                HStack(spacing: 16) {
                    updateContent.modifier(SectionViewModifier())
                    batteryContent.modifier(SectionViewModifier())
                }.padding(.horizontal)
                Text("\(UUID().uuidString)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                NavigationLink(destination: DeviceEditScreen(deviceName: $deviceName, connection: $connection, connectionError: $connectionError, updateAvailable: $updateAvailable)) {
                    Text("DEBUG")
                }
            }
        }.background(Color(UIColor.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle(deviceName)
        .navigationBarItems(trailing: editButton)
    }
    
    var nameSection: some View {
        HStack {
            Text(deviceName).bold().font(.title)
            Spacer()
            Button(action: {}) {
                Image(systemName: "pencil.circle")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 20)
            }
        }.padding(.horizontal).padding(.vertical).background(Capsule().foregroundColor(Color(UIColor.secondarySystemGroupedBackground))).padding(.horizontal)
    }
    
    var editButton: some View {
        // This button should show an action menu with the following options
        // Rename Device
        // Unpair Device (red, desctructive)
        Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/) {
            Image(systemName: "ellipsis.circle")
        }
    }
    
    var icon: some View {
        RoundedRectangle(cornerRadius: 20).frame(height: 300)
            .foregroundColor(.clear)
            .padding(.horizontal)
            .overlay(Text("Device Image").bold().font(.title).foregroundColor(.secondary))
    }
    
    var connectionContent: some View {
        VStack {
            HStack(alignment: .top) {
                Image(systemName: "dot.radiowaves.left.and.right").foregroundColor(.blue)
                    .padding(.bottom, 8)
                Spacer()
                if let message = connectionError {
                    Text(message).font(.footnote).foregroundColor(.red)
                }
            }
            HStack(alignment: .bottom) {
                VStack(alignment: .leading) {
                    Text("Connection").bold().font(.title3)
                    Spacer()
                    HStack {
                        switch connection {
                        case .connected:
                            Image(systemName: "checkmark.circle").foregroundColor(.green)
                            Text("Connected!").foregroundColor(.secondary)
                        case .disconnected:
                            Image(systemName: "exclamationmark.triangle")
                            Text("Not Connected").foregroundColor(.secondary)
                        case .connecting:
                            ActivitySpinner(isLoading: true)
                            Text("Connecting...").foregroundColor(.secondary)
                        }
                    }
                    
                }
                Spacer()
                connectionButton
            }
        }
    }
    
    var connectionButton: some View {
        connection.buttonText.bold().font(.headline).foregroundColor(.white)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 20).foregroundColor(connection.buttonColor)
            )
            
    }
    
    var unpairButton: some View {
        Button(action: {}) {
            HStack {
                Image(systemName: "")
                Text("Remove Device").bold().foregroundColor(.red)
            }.padding().background(RoundedRectangle(cornerRadius: 20).foregroundColor(Color(UIColor.secondarySystemGroupedBackground)))
        }.buttonStyle(PlainButtonStyle())
    }
    
    var batteryContent: some View {
        VStack(alignment: .leading) {
            Image(systemName: "bolt.fill").foregroundColor(.yellow)
                .padding(.bottom, 8)
            Text("Battery").bold().font(.title3)
            Spacer()
            HStack {
                Image(systemName: "battery.25")
                Text("2 hr 23 min")
            }.foregroundColor(.secondary)
        }
    }
    
    @ViewBuilder
    var updateContent: some View {
        if updateAvailable {
            VStack(alignment: .leading) {
                Text("Update Available").bold().font(.title3)
                Spacer()
                HStack {
                    Spacer()
                    updateButton
                    Spacer()
                }
            }
        } else {
            VStack(alignment: .leading) {
                Image(systemName: "arrow.clockwise").foregroundColor(.orange)
                    .padding(.bottom, 8)
                    Text("Up To Date").bold().font(.title3)
                
                Spacer()
                    Text("v1.34-21").foregroundColor(.secondary)
            }
        }
    }
    
    var updateButton: some View {
        RoundedRectangle(cornerRadius: 20).foregroundColor(.blue)
            .overlay(Text("Update Now").bold().font(.headline).foregroundColor(.white))
            .frame(height: 50)
    }
    
    struct SectionViewModifier: ViewModifier {
        var color: Color?
        
        func body(content: Content) -> some View {
            RoundedRectangle(cornerRadius: 20)
                .frame(height: 120)
                .foregroundColor(color ?? Color(UIColor.secondarySystemGroupedBackground))
                .overlay(content.padding(), alignment: .leading)
        }
    }
}


struct ActivitySpinner: UIViewRepresentable {
    @State var isLoading: Bool = false
    
    func makeUIView(context: Context) -> UIActivityIndicatorView {
        return UIActivityIndicatorView()
    }
    
    func updateUIView(_ uiView: UIActivityIndicatorView, context: Context) {
        guard isLoading != uiView.isAnimating else { return }
        if isLoading {
            uiView.startAnimating()
        } else {
            uiView.stopAnimating()
        }
    }
}


struct DeviceDetailScreen_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            DeviceDetailScreen().colorScheme(.dark)
        }
    }
}
