//
//  ListItemView.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/6/21.
//

import SwiftUI

struct ListItemView: View {
    let title: String
    let trailing: String
    let icon: Image?

    init(title: String = "", trailing: String = "", icon: Image? = nil) {
        self.title = title
        self.trailing = trailing
        self.icon = icon
    }

    var body: some View {
        HStack {
            if let icon = icon {
                icon
            }
            Text(title)
            Spacer()
            Text(trailing)
                .foregroundColor(.secondary)
                .font(.caption)
        }
    }
}

struct ListItemView_Previews: PreviewProvider {
    static var previews: some View {
        ListItemView()
    }
}
