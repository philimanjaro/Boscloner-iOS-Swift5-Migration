//
//  CardView.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import Database
import SwiftUI

struct CardClipView: View {
    var card: Badge

    //    @EnvironmentObject var passportManager: PassportManager

    var canSet: Bool {
        false
        //        let isActiveCard = passportManager.activeCard?.id == card.id
        //        let isOffline = passportManager.state.isOffline
        //
        //        return !(isActiveCard || isOffline)
    }

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                // TODO: better placeholder
                Text(card.name ?? "A Badge")
                    .bold()
                Spacer()
            }
            Spacer()
            if canSet {
                HStack {
                    Spacer()
                    //                    Button(action: { passportManager.set(card: card) }) {
                    //                        Text("load")
                    //                            .font(.footnote)
                    //                            .bold()
                    //                            .foregroundColor(.white)
                    //                            .padding(.vertical, 4)
                    //                            .padding(.horizontal, 12)
                    //                            .background(Capsule().foregroundColor(.gray).opacity(0.4))
                    //                    }
                    Spacer()
                }
            }

        }.padding().background(background).aspectRatio(1.7, contentMode: .fill)
    }

    var background: some View {
        LinearGradient(
            gradient: .thisRandom,
            startPoint: .top,
            endPoint: .bottom
        )
        .cornerRadius(16)
    }
}

struct CardView: View {
    @EnvironmentObject var passportManager: PassportManager
    @EnvironmentObject var databaseService: DatabaseService
    var canSet: Bool = false
    var card: Badge

    var clientName: String? {
        //        guard let client = databaseService.client(with: card) else { return nil }
        //
        //        return PersonNameComponentsFormatter().string(from: client.nameComponents)
        return ""
    }

    var body: some View {
        VStack(alignment: .leading) {
            // TODO: Better placeholder name
            Text(card.name ?? card.defaultName)
                .bold()
                .font(.title)
            Spacer()
            HStack {
                Text(clientName ?? "")
                    .bold()
                Spacer()
                //                Text(databaseService.project(with: card.p)?.name ?? "")
                //                    .bold()
                //                    .foregroundColor(.secondary)
            }
        }.padding().background(background).aspectRatio(1.7, contentMode: .fill)
    }

    var background: some View {
        LinearGradient(
            gradient: .thisRandom,
            startPoint: .top,
            endPoint: .bottom
        )
        .cornerRadius(8)
    }
}

extension Gradient {
    static let thisRandom: Gradient = random

    static let gradients: [[Color]] = [
        [
            Color(red: 0x9B / 0xFF, green: 0xF8 / 0xFF, blue: 0xF4 / 0xFF),
            Color(red: 0x6F / 0xFF, green: 0x7B / 0xFF, blue: 0xF7 / 0xFF),
        ],
    ]

    static var random: Gradient { Gradient(colors: gradients.randomElement()!) }
}
