//
//  FormFieldView.swift
//  boscloner
//
//  Created by Jeshurun Roach on 12/8/20.
//

import Foundation
import SwiftUI

struct FieldView: View {
    @Binding var field: FormField

    init(_ binding: Binding<FormField>) {
        _field = binding
    }

    var binding: Binding<String> {
        Binding {
            field.formattedValue
        } set: {
            field.value = $0
        }
    }

    var body: some View {
        VStack {
            HStack(alignment: .firstTextBaseline) {
                Text(field.name)

                TextField(field.placeholder, text: binding, onEditingChanged: clearErrors, onCommit: validate)
                    .multilineTextAlignment(.trailing)
                    .textContentType(field.contentType)
                    .keyboardType(field.keyboardType)
                    .disableAutocorrection(field.disableAutocorrec)
            }
            if let error = _field.wrappedValue.error {
                Text(error)
                    .foregroundColor(.red)
                    .frame(minWidth: 0, maxWidth: .infinity, alignment: .trailing)
            }
        }
    }

    func clearErrors(_ editing: Bool) {
        if !editing {
            field.validate()
        }
    }

    func validate() {
        field.validate()
    }
}
