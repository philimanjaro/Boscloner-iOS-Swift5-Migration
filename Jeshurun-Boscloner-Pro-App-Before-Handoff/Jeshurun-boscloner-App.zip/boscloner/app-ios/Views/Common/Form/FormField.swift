//
//  Field.swift
//  boscloner
//
//  Created by Jeshurun Roach on 12/8/20.
//

import Combine
import UIKit

struct FormField {
    var name: String
    var value: String {
        didSet {
            error = nil
            valueChanged.send(value)
        }
    }

    var placeholder: String
    var error: String?

    var contentType: UITextContentType?
    var keyboardType: UIKeyboardType
    var disableAutocorrec: Bool

    var formattedValue: String { formatter?(value) ?? value }
    var formatter: ((String) -> String)?

    var validation: ((String) -> String?)?

    //  var publisher: AnyPublisher<String, Never> {
//    valueChanged.eraseToAnyPublisher()
    //  }

    private let valueChanged = PassthroughSubject<String, Never>()

    init(name: String,
         value: String?,
         placeholder: String,
         contentType: UITextContentType? = nil,
         keyboardType: UIKeyboardType = .default,
         disableAutocorrec: Bool = false,
         formatter: ((String) -> String)? = nil,
         validate: ((String) -> String?)? = nil)
    {
        self.name = name
        self.value = value ?? ""
        self.placeholder = placeholder
        self.contentType = contentType
        self.keyboardType = keyboardType
        self.disableAutocorrec = disableAutocorrec
        self.formatter = formatter
        validation = validate
    }

    mutating func validate() {
        error = validation?(value)
    }
}

extension FormField {
    static func firstName(value: String? = nil) -> FormField {
        FormField(name: "First Name",
                  value: value, placeholder: "John",
                  contentType: .givenName,
                  disableAutocorrec: true,
                  validate: { name in
                      guard name.count > 1 else {
                          return "Invalid First Name"
                      }
                      return nil
                  })
    }

    static func lastName(value: String? = nil) -> FormField {
        FormField(name: "Last Name",
                  value: value,
                  placeholder: "Smith",
                  contentType: .familyName,
                  disableAutocorrec: true,
                  validate: { name in
                      guard name.count > 1 else {
                          return "Invalid Last Name"
                      }
                      return nil
                  })
    }

    static func name(value: String? = nil, placeholder: String? = nil) -> FormField {
        FormField(name: "Name",
                  value: value,
                  placeholder: placeholder ?? "Pacific Industries",
                  contentType: .name,
                  disableAutocorrec: true,
                  validate: { $0.count > 1 ? nil : "Invalid Name" })
    }

    static func company(value: String? = nil) -> FormField {
        FormField(name: "Company", value: value, placeholder: "ABC inc.")
    }

    // Address Fields
    static func addrStreet(value: String? = nil) -> FormField {
        FormField(name: "Street Address",
                  value: value,
                  placeholder: "123 Broadbank Way",
                  contentType: .fullStreetAddress,
                  validate: { street in
                      guard !street.isEmpty else { return "Invalid Street Address" }
                      // Finish this
                      return nil
                  })
    }

    static func addrCity(value: String? = nil) -> FormField {
        FormField(name: "City",
                  value: value,
                  placeholder: "Seatle",
                  contentType: .addressCity,
                  validate: { city in
                      guard !city.isEmpty else { return "Invalid City" }
                      // Finish this
                      return nil
                  })
    }

    static func addrState(value: String? = nil) -> FormField {
        FormField(name: "State",
                  value: value,
                  placeholder: "WA",
                  contentType: .addressState,
                  validate: { state in
                      guard state.count == 2 else { return "Invalid State Code" }
                      guard stateList.contains(state.uppercased()) else { return "Invalid State Code" }
                      return nil
                  })
    }

    static func addrZip(value: String? = nil) -> FormField {
        FormField(name: "Zip Code",
                  value: value,
                  placeholder: "98114",
                  validate: { zip in
                      guard zip.count == 5 else { return "Invalid Zip" }
                      let numbers = zip.filter("0123456789".contains)
                      guard zip.count == numbers.count else { return "Invalid Zip" }
                      // Finish this
                      return nil
                  })
    }

    static func email(value: String? = nil) -> FormField {
        FormField(name: "Email",
                  value: value,
                  placeholder: "my.email@company.com",
                  contentType: .emailAddress,
                  keyboardType: .emailAddress,
                  validate: { email in
                      let parts = email.split(separator: "@")
                      guard parts.count == 2 else { return "Invalid Email" }
                      let (name, domain) = (parts[0], parts[1])
                      guard !name.isEmpty else { return "Invalid Email" }
                      let dParts = domain.split(separator: ".")
                      guard dParts.count > 1 else { return "Invalid Email" }
                      guard dParts.last!.count > 1 else { return "Invalid Email" }
                      return nil
                  })
    }

    static func phone(value: String? = nil) -> FormField {
        FormField(name: "Phone",
                  value: value,
                  placeholder: "123-4556-7890",
                  contentType: .telephoneNumber,
                  keyboardType: .phonePad) { string in
            var numbers = string.filter("0123456789".contains)
            var countryCode: String = ""
            // 123-456-7890
            switch numbers.count {
            case 14 ... .max:
                numbers = String(numbers.prefix(13))
                fallthrough
            case 11 ..< 14:
                let count = numbers.count - 10
                countryCode = "+\(numbers.prefix(count)) "
                numbers = String(numbers.dropFirst(count))
                fallthrough
            case 7 ..< 11:
                numbers.insert("-", at: .init(utf16Offset: 6, in: numbers))
                fallthrough
            case 4 ..< 7:
                numbers.insert("-", at: .init(utf16Offset: 3, in: numbers))
            default:
                break
            }
            return countryCode + numbers
        } validate: { phone in
            let phone = phone.filter { !" -+()".contains($0) }
            guard (10 ... 13).contains(phone.count), phone.unicodeScalars.allSatisfy(CharacterSet.numerics.contains)
            else {
                return "Invalid Phone Number"
            }
            return nil
        }
    }

    static func notes(value: String? = nil) -> FormField {
        FormField(name: "Notes", value: value, placeholder: "")
    }
}

extension FormField {
    // States including american territories
    static var stateList: [String] { [
        "AL", "AK", "AS", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FM", "FL", "GA",
        "GU", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MH", "MD", "MA",
        "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND",
        "MP", "OH", "OK", "OR", "PW", "PA", "PR", "RI", "SC", "SD", "TN", "TX", "UT",
        "VT", "VI", "VA", "WA", "WV", "WI", "WY",
    ] }
}

public extension CharacterSet {
    static let numerics: CharacterSet = {
        CharacterSet(charactersIn: "0123456789")
    }()
}
