//
//  ActivitySpinnerView.swift
//  boscloner
//
//  Created by Ryan McHugh on 2/4/21.
//

import SwiftUI

struct ActivitySpinnerView: UIViewRepresentable {
    @Binding var isLoading: Bool

    func makeUIView(context _: Context) -> UIActivityIndicatorView {
        return UIActivityIndicatorView()
    }

    func updateUIView(_ uiView: UIActivityIndicatorView, context _: Context) {
        guard isLoading != uiView.isAnimating else { return }
        if isLoading {
            uiView.startAnimating()
        } else {
            uiView.stopAnimating()
        }
    }
}

struct ActivitySpinnerView_Previews: PreviewProvider {
    static var previews: some View {
        ActivitySpinnerView(isLoading: .constant(true))
    }
}
