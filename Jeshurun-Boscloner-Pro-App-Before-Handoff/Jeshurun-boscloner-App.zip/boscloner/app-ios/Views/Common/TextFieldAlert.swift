//
//  TextFieldAlert.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 12/12/20.
//

import SwiftUI

struct TextFieldAlert: UIViewControllerRepresentable {
    @Binding var textString: String
    @Binding var showAlert: Bool

    var title: String
    var message: String

    var onSave: () -> Void

    func makeUIViewController(context _: UIViewControllerRepresentableContext<TextFieldAlert>) -> UIViewController {
        return UIViewController()
    }

    func updateUIViewController(_ uiViewController: UIViewController,
                                context: UIViewControllerRepresentableContext<TextFieldAlert>)
    {
        guard context.coordinator.alert == nil else { return }

        if showAlert {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            context.coordinator.alert = alert

            alert.addTextField { textField in
                textField.placeholder = ""
                textField.text = self.textString
                textField.delegate = context.coordinator
            }

            alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .default) { _ in
                alert.dismiss(animated: true) {
                    showAlert = false
                }
            })

            alert.addAction(UIAlertAction(title: NSLocalizedString("Save", comment: ""), style: .default) { _ in
                if let textField = alert.textFields?.first, let text = textField.text {
                    self.textString = text
                    onSave()
                }

                alert.dismiss(animated: true) {
                    self.showAlert = false
                }
            })

            DispatchQueue.main.async {
                uiViewController.present(alert, animated: true, completion: {
                    self.showAlert = false
                    context.coordinator.alert = nil
                })
            }
        }
    }

    func makeCoordinator() -> TextFieldAlert.Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UITextFieldDelegate {
        var alert: UIAlertController?
        var control: TextFieldAlert

        init(_ control: TextFieldAlert) {
            self.control = control
        }

        func textField(_ textField: UITextField,
                       shouldChangeCharactersIn range: NSRange,
                       replacementString string: String) -> Bool
        {
            if let text = textField.text as NSString? {
                control.textString = text.replacingCharacters(in: range, with: string)
            } else {
                control.textString = ""
            }
            return true
        }
    }
}
