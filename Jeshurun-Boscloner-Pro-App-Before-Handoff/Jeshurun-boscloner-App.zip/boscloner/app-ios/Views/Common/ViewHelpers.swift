//
//  ViewHelpers.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/12/21.
//

import Database
import Foundation
import SwiftUI

class ViewHelpers {
    public static var shared = ViewHelpers()

    // Creates a scrollable list view from an array of 'model' objects, based on a given builder
    func itemList<Content: View, T: Model>(data: [T], title: String = "",
                                           @ViewBuilder content: @escaping (T) -> Content) -> some View
    {
        return List {
            ForEach(data) { item in
                ZStack {
                    content(item)
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle(title)
    }
}
