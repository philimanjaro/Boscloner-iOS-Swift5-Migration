//
//  MapView.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/4/21.
//

import MapKit
import SwiftUI

struct MapView: View {
    var lat: Double?
    var lng: Double?

    @State private var region = MKCoordinateRegion()
    @State private var showMap: Bool = false

    init(lat: Double?, lng: Double?) {
        self.lat = lat
        self.lng = lng
        guard let lat = lat, let lng = lng else { return }
        _region = .init(initialValue: MKCoordinateRegion(
            center: CLLocationCoordinate2D(
                latitude: lat, longitude: lng
            ),
            span: MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10)
        ))
        _showMap = .init(initialValue: true)
    }

    struct AnnotationItem: Identifiable {
        var coordinate: CLLocationCoordinate2D
        let id = UUID()
    }

    var annotationItems: [AnnotationItem] {
        guard let lat = lat, let lng = lng else { return [] }
        return [
            AnnotationItem(coordinate: CLLocationCoordinate2D(latitude: lat, longitude: lng)),
        ]
    }

    var body: some View {
        Group {
            if showMap {
                Map(
                    coordinateRegion: $region,
                    annotationItems: annotationItems
                ) { item in
                    MapPin(coordinate: item.coordinate)
                }.disabled(/*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
            } else {
                RoundedRectangle(cornerRadius: 16)
                    .foregroundColor(Color(UIColor.systemFill))
                    .overlay(Text("Map View")).foregroundColor(.secondary)
            }
        }
        .frame(height: UIScreen.main.bounds.height / 4)
        .listRowBackground(Color(UIColor.systemGroupedBackground))
        .listRowInsets(EdgeInsets(.zero))
    }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView(lat: 47.60902, lng: -122.33405)
            .previewDevice(.iPhone12Pro)
    }
}
