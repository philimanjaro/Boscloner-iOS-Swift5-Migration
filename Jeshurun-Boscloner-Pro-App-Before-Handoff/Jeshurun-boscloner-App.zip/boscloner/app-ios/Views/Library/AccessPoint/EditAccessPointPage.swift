//
//  EditAccessPointPage.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/5/21.
//

import SwiftUI

struct EditAccessPointPage: View {
    var body: some View {
        Text("Placeholder: Edit Access Point Page")
    }
}

struct EditAccessPointPage_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            EditAccessPointPage()
        }
        .previewDevice(.iPhone12Pro)
    }
}
