//
//  AccessPointView.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/5/21.
//

import SwiftUI

struct AccessPointDetailsView: View {
    var body: some View {
        Text("Placeholder: Access Point")
    }
}

struct AccessPointDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AccessPointDetailsView()
        }
        .previewDevice(.iPhone12Pro)
    }
}
