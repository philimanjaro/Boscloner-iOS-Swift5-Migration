//
//  EditAccessPointPage.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/5/21.
//

import SwiftUI

struct AccessPointEditView: View {
    var body: some View {
        Text("Placeholder: Edit Access Point Page")
    }
}

struct AccessPointEditView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AccessPointEditView()
        }
        .previewDevice(.iPhone12Pro)
    }
}
