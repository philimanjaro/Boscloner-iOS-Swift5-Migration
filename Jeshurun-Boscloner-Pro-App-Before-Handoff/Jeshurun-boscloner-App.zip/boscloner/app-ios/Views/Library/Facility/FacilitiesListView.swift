//
//  FacilitiesListView.swift
//  boscloner
//
//  Created by Ryan McHugh on 2/6/21.
//

import Combine
import Database
import SwiftUI

struct FacilitiesListView: View {
    typealias ViewModel = FacilitiesListViewModel

    @StateObject var viewModel = ViewModel()
    var body: some View {
        List {
            ForEach(viewModel.facilities, id: \.id) { facility in
                Text(facility.name)
            }
        }
        .navigationTitle("All Facilities")
        .navigationBarItems(trailing: addButton)
    }
}

extension FacilitiesListView {
    var addButton: some View {
        Button(action: {}) {
            Image(systemName: "plus")
        }
    }
}

struct FacilitiesListView_Previews: PreviewProvider {
    static var previews: some View {
        FacilitiesListView()
    }
}

extension FacilitiesListView {
    class FacilitiesListViewModel: ObservableObject {
        @Published var facilities = [Facility]()

        // Dependencies
        @Dependency(\.database) var database: DatabaseService

        init() {
//            facilities = mockedFacilities()
            database.facility()
                .assign(to: &$facilities)
        }
    }
}
