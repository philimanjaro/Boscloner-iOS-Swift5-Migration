//
//  FacilityDetailsView.swift
//  boscloner
//
//  Created by Ryan McHugh on 12/28/20.
//

import Database
import MapKit
import SwiftUI

struct FacilityDetailsView: View {
    // Required Environment Objects
    @StateObject private var viewModel = FacilityDetailsViewModel()

    // Navigation
    @State private var editSelection: EditItem?
    @State private var menuSelection: MenuType?
    @State private var isMenuShown = false
    @State private var isSheetShown = false
    
    @State var selectedBadge: Badge?

    @State public var facility: Facility!

    private var sectionLimit = 5

    var address: String {
        if let addr = facility.address {
            return "\(addr.street), \(addr.city) \(addr.state)"
        } else {
            return ""
        }
    }

    public init(facility: Facility? = nil) {
        _facility = .init(initialValue: facility ?? Facility.mock(id: .new))
    }

    var body: some View {
        viewModel.facility = facility
        
        return ZStack {
            navigationInjector
                .hidden()

            List {
                clientSection

                Section(footer: Text(address)) {
                    Button(action: onAddressTap) {
                        MapView(lat: facility.lat,
                                lng: facility.lng)
                    }
                    .listRowBackground(Color(UIColor.systemGroupedBackground))
                    .listRowInsets(EdgeInsets(.zero))
                }

                badgesSection
                accessPointsSection
                contactsSection
                notesSection
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle(
                Text("\(facility.name)")
            )
            .sheet(item: $selectedBadge) {
                BadgeDetailsView(badge: $0)
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    menuButton
                }
            }
        }
    }
}

// MARK: - MISC

private extension FacilityDetailsView {
    var menuButton: some View {
        Button(action: onMenuBarTap) {
            Image(systemName: "pencil.circle").resizable()
        }
    }

    func onMenuBarTap() {
        menuSelection = .edit
        isMenuShown.toggle()
    }

    func actionSheet() -> ActionSheet {
        return ActionSheet(title: Text("Facility Menu"), message: nil, buttons: [
            .default(Text("Edit Facility"), action: editAction(.facility)),
            .default(Text("New Access Point"), action: editAction(.addAccessPoint)),
            .default(Text("New Contact"), action: editAction(.addContact)),
            .cancel(),

        ])
    }

    func mapSheet() -> ActionSheet {
        return ActionSheet(title: Text("Facility Address"), message: nil, buttons: [
            .default(Text("Copy Address"), action: {
                Helpers.shared.copyToClipboard(string: facility.address?.combined)
            }),
            .default(Text("Open in Apple Maps"), action: onAppleMapTap),
            .cancel(),
        ])
    }

    func onAppleMapTap() {
        Helpers.shared.navigateWithAppleMaps(coordinate: facility.coordinate, name: facility.name)
        print("Opening address in Apple Maps")
    }

    func onAddressTap() {
        menuSelection = .map
        isMenuShown.toggle()
        print("\(address)")
    }

    func editAction(_ selection: EditItem) -> () -> Void {
        switch selection {
        case .facility:
            return {
                editSelection = .facility
                print("Editing Facility ...")
            }
        case .addAccessPoint:
            return {
                editSelection = .addAccessPoint
                print("New Access Point ...")
                isSheetShown.toggle()
            }
        case .addContact:
            return {
                editSelection = .addContact
                print("New Contact ...")
                isSheetShown.toggle()
            }
        }
    }

    enum EditItem {
        case facility
        case addAccessPoint
        case addContact
    }

    enum MenuType {
        case edit
        case map
    }
}

// MARK: - Navigation Injector

private extension FacilityDetailsView {
    var navigationInjector: some View {
        Section {
            // Edit Facility
            NavigationLink(
                destination: FacilityEditView(facility: $facility),
                tag: .facility,
                selection: $editSelection
            ) {
                Text("Edit Facility")
            }
        }
        .sheet(isPresented: $isSheetShown) {
            ZStack {
                switch editSelection {
                case .addAccessPoint:
                    AccessPointEditView()
                case .addContact:
                    EditContactView()
                default:
                    EmptyView()
                }
            }
        }
        .actionSheet(isPresented: $isMenuShown) {
            switch menuSelection {
            case .edit:
                return actionSheet()
            case .map:
                return mapSheet()
            default:
                return actionSheet()
            }
        }
    }
}

private extension FacilityDetailsView {
    // MARK: - Client Section

    var clientSection: some View {
        let header = Text("")
        return Section(header: header) {
            HStack(alignment: .center) {
                Text("Client: ")
                    .foregroundColor(.secondary)
                    .font(.title3)
                    .bold()
                Text(viewModel.client?.name ?? "")
                    .font(.body)
            }
        }
    }

    // MARK: - Badges Section

    var badgesSection: some View {
        let destination = Text("All Badges")
        
        let header = HStack {
            Text("Badges")
            Spacer()
            if viewModel.badges.count > sectionLimit {
                NavigationLink(destination: destination) {
                    Text("Show all").foregroundColor(.blue)
                }
            }
        }

        // TODO: Integrate Badge model
        return Section(header: header) {
            if !viewModel.badges.isEmpty {
                ForEach(viewModel.badges.prefix(sectionLimit)) { badge in
                    ListItemView(title: badge.name ?? badge.defaultName,
                                 icon: Image(systemName: "key"))
                    .onTapGesture { selectedBadge = badge }
                }
            } else {
                Text("\(facility.name) does not have any Badges.")
            }
        }
    }

    // MARK: - AccessPoints Section

    var accessPointsSection: some View {
        let destination = itemList(data: viewModel.accessPoints, title: "All Access Points") { accessPoint in
            ZStack {
                NavigationLink(destination: AccessPointDetailsView()) {
                    ListItemView(title: accessPoint.name,
                                 icon: Image(systemName: "house"))
                }
            }
        }

        let header = HStack {
            Text("Access Points")
            Spacer()
            if viewModel.accessPoints.count > sectionLimit {
                NavigationLink(destination: destination) {
                    Text("Show all").foregroundColor(.blue)
                }
            }
        }

        let accessPoints = viewModel.accessPoints.count > sectionLimit
            ? Array(viewModel.accessPoints[0 ..< sectionLimit])
            : viewModel.accessPoints

        return Section(header: header) {
            if !viewModel.accessPoints.isEmpty {
                ForEach(accessPoints) { accessPoint in
                    ZStack {
                        NavigationLink(destination: AccessPointDetailsView()) {}
                        ListItemView(title: accessPoint.id.rawValue.uuidString,
                                     icon: Image(systemName: "house"))
                    }
                }
            } else {
                Text("\(facility.name) does not have any Access Points.")
            }
        }
    }

    // MARK: - Contacts Section

    var contactsSection: some View {
        let destination = itemList(data: viewModel.contacts, title: "All Contacts") { contact in
            NavigationLink(destination: ContactDetailsView()) {
                ListItemView(title: contact.name,
                             icon: Image(systemName: "person.circle"))
            }
        }

        let header = HStack {
            Text("Contacts")
            Spacer()
            if viewModel.contacts.count > sectionLimit {
                NavigationLink(destination: destination) {
                    Text("Show all").foregroundColor(.blue)
                }
            }
        }

        let contacts = viewModel.contacts.count > sectionLimit
            ? Array(viewModel.contacts[0 ..< sectionLimit])
            : viewModel.contacts

        return Section(header: header) {
            if !viewModel.contacts.isEmpty {
                ForEach(contacts) { contact in
                    ZStack {
                        NavigationLink(destination: ContactDetailsView()) {}
                        ListItemView(title: contact.name,
                                     trailing: contact.title ?? "",
                                     icon: Image(systemName: "person.circle"))
                    }
                }
            } else {
                Text("\(facility.name) does not have any Contacts.")
            }
        }
    }

    // MARK: - Notes Section

    var notesSection: some View {
        let header = HStack {
            Text("Notes")
            Spacer()
        }

        return Section(header: header) {
            ZStack(alignment: .top) {
                RoundedRectangle(cornerRadius: 16)
                    .foregroundColor(Color(UIColor.systemFill))
                    .overlay(
                        Text(facility.notes == nil ? "Notes" : "").foregroundColor(.secondary)
                    )
                Text(facility.notes ?? "")
                    .bold()
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding()
            }
            .frame(minHeight: UIScreen.main.bounds.height / 3)
            .listRowBackground(Color(UIColor.systemGroupedBackground))
            .listRowInsets(EdgeInsets(.zero))
        }
    }
}

// MARK: - Previews

struct FacilityDetailsView_Previews: PreviewProvider, View {
    static var previews: some View {
        Group {
            Self()
            Self().colorScheme(.dark)
        }.previewDevice(.iPhone12Pro)
    }

    var body: some View {
        TabView {
            NavigationView {
                FacilityDetailsView(facility: mockedFacilities().first!)
            }
        }
    }
}
