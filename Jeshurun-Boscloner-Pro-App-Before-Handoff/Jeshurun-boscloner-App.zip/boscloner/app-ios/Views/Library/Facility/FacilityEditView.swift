//
//  FacilityEditPage.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/2/21.
//

import Combine
import CoreLocation
import Database
import SwiftUI

struct FacilityEditView: View {
    @Environment(\.presentationMode) var presentationMode

    static var allFields: [ReferenceWritableKeyPath<FacilityEditView, FormField>] {
        [\.name, \.addrStreet, \.addrCity, \.addrState, \.addrZip, \.notes]
    }

    @Binding private var facility: Facility?

    @State private var name: FormField
    @State private var addrStreet: FormField
    @State private var addrCity: FormField
    @State private var addrState: FormField
    @State private var addrZip: FormField
    @State private var notes: FormField

    @State private var location: CLLocationCoordinate2D?
    @State private var defaultBadgeSelection: Int = 0
    @State private var alert: AlertType?

    @State private var cancellables = Set<AnyCancellable>()

    @State private var isSaveEnabled = false

    private var client: UID<Client>?

    init(facility: Binding<Facility?> = .constant(nil), client: UID<Client>? = nil) {
        _facility = facility
        self.client = client
        _name = .init(initialValue: .name(value:
            facility.wrappedValue?.name, placeholder: "Facility A"))
        _addrStreet = .init(initialValue: .addrStreet(value: facility.wrappedValue?.address?.street))
        _addrCity = .init(initialValue: .addrCity(value: facility.wrappedValue?.address?.city))
        _addrState = .init(initialValue: .addrState(value: facility.wrappedValue?.address?.state))
        _addrZip = .init(initialValue: .addrZip(value: facility.wrappedValue?.address?.zip))
        _notes = .init(initialValue: .notes(value: facility.wrappedValue?.notes))
    }

    var body: some View {
        Form {
            Section(header: Text("Facility Info")) {
                FieldView($name)
                FieldView($addrStreet)
                FieldView($addrCity)
                FieldView($addrState)
                FieldView($addrZip)
            }

            Section(header: Text("Map")) {
                MapView(lat: location?.latitude, lng: location?.longitude)
            }

            defaultBadgeTypeSection
                .frame(maxWidth: .infinity)

            notesSection

            Section(header: Divider()) {
                deleteButton
            }
            .listRowBackground(Color(UIColor.systemGroupedBackground))
            .listRowInsets(EdgeInsets(.zero))
        }
        .navigationTitle(facility == nil ? "New Facility" : "Edit Facility")
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: closeButton, trailing: saveButton)
        .alert(item: $alert) { type in
            type.alert(with: action(for: type), name: facility?.name)
        }
        // Updates mapview location on change of address fields
        .onReceive(combinePublishedFields(), perform: { _ in
            // Update isSaveEnabled
            self.isSaveEnabled = !hasEmptyFields()

            // TODO: Finish updating map with address
//            let address = Address(street: addrStreet.value,
//                                  city: addrCity.value,
//                                  state: addrState.value,
//                                  country: "USA", zip:
//                                  addrZip.value)
        })
    }
}

// MARK: - MISC

extension FacilityEditView {
    var saveButton: some View {
        Button(action: saveFacility) {
            Text("Save")
        }
        .disabled(!isSaveEnabled)
    }

    var closeButton: some View {
        Button(action: action(for: .closeWithoutSaving)) {
            Label("Close", systemImage: "xmark")
        }
    }

    var deleteButton: some View {
        Button(action: deleteFacility) {
            RoundedRectangle(cornerRadius: 16)
                .foregroundColor(Color(.systemRed))
                .frame(maxWidth: .infinity, minHeight: 50, maxHeight: 50)
                .overlay(Text("Delete")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.white))
        }
    }
}

// MARK: - Functions

extension FacilityEditView {
    func action(for alert: AlertType) -> () -> Void {
        switch alert {
        case .closeWithoutSaving:
            return { presentationMode.wrappedValue.dismiss(); print("closeWithoutSaving") }
        case .delete:
            return { print("delete") }
        }
    }

    func combinePublishedFields() -> Publishers.MergeMany<Publishers.Sequence<String, Never>> {
        let publishers = [name, addrStreet, addrCity, addrState, addrZip].compactMap { $0.value.publisher }
        return Publishers.MergeMany(publishers)
    }

    func validate() {
        for keypath in Self.allFields {
            self[keyPath: keypath].validate()
        }
    }

    func hasEmptyFields() -> Bool {
        Self.allFields.contains { self[keyPath: $0].value.isEmpty }
    }

    func clearErrors() {
        for keypath in Self.allFields {
            self[keyPath: keypath].error = nil
        }
    }

    var hasErrors: Bool {
        Self.allFields.contains { self[keyPath: $0].error != nil }
    }

    func deleteFacility() {
        alert = .delete
        print("Deleting Facility...")
    }

    func saveFacility() {
        validate()
        guard !hasErrors else { return }

        let address: Address = .init(street: addrStreet.value,
                                     city: addrCity.value,
                                     state: addrState.value,
                                     country: "USA",
                                     zip: addrZip.value)

        facility?.name = name.value
        facility?.address = address
        facility?.notes = notes.value

        // TODO: Handle Error on receiveCompletion
        Helpers.shared.getCoordinate(address: address)
            .sink(receiveCompletion: { print($0) }, receiveValue: { coordinate in
                facility?.lat = coordinate.latitude
                facility?.lng = coordinate.longitude
                print("Facility located at: \n lat: \(coordinate.latitude) lng: \(coordinate.longitude)")

                // Persist data here
                if let updatedFacility = _facility.wrappedValue {
                    DependencyInjector.default.database.save(facility: updatedFacility)
                } else {
                    let newFacility = Facility(id: .new,
                                               name: name.value,
                                               address: address,
                                               lat: coordinate.latitude,
                                               lng: coordinate.longitude,
                                               facilityBadgeId: BadgeType.allCases[defaultBadgeSelection].id,
                                               notes: notes.value,
                                               client: client ?? .new)
                    print(newFacility)
                    DependencyInjector.default.database.save(facility: newFacility)
                }
            })
            .store(in: &cancellables)
        presentationMode.wrappedValue.dismiss()
    }
}

extension FacilityEditView {
    // MARK: - Default Badge Type Section

    var defaultBadgeTypeSection: some View {
        let header = HStack {
            Text("Default BadgeType")
            Spacer()
        }

        return Section(header: header) {
            Picker("", selection: $defaultBadgeSelection) {
                ForEach(0 ..< (BadgeType.allCases.count + 1)) { index in
                    let modifiedIndex: Int = index - 1
                    if index == 0 {
                        Text("none")
                            .tag(index)
                    } else {
                        Text(BadgeType.allCases[modifiedIndex].id)
                            .tag(modifiedIndex)
                    }
                }
            }
            .pickerStyle(SegmentedPickerStyle())
        }
        .listRowInsets(EdgeInsets(.zero))
        .listRowBackground(Color(UIColor.systemGroupedBackground))
        .onChange(of: defaultBadgeSelection) {
            if $0 <= 0 { return }
            facility?.defaultBadgeType = BadgeType.allCases[$0 - 1]
        }
    }

    // MARK: - Notes Section

    var notesSection: some View {
        let header = HStack {
            Text("Notes")
            Spacer()
        }

        return Section(header: header) {
            TextEditor(text: $notes.value)
                .frame(maxWidth: .infinity, minHeight: UIScreen.main.bounds.height / 3)
        }
        .listRowInsets(EdgeInsets(top: 5, leading: 10, bottom: 5, trailing: 10))
    }

    enum AlertType: Int, Identifiable {
        var id: Int { rawValue }

        case closeWithoutSaving
        case delete

        func alert(with action: @escaping () -> Void, name: String? = nil) -> Alert {
            switch self {
            case .closeWithoutSaving:
                return Alert(
                    title: Text("Unsaved Changes"),
                    message: Text("Your changes will be lost"),
                    primaryButton: .destructive(Text("OK"), action: action),
                    secondaryButton: .cancel()
                )
            case .delete:
                return Alert(
                    title: Text("Are you sure you want to delete \(name ?? "this")?"),
                    message: Text("You will not be able to recover this facility."),
                    primaryButton: .destructive(Text("OK"), action: action),
                    secondaryButton: .cancel()
                )
            }
        }
    }
}

struct FacilityEditView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            FacilityEditView()
        }
    }
}
