//
//  EditFacilityPage.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/2/21.
//

import Combine
import CoreLocation
import Database
import SwiftUI

struct EditFacilityPage: View {
    @Environment(\.presentationMode) var presentationMode

    private var databaseService: DatabaseService

    static var allFields: [ReferenceWritableKeyPath<EditFacilityPage, FormField>] {
        [\.name, \.addrStreet, \.addrCity, \.addrState, \.addrZip, \.notes]
    }

    @Binding var facility: Facility?

    @State private var name: FormField
    @State private var addrStreet: FormField
    @State private var addrCity: FormField
    @State private var addrState: FormField
    @State private var addrZip: FormField
    @State private var notes: FormField

    @State private var location: CLLocationCoordinate2D?
    @State private var defaultBadgeSelection: Int = 0
    @State private var alert: AlertType?

    @State private var cancellables = Set<AnyCancellable>()

    @State private var isSaveEnabled = false

    init(facility: Binding<Facility?> = .constant(nil), database: DatabaseService) {
        _facility = facility
        databaseService = database
        _name = .init(initialValue: .name(value: facility.wrappedValue?.name, placeholder: "Facility A"))
        _addrStreet = .init(initialValue: .addrStreet(value: facility.wrappedValue?.address?.street))
        _addrCity = .init(initialValue: .addrCity(value: facility.wrappedValue?.address?.city))
        _addrState = .init(initialValue: .addrState(value: facility.wrappedValue?.address?.state))
        _addrZip = .init(initialValue: .addrZip(value: facility.wrappedValue?.address?.zip))
        _notes = .init(initialValue: .notes(value: facility.wrappedValue?.notes))
    }

    var body: some View {
        Form {
            Section(header: Text("Facility Info")) {
                FieldView($name)
                FieldView($addrStreet)
                FieldView($addrCity)
                FieldView($addrState)
                FieldView($addrZip)
            }

            Section(header: Text("Map")) {
                MapView(lat: location?.latitude, lng: location?.longitude)
            }

            defaultBadgeTypeSection
                .frame(maxWidth: .infinity)

            notesSection
        }
        .navigationTitle(_facility.wrappedValue == nil ? "New Facility" : "Edit Facility")
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: closeButton, trailing: saveButton)
        .alert(item: $alert) { type in
            type.alert(with: action(for: type))
        }
        // Updates mapview location on change of address fields
        .onReceive(combinePublishedFields(), perform: { _ in
            // Update isSaveEnabled
            self.isSaveEnabled = !hasEmptyFields()

            // TODO: Finish updating map with address
//            let address = Address(street: addrStreet.value,
//                                  city: addrCity.value,
//                                  state: addrState.value,
//                                  country: "USA", zip:
//                                  addrZip.value)
        })
    }
}

// MARK: - MISC

extension EditFacilityPage {
    var saveButton: some View {
        Button(action: save) {
            Text("Save")
        }
        .disabled(!isSaveEnabled)
    }

    var closeButton: some View {
        Button(action: action(for: .closeWithoutSaving)) {
            Label("Close", systemImage: "xmark")
        }
    }
}

// MARK: - Functions

extension EditFacilityPage {
    func action(for alert: AlertType) -> () -> Void {
        switch alert {
        case .closeWithoutSaving:
            return { presentationMode.wrappedValue.dismiss(); print("closeWithoutSaving") }
        case .delete:
            return { print("delete") }
        }
    }

    func combinePublishedFields() -> Publishers.MergeMany<Publishers.Sequence<String, Never>> {
        let publishers = [name, addrStreet, addrCity, addrState, addrZip].compactMap { $0.value.publisher }
        return Publishers.MergeMany(publishers)
    }

    func validate() {
        for keypath in Self.allFields {
            self[keyPath: keypath].validate()
        }
    }

    func hasEmptyFields() -> Bool {
        Self.allFields.contains { self[keyPath: $0].value.isEmpty }
    }

    func clearErrors() {
        for keypath in Self.allFields {
            self[keyPath: keypath].error = nil
        }
    }

    var hasErrors: Bool {
        Self.allFields.contains { self[keyPath: $0].error != nil }
    }

    func save() {
        validate()
        guard !hasErrors else { return }

        let address: Address = .init(street: addrStreet.value,
                                     city: addrCity.value,
                                     state: addrState.value,
                                     country: "USA",
                                     zip: addrZip.value)

        if facility == nil { facility = Facility(name: name.value) }

        facility?.address = address
        facility?.notes = notes.value

        // Persist data here

        // TODO: Handle Error on receiveCompletion
        Helpers.shared.getCoordinate(address: address)
            .sink(receiveCompletion: { print($0) }, receiveValue: { coordinate in
                facility?.lat = coordinate.latitude
                facility?.lng = coordinate.longitude
                print("Facility located at: \n lat: \(coordinate.latitude) lng: \(coordinate.longitude)")
            })
            .store(in: &cancellables)
        presentationMode.wrappedValue.dismiss()
    }
}

extension EditFacilityPage {
    // MARK: - Default Badge Type Section

    var defaultBadgeTypeSection: some View {
        let header = HStack {
            Text("Default BadgeType")
            Spacer()
        }

        return Section(header: header) {
            Picker("", selection: $defaultBadgeSelection) {
                ForEach(0 ..< (BadgeType.allCases.count + 1)) { index in
                    let modifiedIndex: Int = index - 1
                    if index == 0 {
                        Text("none")
                            .tag(index)
                    } else {
                        Text(BadgeType.allCases[modifiedIndex].id)
                            .tag(modifiedIndex)
                    }
                }
            }
            .pickerStyle(SegmentedPickerStyle())
        }
        .listRowInsets(EdgeInsets(.zero))
        .listRowBackground(Color(UIColor.systemGroupedBackground))
        .onChange(of: defaultBadgeSelection) {
            if $0 <= 0 { return }
            facility?.defaultBadgeType = BadgeType.allCases[$0 - 1]
        }
    }

    // MARK: - Notes Section

    var notesSection: some View {
        let header = HStack {
            Text("Notes")
            Spacer()
        }

        return Section(header: header) {
            TextEditor(text: $notes.value)
                .frame(maxWidth: .infinity, minHeight: UIScreen.main.bounds.height / 3)
        }
        .listRowInsets(EdgeInsets(top: 5, leading: 10, bottom: 5, trailing: 10))
    }

    enum AlertType: Int, Identifiable {
        var id: Int { rawValue }

        case closeWithoutSaving
        case delete

        func alert(with action: @escaping () -> Void) -> Alert {
            switch self {
            case .closeWithoutSaving:
                return Alert(
                    title: Text("Unsaved Changes"),
                    message: Text("Your changes will be lost"),
                    primaryButton: .destructive(Text("OK"), action: action),
                    secondaryButton: .cancel()
                )
            case .delete:
                return Alert(
                    title: Text("Are you sure?"),
                    message: Text("You will not be able to recover this facility."),
                    primaryButton: .destructive(Text("OK"), action: action),
                    secondaryButton: .cancel()
                )
            }
        }
    }
}

struct EditFacilityPage_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            EditFacilityPage(database: DatabaseService())
        }
    }
}
