//
//  CardDetailView.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 12/8/20.
//

import Database
import SwiftUI
import DeviceServices

struct BadgeDetailsView: View {
    @EnvironmentObject private var passportManager: PassportManager
    @StateObject var viewModel = ViewModel()
    @Environment(\.presentationMode) var presentationMode
    @Dependency(\.database) var database
    
    
    let badge: Badge
    
    @State var editedNotes: String = ""

    var body: some View {
        viewModel.badge = badge
        
        return NavigationView {
            ScrollView {
                VStack(alignment: .center) {
                    header
                        .padding(.bottom, 16)
                    actionMenu
                        .padding(.bottom, 24)
                    notes
                    Spacer()
                }.padding()
            }.background(
                Color(UIColor.systemGroupedBackground)
                    .edgesIgnoringSafeArea(.all)
            )
            .navigationBarTitle(badge.name ?? badge.defaultName, displayMode: .inline)
            .navigationBarItems(leading: doneButton, trailing: deleteButton)
        }.onDisappear(perform: viewModel.saveIfNeeded)
    }
}

// MARK: - Navigation Bar
private extension BadgeDetailsView {
    var deleteButton: some View {
        Button {
            viewModel.deleteButtonTapped()
            presentationMode.wrappedValue.dismiss()
        } label: {
            Image(systemName: "trash")
                .foregroundColor(.red)
        }
    }
    
    var doneButton: some View {
        Button {
            presentationMode.wrappedValue.dismiss()
        } label: {
            Text("Done")
        }
    }
}

// MARK: - Header
private extension BadgeDetailsView {
    var header: some View {
        headerContent
            .padding()
            .frame(height: 200)
            .background(headerBackground)
    }
    
    var headerContent: some View {
        VStack(alignment: .leading) {
            headerTitleText
            headerSubtitleText
                .font(Font.custom("Menlo-Bold", size: 16))
                .foregroundColor(.secondary)
            Spacer()
            HStack(alignment: .bottom) {
                VStack(alignment: .leading) {
                    headerFooterTitleText
                    headerFooterSubtitleText
                }
                Spacer()
                headerTrailingFooterText
            }
        }
    }
    
    var headerBackground: some View {
        LinearGradient(
            gradient: .thisRandom,
            startPoint: .top,
            endPoint: .bottom
        ).cornerRadius(8)
    }
    
    var headerTitleText: some View {
        TextField("Name", text: $viewModel.editedName)
            .font(Font.title.bold())
//        Text(badge.name ?? badge.defaultName)
//            .bold()
//            .font(.title)
    }
    
    var headerSubtitleText: some View {
        Text(badge.trimmedPayloadString(limit: 16))
    }
    
    
    var headerFooterTitleText: Text? {
        let client: String?
        #if DEBUG
        client = viewModel.client?.name ?? "BestBuy"
        #else
        client = viewModel.client?.name
        #endif
        
        guard let text = client else { return nil }
        return Text(text)
            .bold()
            .font(.headline)
    }
    
    var headerFooterSubtitleText: Text? {
        let facility: String?
        #if DEBUG
        facility = viewModel.facility?.name ?? "Capital Mall"
        #else
        facility = viewModel.facility?.name
        #endif
        
        guard let text = facility else { return nil }
        return Text(text)
            .font(.subheadline)
    }
    
    var headerTrailingFooterText: Text? {
        Text(badge.type.name)
            .bold()
            .font(.subheadline)
    }
    
    var actionsAvailable: Bool {
        viewModel.passportService.status == .standby
    }
}

// MARK: - Action Menu

private extension BadgeDetailsView {
    
    var actionMenu: some View {
        VStack {
            actionMenuButtons
            actionMenuMessage
                .font(.subheadline)
        }
    }
    
    var actionMenuButtons: some View {
        
        HStack(alignment: .center, spacing: 8) {
            bruteForceButton
            simulateButton
            writeButton
        }
        .buttonStyle(
            ActionButtonStyle(isEnabled: actionsAvailable)
        ).disabled(!actionsAvailable)
        
    }
    
    @ViewBuilder
    var actionMenuMessage: some View {
        let status: PassportService.Status = viewModel.passportService.status
        switch status {
        case .connecting:
            HStack {
                Text("Connecting to passport...")
                    .bold()
                    .foregroundColor(.secondary)
                ActivitySpinner(isLoading: true)
            }
        case .standby:
            EmptyView()
        case .disconnected:
            Text("Please Connect to Passport")
                .bold()
                .foregroundColor(.secondary)
        case .write(let id):
            HStack {
                Text(id == badge.id ? "Writing Badge...": "Busy...")
                    .bold()
                    .foregroundColor(.secondary)
                ActivitySpinner(isLoading: true)
            }
        case .bruteForce(let id):
            HStack {
                Text(id == badge.id ? "Brute Forcing..." : "Busy...")
                    .bold()
                    .foregroundColor(.secondary)
                ActivitySpinner(isLoading: true)
            }
        case .simulating(let id):
            HStack {
                Text(id == badge.id ? "Simulating..." : "Busy...")
                    .bold()
                    .foregroundColor(.secondary)
                ActivitySpinner(isLoading: true)
            }
        }
        
    }
    
    var bruteForceButton: some View {
        Button(action: viewModel.bruteForceButtonTapped) {
            Image(systemName: "hammer.fill")
            Text("Brute Force").bold()
        }
    }
    
    var simulateButton: some View {
        Button(action: viewModel.simulateButtonTapped) {
            Image(systemName: "dot.radiowaves.left.and.right")
            Text("Simulate").bold()
        }
    }
    
    var writeButton: some View {
        Button(action: viewModel.writeButtonTapped) {
            Image(systemName: "pencil.circle.fill")
            Text("Write").bold()
        }
    }

    struct ActionButtonStyle: ButtonStyle {
        var isEnabled: Bool

        func makeBody(configuration: Configuration) -> some View {
            let backgroundColor = configuration.isPressed
                ? Color(UIColor.secondarySystemFill)
                : Color(UIColor.secondarySystemGroupedBackground)
            
            let foregroundColor: Color = isEnabled
                ? .blue
                : .secondary
            
            return RoundedRectangle(cornerRadius: 12)
                .foregroundColor(backgroundColor)
                .frame(height: 65)
                .overlay(
                    VStack(alignment: .center, spacing: 0) {
                        configuration.label
                            .foregroundColor(foregroundColor)
                    }
                )
        }
    }
}



// MARK: - Notes

private extension BadgeDetailsView {
    var notes: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Notes").bold()
                .foregroundColor(.secondary)
            TextEditor(text: $viewModel.editedNotes)
                .frame(height: 150)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .foregroundColor(
                            Color(.secondarySystemGroupedBackground)
                        )
                )
        }
    }
}


// MARK: - Preview

struct BadgeDetailsView_Previews: PreviewProvider {
    static let badge: Badge =
        Badge(id: .new, createdAt: Date(), type: .proxcard, payload: "abcdefg".data(using: .utf8)!, name: "Security Guard", notes: nil, hidden: false, facility: .new, scans: [], unlockedAccessPoints: [], restrictedAccessPoints: [], savedInProjects: [])
    
    
    static var previews: some View {
        Group {
            BadgeDetailsView(badge: badge)
                .environmentObject(PassportManager())
        }
    }
}

struct NavigationPreviewViewModifier: ViewModifier {
    func body(content: Content) -> some View {
        NavigationView {
            content
        }
    }
}
