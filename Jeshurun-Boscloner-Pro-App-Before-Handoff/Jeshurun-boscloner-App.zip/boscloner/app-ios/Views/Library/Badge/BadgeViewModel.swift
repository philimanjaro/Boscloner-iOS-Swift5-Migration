//
//  BadgeViewModel.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/5/21.
//

import Combine
import Database
import Foundation

extension BadgeDetailsView {
    class ViewModel: ObservableObject {
        
        @Dependency(\.passportService) var passportService
        @Dependency(\.database) var database
        
        var badge: Badge? {
            didSet {
                guard badge?.id != oldValue?.id else { return }
                badgeUpdated()
            }
        }
        
        private(set) var facility: Facility?
        private(set) var client: Client?
        private(set) var isDeleted: Bool = false
        
        @Published var editedNotes: String = ""
        @Published var editedName: String = ""
        
        init() {
            
        }
        
        private func badgeUpdated() {
            isDeleted = false
            editedNotes = badge?.notes ?? ""
            editedName = badge?.name ?? ""
            if let badge = badge {
                facility = database
                    .facility(with: badge.facility)
                client = database
                    .client(with: facility?.client)
            } else {
                facility = nil
                client = nil
            }
            objectWillChange.send()
        }
        
        func deleteButtonTapped() {
            database.delete(with: badge?.id)
            isDeleted = true
        }
        
        func writeButtonTapped() {
            guard let badge = badge else { return }
            passportService.write(badge: badge)
        }
        
        func bruteForceButtonTapped() {
            guard let badge = badge else { return }
            passportService.bruteForce(badge: badge)
        }
        
        func simulateButtonTapped() {
            guard let badge = badge else { return }
            passportService.simulate(badge: badge)
        }
        
        func saveIfNeeded() {
            guard var badge = badge, !isDeleted else { return }
            let changed = editedName != badge.name
                || editedNotes != badge.notes
            
            guard changed else { return }
            
            badge.name = editedName.isEmpty ? nil : editedName
            badge.notes = editedNotes.isEmpty ? nil : editedNotes
            database.save(badge: badge)
        }
        
    }
}

