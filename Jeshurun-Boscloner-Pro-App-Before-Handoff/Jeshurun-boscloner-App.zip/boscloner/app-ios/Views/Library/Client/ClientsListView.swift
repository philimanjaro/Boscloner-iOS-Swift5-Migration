//
//  LibraryPage.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import Database
import SwiftUI

struct ClientsListView: View {
    typealias ViewModel = ClientsListViewModel
    @StateObject private var viewModel: ViewModel

    @State private var isAddClientPageShown = false
    @State private var isDeleteClientAlertShown = false

    @State private var offsets: IndexSet?
    
    @Dependency(\.database) var database

    init(viewModel: ViewModel) {
        _viewModel = .init(wrappedValue: viewModel)
    }

    var body: some View {
        NavigationView {
            VStack {
                DIContainer { depInjector in
                    NavigationLink(
                        destination: ClientEditView(viewModel: .init(client: nil, database: depInjector.database)),
                        isActive: $isAddClientPageShown
                    ) {
                        EmptyView()
                    }
                    .frame(width: 0, height: 0)
                }
                List {
                    clientsSection
                }
                .navigationTitle("Clients")
                .navigationBarItems(leading: populateButton, trailing: addClientButton)
                .alert(isPresented: $isDeleteClientAlertShown) {
                    Alert(title: Text("Are you sure you want to delete this client?"),
                          primaryButton: .destructive(Text("Yes"), action: { self.delete() }),
                          secondaryButton: .cancel())
                }
            }
            .listStyle(PlainListStyle())
        }.navigationViewStyle(StackNavigationViewStyle())
    }

    private func delete() {
        if let offsets = offsets {
            viewModel.deleteClient(at: offsets)
        }
    }
    
    private var populateButton: some View {
        Button {
            MockDatabasePopulator(database: database).populate()
        } label: {
            Text("Populate")
        }
    }
}

// MARK: - Sections

extension ClientsListView {
    // MARK: - Clients Section

    var addClientButton: some View {
        Button(action: { isAddClientPageShown = true }, label: { Image(systemName: "plus") })
    }

    var clientsSection: some View {
        Section {
            DIContainer { depInjector in
                ForEach(viewModel.clients, id: \.id) { client in
                    NavigationLink(destination:
                        ClientDetailsView(viewModel: .init(client: client, database: depInjector.database))
                    ) {
                        Text(client.name)
                    }
                }
                .onDelete(perform: { offsets in
                    self.offsets = offsets
                    self.isDeleteClientAlertShown = true
                })
                if viewModel.clients.isEmpty {
                    Text("You do not have any clients").padding().foregroundColor(.gray)
                }
            }
        }
    }
}

// MARK: - Preview

struct ClientsListView_Previews: PreviewProvider {
    static var previews: some View {
        TabView {
            DIContainer { depInjector in
                ClientsListView(viewModel: .init(database: depInjector.database))
                    .tabItem {
                        Image("creditcard.fill")
                        Text("Library")
                    }
                    .tag(2)
            }
        }
    }
}
