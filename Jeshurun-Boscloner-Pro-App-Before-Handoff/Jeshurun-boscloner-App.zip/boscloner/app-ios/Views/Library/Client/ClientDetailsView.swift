//
//  ClientPageView.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 12/8/20.
//

import Database
import SwiftUI

struct ClientDetailsView: View {
    typealias ViewModel = ClientDetailsViewModel
    @StateObject private var viewModel: ViewModel

    @State private var isDeleteProjectAlertShown = false
    @State private var isAlertShown = false
    @State private var isMenuShown = false
    @State private var isSheetShown = false

    @State private var editSelection: EditItem?
    @State private var deleteSelection: DeleteItem?

    @State private var deleteAction: (() -> Void)?
    @State private var deleteName: String?

    private var sectionLimit: Int = 3

    public init(viewModel: ViewModel) {
        _viewModel = .init(wrappedValue: viewModel)
    }

    var body: some View {
        ZStack {
            navigationInjector.hidden()

            List {
                infoSection
//                notesSection
                facilitiesSection
                contactsSection
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle(Text(viewModel.client.name))
            .navigationBarItems(trailing: menuButton)
//            .toolbar {
//                ToolbarItem(placement: .navigationBarTrailing) {
//
//                }
//            }
        }
        .onAppear {
            viewModel.fetchFacilities()
            viewModel.fetchContacts()
        }
    }
}

// MARK: - Navigation Injector

private extension ClientDetailsView {
    var navigationInjector: some View {
        DIContainer { depInjector in
            Section {
                // Edit Client
                NavigationLink(
                    destination: ClientEditView(
                        viewModel: .init(client: viewModel.client,
                                         database: depInjector.database)),
                    tag: .client,
                    selection: $editSelection
                ) {}

                // Edit Contact
                NavigationLink(
                    destination: EditContactView(),
                    tag: .contact,
                    selection: $editSelection
                ) {}

                // Edit Facility
                NavigationLink(
                    destination: FacilityEditView(client: viewModel.client.id),
                    tag: .facility,
                    selection: $editSelection
                ) {}
            }
            .actionSheet(isPresented: $isSheetShown) {
                ActionSheet(title: Text("Client Menu"), buttons: editSheetButtons)
            }
            .alert(isPresented: $isAlertShown) {
                Alert(title: Text("Are you sure you want to delete \(deleteName ?? "this")"),
                      primaryButton: .destructive(Text("Yes"), action: deleteAction ?? {}),
                      secondaryButton: .cancel())
            }
        }
    }
}

// MARK: - MISC

private extension ClientDetailsView {
    var menuButton: some View {
        return Button(action: onMenuTap) {
            Image(systemName: "pencil.circle")
        }
    }

    var addFacilityButton: some View {
        return Button(action: editAction(.facility)) {
            VStack(spacing: 12) {
                Group {
                    Image(systemName: "plus.square")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 25)
                    Text("Add Facility")
                        .font(.title2)
                        .bold()
                }
                .foregroundColor(.secondary)
            }.padding(15)
        }
    }

    func onMenuTap() {
        isSheetShown.toggle()
    }

    func editAction(_ selection: EditItem) -> () -> Void {
        switch selection {
        case .facility:
            return {
                editSelection = .facility
            }
        case .client:
            return {
                editSelection = .client
            }
        case .contact:
            return {
                editSelection = .contact
            }
        case .delete:
            return {
                editSelection = .delete
                deleteAction(.client)
            }
        }
    }

    func deleteAction(_ item: DeleteItem, offsets: IndexSet? = nil) {
        deleteSelection = item
        isAlertShown.toggle()

        var action: () -> Void {
            switch item {
            case .facility:
                if let offsets = offsets, !offsets.isEmpty {
                    deleteName = viewModel.facilities[offsets.first!].name
                }
                return { print("Deleting facility...") }
            case .contact:
                if let offsets = offsets, !offsets.isEmpty {
                    deleteName = viewModel.contacts[offsets.first!].name
                }
                return { print("Deleting contact...") }
            case .client:
                deleteName = viewModel.client.name
                return { print("Deleting client...") }
            }
        }

        deleteAction = action
    }

    var editSheetButtons: [Alert.Button] {
        [
            .default(Text("Edit Client"), action: editAction(.client)),
            .default(Text("New Contact"), action: editAction(.contact)),
            .default(Text("New Facility"), action: editAction(.facility)),
            .destructive(Text("Delete Client"), action: editAction(.delete)),
            .cancel(),
        ]
    }

    enum EditItem {
        case client, contact, facility, delete
    }

    enum DeleteItem {
        case facility, contact, client
    }
}

// MARK: - Sections

private extension ClientDetailsView {
    // MARK: - Info Section

    var infoSection: some View {
        let destination = ContactDetailsView(contact: viewModel.client.primaryContact)

        let header = HStack {
            Text("Client Info")
            Spacer()
        }

        return Section(header: header) {
            ZStack {
                NavigationLink(destination: destination) {
                    EmptyView()
                }.hidden()

                VStack(alignment: .center) {
                    Text("Primary Contact")
                        .font(.title2)
                    Image(systemName: "person.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(minHeight: 75, maxHeight: 150)
                    VStack(spacing: 5) {
                        Text(viewModel.client.primaryContact.name)
                        if let title = viewModel.client.primaryContact.title {
                            Text(title.uppercased()).foregroundColor(.secondary)
                        }
                    }
                }
                .padding(8)
                .frame(maxWidth: .infinity)
            }
        }
    }

    // MARK: - Notes Section

    var notesSection: some View {
        let header = HStack {
            Text("Notes")
            Spacer()
        }

        return Section(header: header) {
            ZStack(alignment: .top) {
                RoundedRectangle(cornerRadius: 16)
                    .foregroundColor(Color(UIColor.systemFill))
                    .overlay(
                        Text(viewModel.client.notes == nil ? "Notes" : "").foregroundColor(.secondary)
                    )
                Text(viewModel.client.notes ?? "")
                    .bold()
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding()
            }
            .frame(minWidth: .infinity, minHeight: UIScreen.main.bounds.height / 3)
            .listRowBackground(Color(UIColor.systemGroupedBackground))
            .listRowInsets(EdgeInsets(.zero))
        }
    }

    // MARK: - Facilities Section

    var facilitiesSection: some View {
        let header = HStack {
            Text("Facilities")
            Spacer()
        }

        return Section(header: header) {
            if viewModel.facilities.isEmpty {
                addFacilityButton
            }

            ForEach(viewModel.facilities) { facility in
                NavigationLink(destination: FacilityDetailsView(facility: facility)) {
                    ListItemView(title: "\(facility.name)")
                }
            }
            .onDelete { offsets in
                deleteAction(.facility, offsets: offsets)
            }
        }
    }

    // MARK: - Contacts Section

    var contactsSection: some View {
        let destination = itemList(data: viewModel.contacts, title: "All Contacts") { contact in
            NavigationLink(destination: ContactDetailsView()) {
                ListItemView(title: contact.name, icon: Image(systemName: "person.circle"))
            }
        }

        let header = HStack {
            Text("Contacts")
            Spacer()
            if viewModel.contacts.count > sectionLimit {
                NavigationLink(destination: destination) {
                    Text("Show all")
                }
            }
        }

        let contacts = viewModel.contacts.count > sectionLimit
            ? Array(viewModel.contacts[0 ..< sectionLimit])
            : viewModel.contacts

        return Section(header: header) {
            if viewModel.contacts.isEmpty {
                Text("\(viewModel.client.name) does not have any contacts.")
            }

            ForEach(contacts) { contact in
                if viewModel.client.primaryContact.id != contact.id {
                    ZStack {
                        NavigationLink(destination: ContactDetailsView(contact: contact)) {}.hidden()
                        ListItemView(title: "\(contact.name)")
                    }
                }
            }
            .onDelete { offsets in
                deleteAction(.contact, offsets: offsets)
            }
        }.frame(maxWidth: .infinity)
    }
}

// MARK: - Preview

struct ClientDetailsView_Previews: PreviewProvider, View {
    static var previews: some View {
        Group {
            Self()
            Self().colorScheme(.dark)
        }.previewDevice(.iPhone12Pro)
    }

    var body: some View {
        TabView {
            NavigationView {
                DIContainer { depInjector in
                    ClientDetailsView(viewModel: .init(client: .mock(), database: depInjector.database))
                }
            }
        }
    }
}
