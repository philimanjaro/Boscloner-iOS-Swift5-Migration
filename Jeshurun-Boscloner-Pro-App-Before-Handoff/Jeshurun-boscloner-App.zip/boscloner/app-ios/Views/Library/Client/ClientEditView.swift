//
//  ClientEditPage.swift
//  boscloner
//
//  Created by Jeshurun Roach on 12/2/20.
//

import Combine
import Database
import SwiftUI

struct ClientEditView: View {
    typealias ViewModel = ClientEditViewModel
    @Environment(\.presentationMode) var presentationMode
    @StateObject var viewModel: ViewModel

    static var allFields: [ReferenceWritableKeyPath<ClientEditView, FormField>] {
        [\.name, \.firstName, \.lastName, \.phone, \.email, \.notes]
    }

    @State private var name: FormField

    @State private var firstName: FormField
    @State private var lastName: FormField

    @State private var phone: FormField
    @State private var email: FormField
    @State private var notes: FormField

    @State private var alert: AlertType?

//    @State private var isSaveEnabled = false

    init(viewModel: ViewModel) {
        _viewModel = .init(wrappedValue: viewModel)
        _name = .init(initialValue: .name(value: viewModel.client?.name, placeholder: "Pacific Industries"))
        _notes = .init(initialValue: .notes(value: viewModel.client?.notes))

        _firstName = .init(initialValue: .firstName(value: viewModel.contact?.firstName))
        _lastName = .init(initialValue: .lastName(value: viewModel.contact?.lastName))
        _phone = .init(initialValue: .phone(value: viewModel.contact?.phone))
        _email = .init(initialValue: .email(value: viewModel.contact?.email))
    }

    var body: some View {
        Form {
            Section(header: Text("Client Info")) {
                FieldView($name)
            }

            Section(header: Text("Contact")) {
                FieldView($firstName)
                FieldView($lastName)
                FieldView($phone)
                FieldView($email)
            }

            Section(header: Text("Notes")) {
                TextEditor(text: $notes.value)
                    .frame(maxWidth: .infinity, minHeight: UIScreen.main.bounds.height / 3)
            }
            .listRowInsets(EdgeInsets(top: 5, leading: 10, bottom: 5, trailing: 10))

            if viewModel.client != nil {
                Section {
                    deleteButton
                }.listRowBackground(Color(UIColor.systemGroupedBackground))
                    .listRowInsets(EdgeInsets(.zero))
            }
        }
        .navigationTitle(title)
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: closeButton, trailing: saveButton)
        .alert(item: $alert) { type in
            type.alert(with: alertAction(type), name: viewModel.client?.name)
        }
    }
}

// MARK: - MISC

extension ClientEditView {
    var uuidText: Text? {
        guard let string = viewModel.client?.id.rawValue.uuidString else { return nil }
        return Text("ID: ") + Text(string)
    }

    var title: String { viewModel.client == nil ? "New Client" : "Edit Client" }

    var closeButton: some View {
        Button(action: alertAction(.closeWithoutSaving)) {
            Label("Close", systemImage: "xmark")
        }
    }

    var saveButton: some View {
        Button(action: saveClient) {
            Text("Save")
        } // .disabled(!isSaveEnabled)
    }

    var deleteButton: some View {
        Button(action: deleteClient) {
            RoundedRectangle(cornerRadius: 16)
                .foregroundColor(Color(.systemRed))
                .frame(maxWidth: .infinity, minHeight: 50, maxHeight: 50)
                .overlay(Text("Delete")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.white))
        }
    }
}

// MARK: - Functions

extension ClientEditView {
    func alertAction(_ selection: AlertType) -> () -> Void {
        switch selection {
        case .closeWithoutSaving:
            return {
                self.alert = .closeWithoutSaving
                presentationMode.wrappedValue.dismiss()
                print("close")
            }
        case .delete:
            return {
                self.alert = .delete
                presentationMode.wrappedValue.dismiss()
                print("deleted")
            }
        }
    }

    func combinePublishedFields() -> Publishers.MergeMany<Publishers.Sequence<String, Never>> {
        let publishers = Self.allFields.compactMap { self[keyPath: $0].value.publisher }
        return Publishers.MergeMany(publishers)
    }

    func validate() {
        for keyPath in Self.allFields {
            self[keyPath: keyPath].validate()
        }
    }

//    func updateSavedEnabled() {
//        isSaveEnabled = !(name.value.isEmpty || firstName.value.isEmpty || lastName.value.isEmpty)
//    }

    func clearErrors() {
        for keyPath in Self.allFields {
            self[keyPath: keyPath].error = nil
        }
    }

    var hasErrors: Bool {
        Self.allFields.contains { self[keyPath: $0].error != nil }
    }

    func saveClient() {
        validate()
        guard !hasErrors else { return }

        viewModel.save(name: name.value,
                       notes: notes.value,
                       contactFirstName: firstName.value,
                       contactLastName: lastName.value,
                       contactTitle: "",
                       contactPhone: phone.value,
                       contactEmail: email.value)

        presentationMode.wrappedValue.dismiss()
    }

    func deleteClient() {
        print("Deleting client")
        alert = .delete
    }
}

extension ClientEditView {
    enum AlertType: Int, Identifiable {
        var id: Int { rawValue }

        case closeWithoutSaving
        case delete

        func alert(with action: @escaping () -> Void, name: String? = nil) -> Alert {
            switch self {
            case .closeWithoutSaving:
                return Alert(
                    title: Text("Unsaved Changes"),
                    message: Text("Your changes will be lost"),
                    primaryButton: .destructive(Text("OK"), action: action),
                    secondaryButton: .cancel()
                )
            case .delete:
                return Alert(
                    title: Text("Are you sure you want to delete \(name ?? "this")?"),
                    message: Text("You will not be able to recover this client."),
                    primaryButton: .destructive(Text("OK"), action: action),
                    secondaryButton: .cancel()
                )
            }
        }
    }
}

struct ClientEditView_Previews: PreviewProvider {
    static var client: Client? { nil }

    static var previews: some View {
        NavigationView {
            DIContainer {
                ClientEditView(viewModel: TestClientEditViewModel(client: client, database: $0.database))
            }
        }
    }
}
