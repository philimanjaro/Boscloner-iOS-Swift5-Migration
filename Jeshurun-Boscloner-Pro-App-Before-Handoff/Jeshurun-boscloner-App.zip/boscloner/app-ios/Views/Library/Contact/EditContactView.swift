//
//  EditContactPage.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/5/21.
//

import SwiftUI

struct EditContactView: View {
    var body: some View {
        Text("Placeholder: Edit Contact Page")
    }
}

struct EditContactView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            EditContactView()
        }
        .previewDevice(.iPhone12Pro)
    }
}
