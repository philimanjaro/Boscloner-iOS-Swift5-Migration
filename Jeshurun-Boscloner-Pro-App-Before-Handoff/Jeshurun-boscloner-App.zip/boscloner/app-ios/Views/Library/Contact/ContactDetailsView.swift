//
//  ContactView.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/5/21.
//

import Database
import SwiftUI

struct ContactDetailsView: View {
    let contact: Contact!
    var body: some View {
        Text("Placeholder: Contact - \(contact.name)")
    }

    init(contact: Contact? = nil) {
        guard let contact = contact else { self.contact = Contact.mock(id: .new); return }
        self.contact = contact
    }
}

struct ContactDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ContactDetailsView()
        }
        .previewDevice(.iPhone12Pro)
    }
}
