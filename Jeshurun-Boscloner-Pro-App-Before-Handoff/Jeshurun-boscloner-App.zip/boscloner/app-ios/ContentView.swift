//
//  ContentView.swift
//  boscloner-proto
//
//  Created by Jeshurun Roach on 9/7/20.
//

import Database
import SwiftUI

struct IsScanningPreference: PreferenceKey {
    static var defaultValue: Bool = false
    
    static func reduce(value: inout Bool, nextValue: () -> Bool) {
        value = value || nextValue()
    }
    
    typealias Value = Bool
    
    
}

struct ContentView: View {
    var facility: Facility {
        var ret = Facility(name: "Home Facility")
        ret.notes = "Loreum Ipsum..."
        return ret
    }

    @Environment(\.depInjector.database) var database
    @State var selectedTab: TabType = .home
    @State var isScanning: Bool = false
    
    var body: some View {
        TabView(selection: $selectedTab) {
            HomePage()
                .onPreferenceChange(IsScanningPreference.self, perform: { value in
                    isScanning = value
                })
                .tabItem {
                    Image(systemName: "dot.radiowaves.left.and.right")
                        
                    Text(isScanning ? "Scanning" : "Scan")
                }.tag(TabType.home)

            ClientsListView(viewModel: .init(database: database)).tabItem {
                Image(systemName: selectedTab == .library ? "creditcard.fill" : "creditcard")
                Text("Library")
            }.tag(TabType.library)
                .environmentObject(\.database)

            SettingsPage().tabItem {
                Image(systemName: selectedTab == .settings ? "gearshape.2.fill" : "gearshape.2")
                Text("Settings")
            }.tag(TabType.settings)
        }
        .environmentObject(PassportManager())
        .environmentObject(ThorManager())
    }
}

extension ContentView {
    enum TabType {
        case home
        case library
        case settings
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(ClientsListViewModel(database: DatabaseService()))
    }
}
