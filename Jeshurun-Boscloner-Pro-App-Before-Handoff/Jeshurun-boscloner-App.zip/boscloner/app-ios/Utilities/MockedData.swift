//
//  MockedData.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 12/9/20.
//

import Database

private let mockedText = """
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu erat sodales, iaculis erat ut, bibendum erat.
 Ut iaculis ut mi vitae pulvinar. Donec porta ultricies ligula ut euismod. Fusce et libero vel massa consectetur
  dapibus. Suspendisse ac lorem eu est tincidunt tincidunt sit amet sed ante. Donec facilisis auctor.
"""

func mockedBadges(project _: Project) -> [Badge] {
    var badges = [Badge]()
    for _ in 0 ..< Int.random(in: 3 ..< 12) {
        badges.append(.mock())
    }

    return badges
}

func mockedSites() -> [Facility] {
    var sites = [Facility]()
    for index in 0 ..< Int.random(in: 3 ..< 12) {
        sites.append(Facility(name: "Facility #\(index)", notes: "Lorem ipsum..."))
    }

    print(sites)

    return sites
}

// MARK: - Updated Models Mocks

func mock<T: Model>(_ content: (Int) -> (T)) -> [T] {
    var ret = [T]()
    for index in 0 ..< Int.random(in: 2 ..< 6) {
        ret.append(content(index))
    }
    return ret
}

func mockedClients() -> [Client] {
    return mock { _ in
        var client = Client.mock()
        client.name = "Boeing"
        client.notes = mockedText
        return client
    }
}

func mockedBadges() -> [Badge] {
    return mock { num in
        var badge = Badge.mock()
        badge.name = "Badge \(num)"
        badge.notes = mockedText
        let rand = Int.random(in: 0 ..< BadgeType.allCases.count)
        badge.type = BadgeType.allCases[rand < 3 ? rand : 1]
        return badge
    }
}

func mockedProjects() -> [Project] {
    return mock { num in
        var project = Project.mock(id: .new)
        project.name = "Project \(num)"
        return project
    }
}

func mockedAccessPoints() -> [AccessPoint] {
    return mock { num in
        var accessPoint = AccessPoint.mock()
        accessPoint.name = "Access Point \(num)"
        accessPoint.notes = mockedText
        return accessPoint
    }
}

func mockedContacts() -> [Contact] {
    return mock { _ in
        var contact = Contact(firstName: "Steve", lastName: "Jobs", title: "CEO", client: .new)
        contact.notes = mockedText
        return contact
    }
}

func mockedFacilities() -> [Facility] {
    return mock { num in
        var facility = Facility(name: "Facility \(num)")

        facility.address = Address(street: "1301 Fifth Avenue",
                                   city: "Seatle",
                                   state: "WA",
                                   country: "USA",
                                   zip: "98101")
        facility.lat = 47.60902
        facility.lng = -122.33405
        facility.defaultBadgeType = .indala
        facility.notes = mockedText

        return facility
    }
}
