//
//  LocationService.swift
//  boscloner
//
//  Created by Ryan McHugh on 2/4/21.
//

import Combine
import CoreLocation
import Foundation

// SOURCE: https://adrianhall.github.io/swift/2019/11/05/swiftui-location/

class LocationService: NSObject, ObservableObject {
    private let locationService = CLLocationManager()
    private let geocoder = CLGeocoder()

    let objectWillChange = PassthroughSubject<Void, Never>()

    @Published var status: CLAuthorizationStatus? {
        willSet { objectWillChange.send() }
    }

    @Published var location: CLLocation? {
        willSet { objectWillChange.send() }
    }

    override init() {
        super.init()
    }

    // Call `initialize()` on first-use
    public func initialize() {
        guard status == nil else { return }
        locationService.delegate = self
        locationService.desiredAccuracy = kCLLocationAccuracyBest
        locationService.requestWhenInUseAuthorization()
        locationService.startUpdatingLocation()
    }
}

extension LocationService: CLLocationManagerDelegate {
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        status = manager.authorizationStatus
    }

    func locationManager(_: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }
        guard let prevLoc = location else { location = loc; return }
        if prevLoc.coordinate.latitude != loc.coordinate.latitude
            || prevLoc.coordinate.longitude != loc.coordinate.longitude
        {
            location = loc
        }
    }
}

extension LocationService {
    func distance(from loc: CLLocation) -> CLLocationDistance? {
        location?.distance(from: loc)
    }

    func distance(from loc: CLLocationCoordinate2D) -> CLLocationDistance? {
        let loc = CLLocation(latitude: loc.latitude, longitude: loc.longitude)
        return location?.distance(from: loc)
    }
}
