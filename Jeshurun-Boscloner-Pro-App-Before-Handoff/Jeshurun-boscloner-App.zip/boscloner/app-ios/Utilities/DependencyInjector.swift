//
//  DI.swift
//  boscloner
//
//  Created by Jeshurun Roach on 12/28/20.
//

import Database
import DeviceServices
import Foundation
import SwiftUI
import DeviceSupport
import BluetoothSupport

struct DependencyInjector {
    var database: DatabaseService
    var thorService: ThorService
    var connectionManager: DeviceConnectionManager
    var passportService: PassportService
    var locationService: LocationService

    var optionalDependency: OptionalDependency?
}

extension DependencyInjector {
    static let `default`: DependencyInjector = {
        let database = DatabaseService()
        database.initialize()

        let thorService = ThorService()
        let passportService = PassportService()
        let locationService = LocationService()
        let connectionManager = DeviceConnectionManager(
            btManager: BluetoothConnectionManager(configuration: .hm19),
            deviceStore: DatabaseDeviceStore(database: database)
        )
        
        return DependencyInjector(database: database,
                                  thorService: thorService,
                                  connectionManager: connectionManager,
                                  passportService: passportService,
                                  locationService: locationService)
    }()

    static var testing: DependencyInjector = {
        let database = DatabaseService()
        database.initialize()

        let thorService = ThorService()
        let connectionManager = DeviceConnectionManager(
            btManager: BluetoothConnectionManager(configuration: .hm19),
            deviceStore: DatabaseDeviceStore(database: database)
        )
        let passportService = PassportService()
        let locationService = LocationService()

        // Facility

        return DependencyInjector(database: database,
                                  thorService: thorService,
                                  connectionManager: connectionManager,
                                  passportService: passportService,
                                  locationService: locationService)
    }()

    static var preview: DependencyInjector { .default }
}

// MARK: - SwiftUI Wrappers

extension DependencyInjector {
    struct EnvironmentKey: SwiftUI.EnvironmentKey {
        static var defaultValue: DependencyInjector { .default }
    }
}

extension EnvironmentValues {
    var depInjector: DependencyInjector {
        get { self[DependencyInjector.EnvironmentKey.self] }
        set { self[DependencyInjector.EnvironmentKey.self] = newValue }
    }
}

struct DependencyInjectViewModifier<Dependency: ObservableObject>: ViewModifier {
    @Environment(\.depInjector) var depInjector

    let keyPath: KeyPath<DependencyInjector, Dependency>

    init(_ keyPath: KeyPath<DependencyInjector, Dependency>) {
        self.keyPath = keyPath
    }

    func body(content: Content) -> some View {
        content
            .environmentObject(depInjector[keyPath: keyPath])
    }
}

struct OptionalDependencyInjectViewModifier<Dependency: ObservableObject>: ViewModifier {
    @Environment(\.depInjector) var depInjector

    let keyPath: KeyPath<DependencyInjector, Dependency?>

    init(_ keyPath: KeyPath<DependencyInjector, Dependency?>) {
        self.keyPath = keyPath
    }

    func body(content: Content) -> some View {
        guard let dependency = depInjector[keyPath: keyPath] else { fatalError("dependency does not exist") }
        return content
            .environmentObject(dependency)
    }
}

struct DependencyBuilderViewModifier<Dependency>: ViewModifier {
    @Environment(\.depInjector) var depInjector

    let keyPath: WritableKeyPath<DependencyInjector, Dependency?>
    let builder: (DependencyInjector) -> Dependency

    init(_ keyPath: WritableKeyPath<DependencyInjector, Dependency?>,
         builder: @escaping (DependencyInjector) -> Dependency)
    {
        self.keyPath = keyPath
        self.builder = builder
    }

    func body(content: Content) -> some View {
        let dependency = builder(depInjector)

        return content
            .transformEnvironment(\.depInjector) { $0[keyPath: keyPath] = .some(dependency) }
    }
}

struct DIContainer<Content: View>: View {
    @Environment(\.depInjector) private var depInjector
    private let contentBuilder: (DependencyInjector) -> Content

    init(@ViewBuilder content: @escaping (DependencyInjector) -> Content) {
        contentBuilder = content
    }

    var body: some View {
        contentBuilder(depInjector)
    }
}

extension View {
    func environmentObject<Dependency: ObservableObject>(_ keyPath: KeyPath<DependencyInjector,
        Dependency>) -> some View
    {
        modifier(DependencyInjectViewModifier(keyPath))
    }

    func environmentObject<Dependency: ObservableObject>(_ keyPath: KeyPath<DependencyInjector,
        Dependency?>) -> some View
    {
        modifier(OptionalDependencyInjectViewModifier(keyPath))
    }

    func dependency<Dependency>(_ keyPathp: WritableKeyPath<DependencyInjector, Dependency?>,
                                builder: @escaping (DependencyInjector) -> Dependency) -> some View
    {
        modifier(DependencyBuilderViewModifier(keyPathp, builder: builder))
    }

    func dependencyInjector(_ depInjector: DependencyInjector = .default) -> some View {
        environment(\.depInjector, depInjector)
    }
}

// MARK: - Example of Optional Dependency

private struct DependencyInjectionDemonstrationView: View {
    var body: some View {
        VStack {
            // inject a required dependency as an environment object
            ViewThatNeedsRequiredDependency()
                .environmentObject(\.database)

            // create an optional dependency
            ViewThatNeedsOptionalDependency()
                .dependency(\.optionalDependency) {
                    OptionalDependency(database: $0.database)
                }

            // create AND inject an optional dependency into the environment
            ViewThatNeedsOptionalDependency()
                .environmentObject(\.optionalDependency)
                .dependency(\.optionalDependency) {
                    OptionalDependency(database: $0.database)
                }

            // FORCE inject an optional dependency as an environment object.
            // WARNING: this will crash if the dependency isn't created
            // just like how app will crash if environment object is not placed in environment.
            // we crash here instead so it's easier to reason about the environment failure.
            ViewThatNeedsOptionalDependency()
                .environmentObject(\.database)

            // create a view with a view model with required dependencies
            DIContainer { depInjector in
                ViewModelViewThatNeedsRequiredDependency(viewModel: .init(database: depInjector.database))
            }

            // create a view with a view model with optional dependencies if exists
            DIContainer { depInjector in
                if let dependency = depInjector.optionalDependency {
                    ViewModelViewThatNeedsOptionalDependency(viewModel: .init(optional: dependency))
                } else {
                    EmptyView()
                }
            }
        }
    }

    struct ViewThatNeedsOptionalDependency: View {
        @EnvironmentObject var optionalDependency: OptionalDependency

        var body: some View {
            Text(verbatim: "\(optionalDependency)")
        }
    }

    struct ViewThatNeedsRequiredDependency: View {
        @EnvironmentObject var database: DatabaseService

        var body: some View {
            Text(verbatim: "\(database)")
        }
    }

    struct ViewModelViewThatNeedsRequiredDependency: View {
        @StateObject var viewModel: ViewModel

        var body: some View {
            Text(verbatim: "\(viewModel)")
        }

        class ViewModel: ObservableObject {
            init(database _: DatabaseService) {}
        }
    }

    struct ViewModelViewThatNeedsOptionalDependency: View {
        @StateObject var viewModel: ViewModel

        var body: some View {
            Text(verbatim: "\(viewModel)")
        }

        class ViewModel: ObservableObject {
            init(optional _: OptionalDependency) {}
        }
    }
}

class OptionalDependency: ObservableObject {
    init(database _: DatabaseService) {}
}
