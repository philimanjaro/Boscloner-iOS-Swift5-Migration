//
//  Extensions.swift
//  boscloner
//
//  Created by Ryan McHugh on 12/28/20.
//

import Database
import Foundation
import SwiftUI

public extension PreviewDevice {
    static var iPhone12Pro: PreviewDevice { "iPhone 12 Pro" }
    static var iPhoneSE: PreviewDevice { "iPhone SE" }
    static var mac: PreviewDevice { "My Mac" }
}

// View
extension View {
    // Creates a scrollable list view from an array of 'model' objects, based on a given builder
    func itemList<Content: View, T: Model>(data: [T],
                                           title: String = "",
                                           @ViewBuilder content: @escaping (T) -> Content) -> some View
    {
        return List {
            ForEach(data) { item in
                ZStack {
                    content(item)
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle(title)
    }

    func runBlock(_ run: @escaping () -> Void) -> some View {
        run()
        return EmptyView()
    }
}

extension Set {
    mutating func toggle(_ member: Element) {
        if contains(member) {
            remove(member)
        } else {
            insert(member)
        }
    }
}

// Property Wrappers
@propertyWrapper
struct Dependency<D> {
    static var injector: DependencyInjector { .default }
    let keyPath: KeyPath<DependencyInjector, D>
    init(_ keyPath: KeyPath<DependencyInjector, D>) {
        self.keyPath = keyPath
    }

    var wrappedValue: D {
        Self.injector[keyPath: keyPath]
    }
}

// Source: https://stackoverflow.com/questions/28872450/conversion-from-nstimeinterval-to-hour-minutes-seconds-milliseconds-in-swift
extension TimeInterval {
    var milliseconds: Int {
        return Int(truncatingRemainder(dividingBy: 1) * 1000)
    }

    var seconds: Int {
        return Int(self) % 60
    }

    var minutes: Int {
        return (Int(self) / 60) % 60
    }

    var hours: Int {
        return Int(self) / 3600
    }

    var stringTime: String {
        if hours != 0 {
            return "\(hours)h \(minutes)m \(seconds)s"
        } else if minutes != 0 {
            return "\(minutes)m \(seconds)s"
        } else if milliseconds != 0 {
            return "\(seconds)s \(milliseconds)ms"
        } else {
            return "\(seconds)s"
        }
    }
}
