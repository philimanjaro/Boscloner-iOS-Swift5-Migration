//
//  Helpers.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/4/21.
//

import Combine
import Database
import Foundation
import MapKit
import UIKit

public class Helpers {
    // Singleton
    public static var shared = Helpers()

    // MARK: - Location Functions

    public func getCoordinate(address: Address?) -> AnyPublisher<CLLocationCoordinate2D, Error> {
        guard let address = address else {
            return Fail(error: LocationError.couldNotParseAddress(nil)).eraseToAnyPublisher()
        }

        return Future { promise in
            CLGeocoder().geocodeAddressString(address.combined) { placemarks, error in
                if error == nil, let coordinate = placemarks?.first?.location?.coordinate {
                    promise(.success(coordinate))
                } else if let error = error {
                    promise(.failure(error))
                } else { promise(.failure(LocationError.couldNotResolveLocationLookup)) }
            }
        }.eraseToAnyPublisher()
    }

    public func navigateWithAppleMaps(coordinate: CLLocationCoordinate2D?, name: String?) {
        guard let coordinate = coordinate else { return }
        let mapItem = MKMapItem(placemark: MKPlacemark(coordinate: coordinate, addressDictionary: nil))
        mapItem.name = name ?? "Facility"
        mapItem.openInMaps(launchOptions: nil)
    }

    public func copyToClipboard(string: String?) {
        UIPasteboard.general.string = string
    }
}

// MARK: - Errors

extension Helpers {
    // MARK: - Location Errors

    enum LocationError: Error {
        case couldNotParseAddress(Address?)
        case couldNotResolveLocationLookup
    }

    func onError<T>(_ completion: Subscribers.Completion<T>) {
        switch completion {
        case .finished: ()
        case let .failure(error): print(error)
        }
    }
}
