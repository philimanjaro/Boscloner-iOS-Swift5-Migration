//
//  TestFacilityDetailsViewModel.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/13/21.
//

import Foundation

final class TestFacilityDetailsViewModel: FacilityDetailsViewModel {
    override func fetchContacts() {
        contacts = mockedContacts()
    }

    override func fetchBadges() {
        badges = mockedBadges()
    }

    override func fetchAccessPoints() {
        accessPoints = mockedAccessPoints()
    }
}
