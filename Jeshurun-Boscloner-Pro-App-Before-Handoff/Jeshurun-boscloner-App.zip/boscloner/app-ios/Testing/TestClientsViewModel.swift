//
//  TestLibraryViewModel.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/7/21.
//

import Combine
import Database
import Foundation
import SwiftUI

final class TestClientsViewModel: ClientsListViewModel {}
