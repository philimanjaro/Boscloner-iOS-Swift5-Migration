//
//  TestClientEditViewModel.swift
//  boscloner
//
//  Created by Shahla Almasri Hafez on 1/14/21.
//

final class TestClientEditViewModel: ClientEditViewModel {}
