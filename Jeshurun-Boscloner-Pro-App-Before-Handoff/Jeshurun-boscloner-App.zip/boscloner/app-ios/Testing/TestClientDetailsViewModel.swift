//
//  TestClientDetailsViewModel.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/13/21.
//

import Combine
import Database
import Foundation
import SwiftUI

final class TestClientDetailsViewModel: ClientDetailsViewModel {
    override func fetchFacilities() {
        facilities = mockedFacilities()
    }

    override func fetchContacts() {
        contacts = mockedContacts()
    }
}
