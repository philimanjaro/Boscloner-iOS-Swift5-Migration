//
//  TestLibraryViewModel.swift
//  boscloner
//
//  Created by Ryan McHugh on 1/7/21.
//

import Combine
import Database
import Foundation
import SwiftUI

public class TestLibraryViewModel: LibraryViewModel {
    override init(database: DatabaseService) {
        super.init(database: database)
//        mockData()
    }

    override func createProject(name _: String, for _: Client) {}

    override func deleteProject(for _: Client, at _: IndexSet) {}

    override func fetchRecentProjects() {}

    override func fetchClients() {
        super.clients = mockedClients()
    }

    override func fetchProjects(for _: Client) {
        super.projects = mockedProjects()
    }

    override func fetchFacilities() {
        super.facilities = mockedFacilities()
    }

    func mockData() {
        clients.forEach { client in
            facilities.forEach { facility in
                contacts.forEach { contact in
                    if Int.random(in: 0 ..< 12) > 3 {
                        var client = client
                        var facility = facility
                        var contact = contact
                        let random = Int.random(in: 0 ..< contacts.count - 2)

                        client.facilities += [facility.id]
                        client.primaryContact = contact.id
                        client.contacts = self.contacts[random ..< (random + 2)].compactMap { $0.id }

                        facility.client = client.id
                        facility.contacts = self.contacts[random ..< (random + 2)].compactMap { $0.id }

                        contact.client = client.id
                    }
                }
            }
        }
    }
}
