//
//  bosclonerApp.swift
//  boscloner
//
//  Created by Jeshurun Roach on 9/8/20.
//

import Database
import SwiftUI

@main
struct BosclonerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .dependencyInjector()
        }
    }
}
